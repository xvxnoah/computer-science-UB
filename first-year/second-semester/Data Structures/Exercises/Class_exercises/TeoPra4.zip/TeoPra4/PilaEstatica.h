/* 
 * File:   PilaEstatica.h
 * Author: Noah Márquez
 */

#ifndef PILAESTATICA_H
#define PILAESTATICA_H

class PilaEstatica {

private:
    enum {DEFAULT_MAX_STACK = 30};
    int _pila[DEFAULT_MAX_STACK]; //stack
    int _cim; //top
    
public:
    PilaEstatica(int); //constructor
    PilaEstatica(const PilaEstatica& orig); //copy constructor
    virtual ~PilaEstatica(); //destructor (NO NECESSARI)
    int size() const; //return the size
    bool isEmpty() const; //return TRUE if stack is empty
    bool isFull() const; //return TRUE if stack is full
    const int& top() const; //return the top element of stack
    void push(const int& e); //introduce an element in the stack
    void pop(); //remove top element from stack
    void print() const; //print the contents of the stack
};

#endif /* PILAESTATICA_H */

