/* 
 * File:   PilaEstatica.cpp
 * Author: Noah Márquez
 */

#include "PilaEstatica.h"
#include <iostream>
#include <stdexcept>
using namespace std;

PilaEstatica::PilaEstatica(int cap) {
    this->_cim = -1;
}

PilaEstatica::PilaEstatica(const PilaEstatica& orig) {
    for (int i = 0; i < orig.size(); i++) { //amb un for perquè no podem copiar un vector directament a un altre.
        this->_pila[i] = orig._pila[i];
    }
    this->_cim = orig._cim;
}

int PilaEstatica::size() const {
    return (this->_cim + 1);
}

bool PilaEstatica::isEmpty() const {
    return (_cim < 0); //Return true if the stack is empty
}

bool PilaEstatica::isFull() const {
    return ((_cim + 1) == this->DEFAULT_MAX_STACK);
}

const int& PilaEstatica::top() const { //el primer const vol dir que el retorno només es pot veure no podificar. L'últim const vol dir que la funció només consulta els atributs i no els edita.
    if (isEmpty()) {
        throw out_of_range("top(): empty stack");
    }
    return _pila[_cim];
    //return the top element of stack

}

void PilaEstatica::push(const int& e) {
    if (size() == this->DEFAULT_MAX_STACK) {
        throw out_of_range("push(): full stack");
    }
    _pila[++_cim] = e; //introduce an element in the stack
}

void PilaEstatica::pop() {
    if (this->isEmpty()) {
        throw out_of_range("pop(): empty stack");
    }
    --_cim; //remove top element from the stack
}

void PilaEstatica::print() const {
    if (this->isEmpty())
        cout << "Stack =[]" << "  size " << size() << endl;
    else {
        cout << "Stack=[";
        for (int i = 0; i <= _cim; i++) {
            if (i != _cim) cout << _pila[i] << " ,";
            else cout << _pila[i];
        }
        cout << "] size " << size() << " " << endl;
    }
}

PilaEstatica::~PilaEstatica() {
}
