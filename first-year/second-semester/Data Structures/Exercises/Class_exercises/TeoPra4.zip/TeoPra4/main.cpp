/* 
 * File:   main.cpp
 * Author: Noah Márquez
 */

#include <cstdlib>
#include <iostream>
#include <stdexcept>
#include <exception>
#include "PilaEstatica.h"

using namespace std;

int main() {
    try{
        int valors[4] = {1, 2, 3, 4};
        PilaEstatica pila;
        
        for (int i = 0; i < 4; i++){
            pila.push(valors[i]);
        }
        pila.print();
        int i = 1;
        
        while (!pila.isEmpty()){
            cout << " top " << i << " es: " << pila.top() << endl;
            pila.pop();
            i++;
        }
        pila.print();
    }
    catch (exception const& ex){
        cerr << "Exception: " << ex.what() << endl;
        return -1;
    }

    return 0;
}

