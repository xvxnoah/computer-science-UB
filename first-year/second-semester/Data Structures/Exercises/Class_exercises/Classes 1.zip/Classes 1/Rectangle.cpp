/*
 * 
 * 
 * 
 */

/* 
 * File:   Rectangle.cpp
 * Author: Noah
 * 
 * Created on 24 de febrero de 2021, 13:24
 */

#include "Rectangle.h"

Rectangle::Rectangle() {
    width = 5;
    height = 5;
}

Rectangle::Rectangle(int w, int h) {
    width = w;
    height = h;
    //this --> heigth : this és un punter intern
}

int Rectangle::area() {
    return(width * height);
}

