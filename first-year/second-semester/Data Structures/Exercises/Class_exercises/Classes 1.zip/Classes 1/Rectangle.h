/* 
 * File:   Rectangle.h
 * Author: noahmv
 *
 * Created on 24 de febrero de 2021, 13:24
 */

#ifndef RECTANGLE_H
#define RECTANGLE_H

class Rectangle {
    int width, height; //atributs
    
public:
    Rectangle(); //Constructor per defecte
    //Rectangle(const Rectangle& orig); Constructor còpia. (Rectangle(Rectangle&))
    Rectangle(int, int); //Constructor amb paràmetres
    int area();
    //virtual ~Rectangle(); Destructor
    
private:

};

#endif /* RECTANGLE_H */

