/*
 * 
 * 
 * 
 */

/* 
 * File:   main.cpp
 * Author: noahmv
 *
 * Created on 24 de febrero de 2021, 13:23
 */

#include <cstdlib>
#include <iostream>
#include "Rectangle.h"

using namespace std;

int main() {
    Rectangle rect(3, 4); //Constructor amb paràmetres
    Rectangle rectb; //crida al constructor per defecte, la seva àrea serà 5·5.
    cout << "rect area: " << rect.area() << endl;
    cout << "rectb area: " << rectb.area() << endl;
    return 0;
}

