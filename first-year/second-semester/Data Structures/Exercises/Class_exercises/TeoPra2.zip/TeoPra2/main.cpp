/* 
 * File:   main.cpp
 * Author: Noah Márquez
 */

#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>

#include <stdexcept>
#include <exception>
#include "LinkedDeque.h"

using namespace std;

/**
 * Mètode per eliminar un element de l'inici de la cua i recollir les possibles
 * excepcions.
 * @param linked, LinkedDeque
 */
void eliminarFront(LinkedDeque<int>* linked){
    try{
        linked->dequeueFront();
    } catch(exception const& ex){
        cerr << "EXCEPTION: " << ex.what() << endl;
    }
}

/**
 * Mètode per eliminar un element del final de la cua i recollir les possibles
 * excepcions.
 * @param linked, LinkedDeque
 */
void eliminarRear(LinkedDeque<int>* linked){
    try{
        linked->dequeueBack();
    } catch(exception const& ex){
        cerr << "EXCEPTION: " << ex.what() << endl;
    }
}

/**
 * Mètode per obtenir l'element de l'inici de la cua i recollir les possibles
 * excepcions
 * @param linked, LinkedDeque
 */
void front(LinkedDeque<int>* linked){
    try{
        cout << linked->getFront() << endl;
    } catch(exception const& ex){
        cerr << "EXCEPTION: " << ex.what() << endl;
    }
}

/**
 * Mètode per obtenir l'element del final de la cua i recollir les possibles
 * excepcions
 * @param linked, LinkedDeque
 */
void rear(LinkedDeque<int>* linked){
    try{
        cout << linked->getBack() << endl;
    } catch(exception const& ex){
        cerr << "EXCEPTION: " << ex.what() << endl;
    }
}

void casProva1(){
    cout << "\n";
    cout << "-----------------------" << endl;
    cout << "    CAS DE PROVA 1:" << endl;
    cout << "-----------------------" << endl;
    LinkedDeque<int> *test1 = new LinkedDeque<int>();
    
    //testejem els mètodes
    test1->enqueueFront(10);
    test1->enqueueBack(20);
    test1->enqueueFront(30);
    test1->enqueueBack(40);
    test1->print();
    eliminarFront(test1);
    test1->enqueueBack(40);
    test1->print();
    cout << "\n";
    
    delete test1;
}

void casProva2() {
    cout << "-----------------------" << endl;
    cout << "    CAS DE PROVA 2:" << endl;
    cout << "-----------------------" << endl;
    LinkedDeque<int> *test2 = new LinkedDeque<int>();
    
    //testejem els mètodes
    test2->enqueueFront(10);
    front(test2);
    test2->enqueueBack(20);
    test2->enqueueBack(30);
    test2->print();
    eliminarRear(test2);
    rear(test2);
    eliminarRear(test2);
    eliminarRear(test2);
    eliminarFront(test2);
    test2->print();
    cout << "\n";
    
    delete test2;
}

int main() {
    LinkedDeque<int> q;
    int elements[5] = {1, 2, 3, 4, 5};
    
    for(int i = 0; i < 5; i++){
        q.enqueueBack(elements[i]);
        q.print();
    }
    int elem = 5; q.enqueueAt(elem, 2); q.print();
    elem = 6; q.enqueueAt(elem, 7); q.print();
    elem = 7; q.enqueueAt(elem, 0); q.print();
    
    int opcio, element;
    vector<string> opcions{"Inserir element a l'inici", "Inserir "
        "element al darrera", "Treure element pel davant",
        "Treure element pel darrera", "Consultar el primer element",
        "Consultar el darrer element", "Imprimir tot el contingut de LinkedDeque",
        "Sortir"};
    
    casProva1();
    casProva2();
    
    //crida al constructor
    LinkedDeque<int> *linked= new LinkedDeque<int>();
    
    do {
        for (int i = 0; i < opcions.size(); i++) {
            cout << (i + 1) << ".  " << opcions[i] << endl;
        }
        cin >> opcio;
        
        //Bucle fins que la opció introduïda sigui correcte
        while (opcio < 1 || opcio > 8) {
            cout << "Opció no vàlida. Introdueix un altre nombre " << endl;
            for (int i = 0; i < opcions.size(); i++) {
                cout << (i + 1) << ".\t" << opcions[i] << endl;
            }
            cin >> opcio;
        }

        switch (opcio) {
            case 1:
                cout << "Element a inserir a l'inici: " << endl;
                cin >> element;
                linked->enqueueFront(element);
                break;
            case 2:
                cout << "Element a inserir al darrere: " << endl;
                cin >> element;
                linked->enqueueBack(element);
                break;
            case 3:
                eliminarFront(linked);
                break;
            case 4:
                eliminarRear(linked);
                break;
            case 5:
                front(linked);
                break;
            case 6:
                rear(linked);
                break;
            case 7:
                linked->print();
                break;
        }
    } while (opcio != 8);
    
    //crida al destructor
    delete linked;
    return 0;
}

