/* 
 * File:   main.cpp
 * Author: Noah Márquez
 */

#include <cstdlib>
#include <iostream>
#include <stdexcept> //Per manegar les excepcions
#include "Time.h"

using namespace std;

int main(int argc, char** argv) {
    /*
     * Proveu de descomentar el codi i veure què passa.
    //Time t2(25, 0, 0); //si fem això el programa acaba abruptament
    //t2.print(); //La resta del programa s'executarà
    
    //Solució captar les possibles excepcions:
    
    try{
        //Time t1(25, 0, 0); //Saltarà tot el que hi hagi a sota i anirà al catch si l'excepció s'activa
        //t1.print();
        //Continua després del try-catch si l'excepció no es produeix
    } catch(invalid_argument& ex){ //necessiteu incloure el include
        cout << "Exception: " << ex.what() << endl;
        //Continue després del try-catch
    }
    cout << "Next stament després del try-catch" << endl;
     */
    cout << "Objecte normal: " << endl; 
    
    Time t1(1, 2, 3); //declara un objecte estàtic, s'esborrarà automàticament del stack.
    t1.print(); //usa el print amb l'objecte i digues quina és la sortida.
    
    cout << "Punter a objecte estatic: " << endl; 
    Time* ptrT1 = &t1; //declara un punter i assigna l'adreça de l'objecte estàtic creat abans. El punter també s'esborra automàticament.
    (*ptrT1).print(); //usa el print amb l'objecte i digues quina és la seva sortida.
    ptrT1->print(); //usa el print amb l'objecte i digues quina és la seva sortida.

    //RECORDA QUE: anObjectPtr-> member és el mateix que (*anObjectPtr).member (possem el parèntesis per assegurar, però millor fer servir la fletxa).
    cout << "Referencia a objecte: " << endl;
    Time& refT1 = t1; //crea un objecte Time anomenat refT1 un alias de t1.
    refT1.print(); //usa el print amb l'objecte i digues quina és la seva sortida.

    cout << "Objecte dinamic: " << endl; 
    Time* ptrT2 = new Time(4, 5, 6); //Crea dinàmicament un objecte. L'hem de borrar desprès d'utilitzar-ho, perquè el creem amb un new al heap.
    ptrT2->print(); //usa el print amb l'objecte i digues quina és la seva sortida.
    delete ptrT2;
    return 0;

    //Declara un array estàtic de 2 objectes Time anomenat tArray1 inicialitzats amb el constructor per defecte
    cout << "Array d'objectes 1: " << endl; 
    Time tArray1[2];
    tArray1[0].print(); //00::00:00
    tArray1[1].print(); //00::00:00

    //Declara un array estàtic de 2 objectes Time anomenat tArray2 inicialitzats amb el constructor per paràmetres
    cout << "Array d'objectes 2 " << endl; 
    Time tArray2[2] = {Time(7, 8, 9), Time(10)}; // Invoca al constructor
    tArray2[0].print(); // 07:08:09
    tArray2[1].print(); // 10:00:00

    //Declara un array dinàmic de 2 objectes Time anomenat pttrTArray3 inicialitzats amb el constructor per defecte
    cout << "Array d'objectes 3: " << endl; 
    Time *ptrArray3 = new Time[2]; // es un punter a Time
    ptrArray3[0].print(); //00::00:00
    ptrArray3[1].print(); //00::00:00
    delete [] ptrArray3; // allibera la memoria de l'array via delete[] (perquè és un array s'utiliza delete[])

    //Declara un array dinàmic de 2 objectes Time anomenat pttrTArray4 inicialitzats amb el constructor per paràmetres
    cout << "Array d'objectes 4: " << endl; 
    Time * ptrArray4 = new Time[2]{Time(11, 12, 13), Time(14)};
    ptrArray4->print(); //11:12:13 
    (ptrArray4 + 1)->print(); // 14:00:00
    delete[] ptrArray4; // allibera la memoria de l'array via delete[] (perquè és un array s'utiliza delete[])
    
    cout << "Fi del programa." << endl; 

}

/*
 * int i = 0;
 * cout << ++i << endl; primer assignem (sumem 1) i després tornem el resultat ->1
 * cout << i++ << endl; primer retornem el contingut de la i, posteriorment sumem 1 ->1
 * cout << i; ->2
 */