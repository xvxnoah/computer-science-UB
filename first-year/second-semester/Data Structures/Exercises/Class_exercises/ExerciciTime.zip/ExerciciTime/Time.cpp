/* 
 * File:   Time.cpp
 * Author: Noah Márquez
 */

#include <iostream>
#include <iomanip>  // get_time put_time functions
#include <stdexcept> // per manegar excepcions
#include "Time.h"

using namespace std; 

Time::Time(int h, int m, int s){
    this->setHour(h); //A la diapo sense el this.
    this->setMinute(m);
    this->setSecond(s); 
}


int Time::getHour() const{
    return this->hour; //A la diapo sense el this.
}

void Time::setHour(int h){
    if (h>=0 && h<=23 ) {
        this->hour = h; //A la diapo sense el this.
    } else { 
        throw invalid_argument("Invalid hour! Hour shall be 0-23."); 
    }
}

int Time:: getMinute() const{
    return this->minute; //A la diapo sense el this.
}

void Time::setMinute(int m){
    if (m >=0 && m <=59 ){
        this->minute = m; //A la diapo sense el this.
    } else {
        throw invalid_argument("Invalid minute! Minute shall be 0-59."); 
    }
}

int Time::getSecond() const{
    return this->second; //A la diapo sense el this.
}

void Time::setSecond(int s){
     if (s >=0 && s <=59 ){
        this->second = s; //A la diapo sense el this.
    } else {
        throw invalid_argument("Invalid segon ! ha d'estar entre 0-59"); 
    }
}

void Time::setTime(int h, int m, int s)
{   
    setHour(h);
    setMinute(m);
    setSecond(s); 

}

void Time::print() const
{
    cout << setfill('0'); //De la llibreria iomanip, amb setfill si detecta que hi ha un espai dels 2 buit, l'omple amb un 0.
    cout << setw(2) << hour << ":" //setw estableix l'amplada, en aquest cas 2 espais, llavors esperarà 2 espais.
         << setw(2) << minute << ":" //setw també abans de minute
         << setw(2) << second << endl; //setw també abans de second
} 
