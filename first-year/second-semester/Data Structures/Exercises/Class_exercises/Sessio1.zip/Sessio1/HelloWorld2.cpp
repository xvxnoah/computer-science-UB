/*
 * 
 * 
 * 
 */
#include <iostream>
#include <cstdlib>

using namespace std;

int  main2()
{
    int years = 0;
    cout << "Write how old are you at the end of this year?  ";
    cin >> years;
    cout << "So, you were born in " << (2021-years) << endl;
    return 0;
}
