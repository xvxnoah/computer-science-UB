/*
 * La congruència de Zeller és un càlcul que permet obtenir el dia de la setmana
 * per a una data qualsevol del calendai gregorià. Donada una data determinada pel
 * triplet {d, m, a}, on d és el dia del mes, m és el mes de l'any i a és l'any.
 *      1. Se li resten dues unitats al mes m i si dóna zero o menys se li suma 12
 *      al mes i se li resta una unitat a l'any. El nou mes obtingut l'anomenem m'
 *      i el nou any a'.
 * 
 *      2. Es calcula la centúria c (els dos primers dígits de l'any) a partir de 
 *      l'any a'.
 *  
 *      3. Es calcula l'any dins la centúria y (els dos darrers dígits de l'any)
 *      a partir de l'any a'.
 * 
 *      4. Es calcula f = [2.6m' - 0.] + d + y + [y/4] + [c/4] -2c,
 *      on [x] és la part entera per defecte de x.
 * 
 *      5. f mòdul 7 representa el dia de la setmana segons la correspondència
 *      següent: 0 = diumenge, 1 = dilluns, ...
 * 
 * 
 */

#include <iostream>

using namespace std;

void dia(int h){
    switch(h){
        case 0:
            cout << "diumenge" << endl; break;
        case 1:
            cout << "dilluns" << endl; break;
        case 2:
            cout << "dimarts" << endl; break;
        case 3:
            cout << "dimecres" << endl; break;
        case 4:
            cout << "dijous" << endl; break;
        case 5:
            cout << "divendres" << endl; break;
        case 6:
            cout << "dissabte" << endl; break;
    }
}

int zeller()
{
    int d, m, a;
    cout << "Escriu dia, mes i anys" << endl;
    cin >> d >> m >> a;
    int a2, m2;
    if (m - 2 <= 0){
        m2 = m - 2 + 12;
        a2 = a - 1;
    }
    else{
        m2 = m - 2;
        a2 = a;
    }
    
    int c = a2 / 100;
    int y = a2 % 100;
    
    int f = (26*m2-2)/10 + d + y + (y/4) + (c/4) - 2*c;
    int s = f%7;
    
    if (s < 0) s+= 7; //Compte!!
    
    dia(s);
}