/*
 * Quina és la sortida d'aquest programa donada l'entrada 3 8 9 4 2 -1? La sortida és 9.
 * Descriviu en una frase què fa aquest programa: Troba el màxim. 
 * 
 */
#include <iostream>

using namespace std;

int misterios()
{
    int a;
    cin >> a;
    int m = a;
    
    while(a > 0){
        if (m < a) m = a;
        cin >> a;
    }
    
    cout << m << endl;
}
