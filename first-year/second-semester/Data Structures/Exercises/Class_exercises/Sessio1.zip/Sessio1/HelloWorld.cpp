/* 
 * File:   HelloWorld.cpp
 * Author: Noah
 *
 * Created on 20 de febrero de 2021, 12:30
 */

#include <cstdlib>
#include <iostream>
using namespace std;

int main2();
void helloWorld3();
int misterios();
int pasParametres();
int zeller();
int circumferencia();
int operacions();
int fibonnacci();
/*
 * 
 */
int main() {
    cout <<"Hello World" << endl;
    cout << "This is a nice example \n"<< endl;
    
    //main2();
    //helloWorld3();
    //misterios();
    //pasParametres();
    //zeller();
    //circumferencia();
    //operacions();
    fibonnacci();
    return 0;
}

