/*
 * Calcular la longitud i l'àrea d'una circumferència i el volum de l'esfera.
 * Longitud de la circunferencia = 2*PI*Radio
 * Área de la circunferencia = PI*Radio^2
 * Volumen de la esfera = (4/3)*PI*Radio^3
 * 
 */
#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int circumferencia(void) {
    const float PI = 3.1416;
    float radio;
    cout << "Introduce el valor del radio : ";
    cin >> radio;
    cout << "\nLongitud de la circunferencia: " << fixed << setprecision(2) << 2 * PI*radio;
    cout << "\nArea del circulo: " << PI * pow(radio, 2);
    cout << "\nVolumen de la esfera: " << (4.0 / 3) * PI * pow(radio, 3) << endl;
    system("pause");
}
