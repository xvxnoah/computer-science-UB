/*
 * Feu un programa que:
 *      demani un nom al main,
 *      l'imprimeixi per pantalla i,
 *      posteriorment, cridi a una funció modifica que permetrà a l'usuari tornar
 *      a introduir un altre nom.
 *          La funció modifica ha de permetre el pas per referència
 * Al tornar de la funció modifica, s'ha d'imprimir el nom per pantalla
 * 
 * 
 */
#include <iostream>
#include <string>

using namespace std;

void modifica(string& nom)
{
    cout << "escriu un altre nom " << endl; 
    cin >> nom;
}

int pasParametres(){
    string nom;
    cout << " Dona un nom " << endl;
    cin >> nom;
    cout << "et dius " << nom << endl;
    modifica(nom);
    cout << "et dius " << nom << endl;
return 0;
}
