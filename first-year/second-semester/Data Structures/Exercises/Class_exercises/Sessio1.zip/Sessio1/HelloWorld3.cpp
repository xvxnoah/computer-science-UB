/*
 * 
 * 
 * 
 */
#include <iostream>

using namespace std;

void helloWorld3()
{
    string name;
    cout << "What is your name? ";
    getline(cin, name);
    cout << "Hello, " << name << "!\n";
}
