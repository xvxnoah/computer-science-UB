/*
 * 
 * 
 * 
 */

/* 
 * File:   main.cpp
 * Author: noahmv
 *
 * Created on 24 de febrero de 2021, 13:40
 */

#include <cstdlib>
#include <string>
#include <vector>

using namespace std;
#include "Person.h"



int main(int argc, char** argv) {
    const int PERSON_SZ = 4;
    vector<Person *> people;
    cout <<"Inici del programa" << endl;
    
    string names[] = {"Jim", "Fred", "Harry", "Linda"};
    int ages[] = {23, 35, 52, 59};
    
    for(int i = 0; i < PERSON_SZ; i++){
        Person * a = new Person(names[i], ages[i]);
        a->print();     //(*a).metode() == a->metode()
        people.push_back(a);
    }
    cout<<"Imprimint el vector" << endl;
    
    for(std::vector<Person*>::iterator it = people.begin(); it != people.end(); ++it){
        (*it)->print();
    }
    cout<<"Final del programa" << endl;

    return 0;
}

