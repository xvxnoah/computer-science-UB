/* 
 * File:   Person.h
 * Author: noahmv
 *
 * Created on 24 de febrero de 2021, 13:40
 */

#ifndef PERSON_H
#define PERSON_H
#include <iostream>
#include <string>

using namespace std;

class Person {
public:
    Person(string n, int a); //al .h no fa falta possar nom a les variables.Inicialitza els atributs amb els paràmetres rebuts
    string get_name()const; //const ens fa que només sigui de consulta, no de canvi. Els getters normalment són const perquè només consultem. Retorna el nom de la persona
    int get_age()const; //retorna l'edat de la persona
    void increment_age(); //incrementa una unitat l'edat de la persona
    void print()const; //imprimeix per pantalla les dades de la persona
    
private:
    string name;
    int age;

};

#endif /* PERSON_H */

