/* 
 * File:   Person.cpp
 * Author: Noah
 * 
 * Created on 24 de febrero de 2021, 13:40
 */

#include "Person.h"
#include <iostream>
#include <vector>
#include <string>

using namespace std;


Person::Person(string n, int a) {
    name = n;
    age = a;
}

string Person::get_name()const{
    return name;
}

void Person::increment_age(){
    age += 1;
}

void Person::print() const{
    cout << "Nom:" << name << " i la seva edat és " << age << endl;
}

