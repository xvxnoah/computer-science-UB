/* 
 * File:   main.cpp
 * Author: Noah Márquez
 */

/*
 * Quins tipus de fitxers tens a la carpeta del teu ordinador del projecte?
 * Només tinc un arxiu main.cpp a la carpeta Source Files del meu projecte.
 * 
 * A la carpeta de Source Files tinc el main.cpp
 * A la carpeta Header Files no hi ha res.
 * A la carpeta Resource Files no hi ha res.
 * A la Test Files no hi ha res.
 * A la Important Files hi ha un arxiu anomenat Makefile.
 */

#include <cstdlib>
#include <iostream>
#include <string>

using namespace std;

int main(int argc, char** argv) {
    string nom;
    int option;
    string arr_options[] = {"Sortir", "Benvinguda"};

    cout << "Hola, com et dius? ";
    cin>> nom;

    do {
        cout << "Hola " << nom << ", que vols fer?" << endl;
        for (int i = 0; i < 2; i++) {
            cout << (i+1) << ". " << arr_options[i] << endl;
        }

        cin>>option;

        while (option != 1 && option != 2) {
            cout << "Opció no vàlida. Introdueix un altre nombre " << endl;
            cout << "Hola " << nom << ", que vols fer?" << endl;
            for (int i = 0; i < 2; i++) {
                cout << (i+1) << ". " << arr_options[i] << endl;
            }
            cin>>option;
        }
        if (option != 1) {
            cout << "Benvingut/da a l'assignatura d'estructura de dades " << nom << endl;
        } else {
            cout << "Fins a la propera " << nom << endl;
        }

    } while (option != 1);

    return 0;
}

