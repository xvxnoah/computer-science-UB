/* 
 * File:   Rectangle.cpp
 * Author: Noah Márquez
 */

#include "Rectangle.h"
#include "Quadrilateral.h"
#include <iostream>
#include <stdexcept>

using namespace std;

Rectangle::Rectangle(float b, float h) : Quadrilateral(b) {
    cout << "Constructor de Rectangle" << endl;
    
    height = h;
    
    if (b <= 0 || h <= 0) {
        throw invalid_argument("");
    }
}

Rectangle::~Rectangle(){
}

float Rectangle::getArea() {
    return (base * height);
}

float Rectangle::getPerimeter() {
    return (base * 2)+(height * 2);
}

void Rectangle::print() {
    cout << "Rectangle (" << base << ", " << height << ")" << endl;
}


