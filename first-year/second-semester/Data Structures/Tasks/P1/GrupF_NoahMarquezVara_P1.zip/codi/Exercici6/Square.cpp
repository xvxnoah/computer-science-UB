/* 
 * File:   Square.cpp
 * Author: Noah Márquez
 */

#include "Square.h"
#include "Quadrilateral.h"
#include <iostream>
#include <stdexcept>

using namespace std;

Square::Square(float b) : Quadrilateral(b) {
    cout << "Constructor de Square" << endl;
    
    if(b <= 0){
        throw invalid_argument("");
    }
}

Square::~Square(){
}

float Square::getArea() {
    return(base * base);
}

float Square::getPerimeter(){
    return(base * 4);
}

void Square::print(){
    cout << "Square (" << base << ")"<<endl;
}


