/* 
 * File:   main.cpp
 * Author: Noah Márquez
 */

/* a) Què ens permet fer l'herència que no podríem fer altrament?
 *  L'herència ens permet la reuasabilitat de variables i funcionalitats que ja
 *  han estat definides en altres classes.
 * 
 * b) Que passa si getArea() de la classe Quadrilateral no és virtual? Perquè?
 *  Si getArea() de la classe Quadrilateral no és virtual no ens seria possible fer
 *  la suma de les àrees possat que el vector és format per una sèrie d'objectes
 *  de tipus Quadrilateral i al possar getArea() com a virtual, permetem el 
 *  polimorfisme per tal de que les classes filles pugin fer ús d'aquest mètode.
 * 
 * c) Perquè els constructors i destructors els hem de cridar a les classes derivades i no a la classe base?
 *  Perquè les classes derivades no hereten el destructor de la seva classe base.
 * 
 * d) Es podria fer que getArea()i getPerimetre() fos només un mètode de la classe
 *    "Quadrilateral"?
 *  No es podria fer ja que getArea() i getPerimetre() funcionen de manera diferent
 *  segons estiguem tractant un Square o un Rectangle.
 * 
 * e) Anomena els membres de dades definits en els teus programes i digues a quina
 * classe pertanyen. Explica les decisions de visibilitat de cadascun
 *  protected float base (Quadrilateral), private float height (Rectangle),
 *  private vector<Quadrilateral*> v (QuadrilateralContainer).
 *  
 *  En la classe mare declaro un float base amb visibilitat protected per tal de
 *  que les classes filles puguin accedir-hi. En canvi, els altres membres de dades
 *  els declaro private, perquè no necessitem que cap classe derivada tingui accès
 *  i tampoc volem que es pugui accedir externament.
 * 
 * f) L'iterador que recorre les figures, quant s'incrementa cada cop? Perquè?
 *  L'iterador s'incrementa en un, tantes vegades com figures hagi de recòrrer.
 */

#include <cstdlib>
#include <iostream>
#include <vector>
#include <string>
#include <fstream>

#include "Rectangle.h"
#include "Square.h"
#include "Quadrilateral.h"
#include "QuadrilateralContainer.h"

using namespace std;

void figura(int &comptQuadrat, int &comptRect, QuadrilateralContainer *container) {
    float base, altura;
    char lletra;

    do {
        cout << "(S)quare/ (R)ectangle? ";
        cin >> lletra;
    } while (lletra != 'R' && lletra != 'S');

    if (lletra == 'S') {
        cout << "Quadrat " << comptQuadrat + 1 << endl;

        cout << "Base? ";
        cin >> base;

        try {
            Square* quadrat = new Square(base);
            try {
                container->addQuadrilateral(quadrat);
                quadrat->print();
                cout << "L'àrea d'aquest Quadrat és de " << quadrat->getArea() << endl;
                cout << "El perímetre d'aquest Quadrat és de " << quadrat->getPerimeter() << endl;
                comptQuadrat++;
            } catch (const invalid_argument& e) {
                cout << "El vector com a màxim pot guardar 10 figures. Has arribat al límit." << endl;
                cout << "\n";
                delete quadrat;
            }

        } catch (const invalid_argument& e) {
            cout << "Atenció: aquest valor no és acceptat";
            cout << "\n";
        }

    } else {
        cout << "Rectangle " << comptRect + 1 << endl;

        cout << "Base? ";
        cin >> base;

        cout << "Altura? ";
        cin >> altura;

        try {
            Rectangle* rectangle = new Rectangle(base, altura);
            try {
                container->addQuadrilateral(rectangle);
                rectangle->print();
                cout << "L'àrea d'aquest Rectangle és de " << rectangle->getArea() << endl;
                cout << "El perímetre d'aquest Rectangle és de " << rectangle->getPerimeter() << endl;
                comptRect++;
            } catch (const invalid_argument& e) {
                cout << "El vector com a màxim pot guardar 10 figures. Has arribat al límit." << endl;
                cout << "\n";
                delete rectangle;
            }

        } catch (const invalid_argument& e) {
            cout << "Atenció: aquest valor no és acceptat";
            cout << "\n";
        }

    }

    cout << "\n";
}

void quadratFyle(int &comptQuadrat, float base, QuadrilateralContainer *container) {
    try {
        Square* quadrat = new Square(base);
        try {
            container->addQuadrilateral(quadrat);
            quadrat->print();
            cout << "L'àrea d'aquest Quadrat és de " << quadrat->getArea() << endl;
            cout << "El perímetre d'aquest Quadrat és de " << quadrat->getPerimeter() << endl;
            comptQuadrat++;
        } catch (const invalid_argument& e) {
            cout << "El vector com a màxim pot guardar 10 figures. Has arribat al límit." << endl;
            cout << "\n";
            delete quadrat;
        }

    } catch (const invalid_argument& e) {
        cout << "Atenció: aquest valor no és acceptat";
        cout << "\n";
    }

    cout << "\n";
}

void rectangleFyle(int &comptRect, int base, int altura, QuadrilateralContainer *container) {
    try {
        Rectangle* rectangle = new Rectangle(base, altura);
        try {
            container->addQuadrilateral(rectangle);
            rectangle->print();
            cout << "L'àrea d'aquest Rectangle és de " << rectangle->getArea() << endl;
            cout << "El perímetre d'aquest Rectangle és de " << rectangle->getPerimeter() << endl;
            comptRect++;
        } catch (const invalid_argument& e) {
            cout << "El vector com a màxim pot guardar 10 figures. Has arribat al límit." << endl;
            cout << "\n";
            delete rectangle;
        }

    } catch (const invalid_argument& e) {
        cout << "Atenció: aquest valor no és acceptat";
        cout << "\n";
    }

    cout << "\n";
}

int main(int argc, char** argv) {
    int option;
    int comptQuadrat = 0;
    int comptRect = 0;
    vector<string> opcions{"1. Sortir", "2. Afegir figura", "3. Llegir fitxer", "4. Glossari de figures", "5. Suma de totes les àrees"};
    ifstream meu_fitxer;
    float dada1, dada2;
    char tipus;
    string fitxer;
    QuadrilateralContainer *container = new QuadrilateralContainer();

    do {
        cout << "Hola, què vols fer? " << endl;

        for (int i = 0; i < opcions.size(); i++) {
            cout << opcions[i] << endl;
        }
        cin>>option;

        while (option != 1 && option != 2 && option != 3 && option != 4 && option != 5) {
            cout << "Opció no vàlida. Introdueix un altre nombre " << endl;
            for (int i = 0; i < opcions.size(); i++) {
                cout << opcions[i] << endl;
            }
            cin>>option;
        }

        switch (option) {
            case 1:
                cout << "Fins a la propera" << endl;
                cout << "\n";
                container->~QuadrilateralContainer();
                break;
            case 2:
                figura(comptQuadrat, comptRect, container);
                break;
            case 3:
                cout << "Ruta al fitxer: " << endl;
                cin >> fitxer;
                cout << "Reading file " << fitxer << "..." << endl;
                meu_fitxer.open(fitxer, ios::in); //Obrim l'arxiu em mode lectura.
                while (!meu_fitxer.eof()) {
                    meu_fitxer >> tipus;
                    if (tipus == 'R') {
                        meu_fitxer >> dada1 >> dada2;
                        rectangleFyle(comptRect, dada1, dada2, container);
                    } else if (tipus == 'S') {
                        meu_fitxer >> dada1;
                        quadratFyle(comptQuadrat, dada1, container);
                    }
                }
                meu_fitxer.close();
                break;
            case 4:
                cout << "Tens " << comptQuadrat << " quadrats i " << comptRect << " rectangles." << endl;
                cout << "\n";
                break;
            case 5:
                container->getAreas();
                break;
        }

    } while (option != 1);

    return 0;
}