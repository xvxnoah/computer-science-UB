/* 
 * File:   Quadrilateral.h
 * Author: Noah Márquez
 */

#ifndef QUADRILATERAL_H
#define QUADRILATERAL_H

class Quadrilateral {
public:
    Quadrilateral();
    Quadrilateral(float);
    virtual float getArea();
    virtual float getPerimeter();
    virtual void print();
    ~Quadrilateral();
    
protected:
    float base;
};

#endif /* QUADRILATERAL_H */
