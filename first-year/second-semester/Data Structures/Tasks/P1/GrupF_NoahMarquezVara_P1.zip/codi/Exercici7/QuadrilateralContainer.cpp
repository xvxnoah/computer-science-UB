/* 
 * File:   QuadrilateralContainer.cpp
 * Author: Noah Márquez
 */

#include "QuadrilateralContainer.h"
#include "Quadrilateral.h"
#include <iostream>
#include <vector>

using namespace std;

QuadrilateralContainer::QuadrilateralContainer() {
    v = vector<Quadrilateral*> ();
}

void QuadrilateralContainer::addQuadrilateral(Quadrilateral* q){
    if(v.size() < 10){
        v.push_back(q);
    }
    else{
        throw invalid_argument("");
    }
}

float QuadrilateralContainer::getAreas(){
    float a = 0;
    
    for(vector<Quadrilateral*>::iterator it = v.begin(); it != v.end(); ++it){
        Quadrilateral* figura = *it;
        a += figura->getArea();
    }
    
    cout << "La suma de les àrees dels quadrats i rectangles continguts en el vector és: " << a << endl;
    cout << "\n";
    return a;
}

QuadrilateralContainer::~QuadrilateralContainer() {
    for(vector<Quadrilateral*>::iterator it = v.begin(); it != v.end(); ++it){
        delete (*it);
    }
    cout << "Destructor de QuadrilateralContainer" << endl;
    cout << "\n";
}

