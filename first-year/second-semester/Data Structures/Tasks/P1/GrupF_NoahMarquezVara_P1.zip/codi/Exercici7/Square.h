/* 
 * File:   Square.h
 * Author: Noah Márquez
 */

#ifndef SQUARE_H
#define SQUARE_H
#include "Quadrilateral.h"

class Square : public Quadrilateral {
public:
    Square();
    Square(float);
    float getArea();
    float getPerimeter();
    void print();
    ~Square();
};

#endif /* SQUARE_H */

