/* 
 * File:   Quadrilateral.cpp
 * Author: Noah Márquez
 */

#include "Quadrilateral.h"
#include <iostream>
using namespace std;

Quadrilateral::Quadrilateral(float b) {
    base = b;
    
    cout << "Constructor de Quadrilateral" << endl;
}

Quadrilateral::Quadrilateral() {
}

Quadrilateral::~Quadrilateral(){
    cout << "Destructor de Quadrilateral" << endl;
}

float Quadrilateral::getArea(){
    return 0;
}

float Quadrilateral::getPerimeter(){
    return 0;
}

void Quadrilateral::print(){
    
}


