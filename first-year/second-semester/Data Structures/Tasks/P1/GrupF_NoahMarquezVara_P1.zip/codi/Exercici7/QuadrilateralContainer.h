/* 
 * File:   QuadrilateralContainer.h
 * Author: Noah Márquez
 */

#ifndef QUADRILATERALCONTAINER_H
#define QUADRILATERALCONTAINER_H
#include <vector>
#include "Quadrilateral.h"
using namespace std;

class QuadrilateralContainer {
public:
    QuadrilateralContainer();
    void addQuadrilateral (Quadrilateral*);
    float getAreas();
    
    virtual ~QuadrilateralContainer();
    
private:
    vector<Quadrilateral*> v;
};

#endif /* QUADRILATERALCONTAINER_H */

