/* 
 * File:   Rectangle.h
 * Author: Noah Márquez
 */

#ifndef RECTANGLE_H
#define RECTANGLE_H
#include "Quadrilateral.h"

class Rectangle : public Quadrilateral {
public:
    Rectangle(float, float);
    float getArea();
    float getPerimeter();
    void print();
   ~Rectangle();
   
private:
    float height;

};

#endif /* RECTANGLE_H */

