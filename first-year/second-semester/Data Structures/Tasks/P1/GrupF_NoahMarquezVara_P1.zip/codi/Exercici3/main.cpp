/* 
 * File:   main.cpp
 * Author: Noah Márquez
 */

#include <cstdlib>
#include <iostream>
#include "Square.h"
#include <vector>
#include <stdexcept>

using namespace std;

void quadrat(int &comptador){
    int base;
    
    cout << "Quadrat "<< comptador << endl;
    
    
    cout << "Base? ";
    cin >> base;
    
    try{
        Square quadrat(base);
        quadrat.print();
        cout << "L'àrea d'aquest Quadrat és de " << quadrat.getArea() << endl;
        cout << "El perímetre d'aquest Quadrat és de " << quadrat.getPerimetre() << endl;
        comptador++;
    }
    catch(const invalid_argument& e){
           cout << "Atenció: aquest valor no és acceptat."; 
           cout << "\n";
        
    }
    
    cout << "\n";
}

int main() {
    int option;
    int comptador = 1;
    vector<string> opcions{"1. Sortir", "2. Introduir quadrat"};

    do {
        cout << "Hola, què vols fer? " << endl;

        for (int i = 0; i < opcions.size(); i++) {
            cout << opcions[i] << endl;
        }
        cin>>option;

        while (option != 1 && option != 2) {
            cout << "Opció no vàlida. Introdueix un altre nombre " << endl;
            for (int i = 0; i < opcions.size(); i++) {
                cout << opcions[i] << endl;
            }
            cin>>option;
        }

        switch (option) {
            case 1:
                cout << "Fins a la propera";
                break;
            case 2:
                quadrat(comptador);
                break;
        }
    } while(option != 1);



    return 0;
}

