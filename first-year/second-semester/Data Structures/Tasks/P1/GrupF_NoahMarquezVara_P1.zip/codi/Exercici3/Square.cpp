/* 
 * File:   Square.cpp
 * Author: Noah Márquez
 */

#include "Square.h"
#include <iostream>
#include <stdexcept>

using namespace std;

Square::Square() {
}

Square::Square(int b) {
    base = b;
    
    if(base <= 0){
        throw invalid_argument("");
    }
}

int Square::getArea() {
    return(base * base);
}

int Square::getPerimetre(){
    return(base * 4);
}

void Square::print(){
    cout << "Square (" << base << ")"<<endl;
}


