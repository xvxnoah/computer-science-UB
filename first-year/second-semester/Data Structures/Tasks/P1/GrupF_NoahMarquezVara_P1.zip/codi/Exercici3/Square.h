/* 
 * File:   Square.h
 * Author: Noah Márquez
 */

#ifndef SQUARE_H
#define SQUARE_H

class Square {
private:
    int base;
public:
    Square();
    Square(int);
    int getArea();
    int getPerimetre();
    void print();


};

#endif /* SQUARE_H */

