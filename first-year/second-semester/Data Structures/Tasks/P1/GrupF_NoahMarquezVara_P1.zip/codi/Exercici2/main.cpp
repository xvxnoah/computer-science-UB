/* 
 * File:   main.cpp
 * Author: Noah Márquez
 */

#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>

using namespace std;

int escollida(int &option, string nom) {
    vector<string> opcions{"1. Sortir", "2. Benvinguda", "3. Redefinir nom"};

    for (int i = 0; i < opcions.size(); i++) {
        cout << opcions[i] << endl;
    }
    cin>>option;

    while (option != 1 && option != 2 && option != 3) {
        cout << "Opció no vàlida. Introdueix un altre nombre " << endl;
        cout << "Hola " << nom << ", que vols fer?" << endl;
        for (int i = 0; i < opcions.size(); i++) {
            cout << opcions[i] << endl;
        }
        cin>>option;
    }
    return option;
}

int main(int argc, char** argv) {
    string nom;
    int option;


    cout << "Hola, com et dius? ";
    cin>> nom;

    do {
        cout << "Hola " << nom << ", que vols fer?" << endl;
        option = escollida(option, nom);

        switch (option) {
            case 1:
                cout << "Fins a la propera " << nom << endl;
                break;
            case 2:
                cout << "Benvingut/da a l'assignatura d'estructura de dades " << nom << endl;
                break;
            case 3:
                cout << "Hola, com et dius? ";
                cin >> nom;
        }
    } while (option != 1);

    return 0;
}

