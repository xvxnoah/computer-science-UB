/* 
 * File:   Rectangle.h
 * Author: Noah Márquez
 */

#ifndef RECTANGLE_H
#define RECTANGLE_H
#include <string>

class Rectangle {
public:
    Rectangle();
    Rectangle(float);
    Rectangle(float, float);
    float getArea(char);
    float getPerimetre(char);
    void print(char);
    
private:
    float base;
    float height;

};

#endif /* RECTANGLE_H */

