/* 
 * File:   Rectangle.cpp
 * Author: Noah Márquez
 */

#include "Rectangle.h"
#include <iostream>
using namespace std;

Rectangle::Rectangle() {
}

Rectangle::Rectangle(float b) {
    base = b;
    
    if(base <= 0){
        throw invalid_argument("");
    }
}

Rectangle::Rectangle(float b, float a) {
    base = b;
    height = a;
    
    if(base <= 0 || height <= 0){
        throw invalid_argument("");
    }
}

float Rectangle::getArea(char a) {
    if (a == 'S') {
        return (base * base);
    } else {
        return (base * height);
    }

}

float Rectangle::getPerimetre(char b) {
    if (b == 'S') {
        return (base * 4);
    } else {
        return (base * 2)+(height * 2);
    }

}

void Rectangle::print(char c) {
    if (c == 'S') {
        cout << "Square (" << base << ")" << endl;
    }
    else{
        cout << "Rectangle (" << base << ", " << height << ")" << endl;
    }

}


