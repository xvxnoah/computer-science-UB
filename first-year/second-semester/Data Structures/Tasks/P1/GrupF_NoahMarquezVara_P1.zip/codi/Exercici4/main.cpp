/* 
 * File:   main.cpp
 * Author: Noah Márquez
 */

#include <cstdlib>
#include <iostream>
#include <vector>
#include <string>

#include "Rectangle.h"

using namespace std;

void figura(int &comptQuadrat, int &comptRect) {
    float base, altura;
    char lletra;

    do {
        cout << "(S)quare/ (R)ectangle? ";
        cin >> lletra;
    } while (lletra != 'S' && lletra != 'R');

    if (lletra == 'S') {
        cout << "Quadrat " << comptQuadrat + 1 << endl;
        cout << "Base? ";
        cin >> base;

        try {
            Rectangle quadrat(base);
            quadrat.print(lletra);
            cout << "L'àrea d'aquest Quadrat és de " << quadrat.getArea(lletra) << endl;
            cout << "El perímetre d'aquest Quadrat és de " << quadrat.getPerimetre(lletra) << endl;
            comptQuadrat++;
        } catch (const invalid_argument& e) {
            cout << "Atenció: aquest valor no és acceptat";
            cout << "\n";
        }

    } else {
        cout << "Rectangle " << comptRect + 1 << endl;
        cout << "Base? ";
        cin >> base;

        cout << "Altura? ";
        cin >> altura;

        try {
            Rectangle rectangle(base, altura);
            rectangle.print(lletra);
            cout << "L'àrea d'aquest Rectangle és de " << rectangle.getArea(lletra) << endl;
            cout << "El perímetre d'aquest Rectangle és de " << rectangle.getPerimetre(lletra) << endl;
            comptRect++;
        } catch (const invalid_argument& e) {
            cout << "Atenció: aquest valor no és acceptat";
            cout << "\n";
        }

    }

    cout << "\n";
}

int main(int argc, char** argv) {
    int option;
    int comptQuadrat = 0;
    int comptRect = 0;
    vector<string> opcions{"1. Sortir", "2. Afegir figura", "3. Glossari de figures"};

    do {
        cout << "Hola, què vols fer? " << endl;

        for (int i = 0; i < opcions.size(); i++) {
            cout << opcions[i] << endl;
        }
        cin>>option;

        while (option != 1 && option != 2 && option != 3) {
            cout << "Opció no vàlida. Introdueix un altre nombre " << endl;
            for (int i = 0; i < opcions.size(); i++) {
                cout << opcions[i] << endl;
            }
            cin>>option;
        }

        switch (option) {
            case 1:
                cout << "Fins a la propera";
                break;
            case 2:
                figura(comptQuadrat, comptRect);
                break;
            case 3:
                cout << "Tens " << comptQuadrat << " quadrats i " << comptRect << " rectangles." << endl;
                cout << "\n";
                break;
        }

    } while (option != 1);

    return 0;
}

