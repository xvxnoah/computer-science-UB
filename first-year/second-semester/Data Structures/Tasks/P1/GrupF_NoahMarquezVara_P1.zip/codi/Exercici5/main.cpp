/* 
 * File:   main.cpp
 * Author: Noah Márquez
 */

#include <cstdlib>
#include <iostream>
#include <vector>
#include <string>
#include <fstream>

#include "Rectangle.h"

using namespace std;

void figura(int &comptQuadrat, int &comptRect) {
    float base, altura;
    char lletra;

    do {
        cout << "(S)quare/ (R)ectangle? ";
        cin >> lletra;
    } while (lletra != 'R' && lletra != 'S');


    if (lletra == 'S') {
        cout << "Quadrat " << comptQuadrat + 1 << endl;


        cout << "Base? ";
        cin >> base;

        try {
            Rectangle quadrat(base);
            quadrat.print(lletra);
            cout << "L'àrea d'aquest Quadrat és de " << quadrat.getArea(lletra) << endl;
            cout << "El perímetre d'aquest Quadrat és de " << quadrat.getPerimetre(lletra) << endl;
            comptQuadrat++;
        } catch (const invalid_argument& e) {
            cout << "Atenció: aquest valor no és acceptat";
            cout << "\n";
        }

    } else {
        cout << "Rectangle " << comptRect + 1 << endl;


        cout << "Base? ";
        cin >> base;

        cout << "Altura? ";
        cin >> altura;

        try {
            Rectangle rectangle(base, altura);
            rectangle.print(lletra);
            cout << "L'àrea d'aquest Rectangle és de " << rectangle.getArea(lletra) << endl;
            cout << "El perímetre d'aquest Rectangle és de " << rectangle.getPerimetre(lletra) << endl;
            comptRect++;
        } catch (const invalid_argument& e) {
            cout << "Atenció: aquest valor no és acceptat";
            cout << "\n";
        }

    }

    cout << "\n";
}

void quadratFyle(int &comptQuadrat, float base) {
    try {
        Rectangle quadrat(base);
        quadrat.print('S');
        cout << "L'àrea d'aquest Quadrat és de " << quadrat.getArea('S') << endl;
        cout << "El perímetre d'aquest Quadrat és de " << quadrat.getPerimetre('S') << endl;
        comptQuadrat++;
    } catch (const invalid_argument& e) {
        cout << "Atenció: aquest valor no és acceptat";
        cout << "\n";
    }

    cout << "\n";
}

void rectangleFyle(int &comptRect, float base, float altura) {
    try {
        Rectangle rectangle(base, altura);
        rectangle.print('R');
        cout << "L'àrea d'aquest Rectangle és de " << rectangle.getArea('R') << endl;
        cout << "El perímetre d'aquest Rectangle és de " << rectangle.getPerimetre('R') << endl;
        comptRect++;
    } catch (const invalid_argument& e) {
        cout << "Atenció: aquest valor no és acceptat";
        cout << "\n";
    }

    cout << "\n";
}

int main(int argc, char** argv) {
    int option;
    int comptQuadrat = 0;
    int comptRect = 0;
    vector<string> opcions{"1. Sortir", "2. Afegir figura", "3. Llegir fitxer", "4. Glossari de figures"};
    ifstream meu_fitxer;
    float dada1, dada2;
    char tipus;
    string fitxer;

    do {
        cout << "Hola, què vols fer? " << endl;

        for (int i = 0; i < opcions.size(); i++) {
            cout << opcions[i] << endl;
        }
        cin>>option;

        while (option != 1 && option != 2 && option != 3 && option != 4) {
            cout << "Opció no vàlida. Introdueix un altre nombre " << endl;
            for (int i = 0; i < opcions.size(); i++) {
                cout << opcions[i] << endl;
            }
            cin>>option;
        }

        switch (option) {
            case 1:
                cout << "Fins a la propera";
                break;
            case 2:
                figura(comptQuadrat, comptRect);
                break;
            case 3:
                cout << "Ruta al fitxer: " << endl;
                cin >> fitxer;
                cout << "Reading file " << fitxer << "..." << endl;
                meu_fitxer.open(fitxer, ios::in); //Obrim l'arxiu em mode lectura.
                while (!meu_fitxer.eof()) {
                    meu_fitxer >> tipus;
                    if (tipus == 'R') {
                        meu_fitxer >> dada1 >> dada2;
                        rectangleFyle(comptRect, dada1, dada2);
                    } else if (tipus == 'S') {
                        meu_fitxer >> dada1;
                        quadratFyle(comptQuadrat, dada1);
                    }
                }
                meu_fitxer.close();
                break;
            case 4:
                cout << "Tens " << comptQuadrat << " quadrats i " << comptRect << " rectangles." << endl;
                cout << "\n";
                break;
        }

    } while (option != 1);

    return 0;
}

