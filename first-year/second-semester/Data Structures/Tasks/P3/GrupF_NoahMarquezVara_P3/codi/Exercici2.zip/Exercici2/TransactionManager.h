#ifndef TRANSACTIONMANAGER_H
#define TRANSACTIONMANAGER_H

#include <string>
#include <iostream>
#include <utility>
#include "Transaction.h"
#include "BinarySearchTree.h"

/*-----------------------------------------------------------------------------
 * COST TEORIC DELS MÈTODES:
 *
 * TransactionManager (constructor amb paràmetres per defecte): O(1)
 * TransactionManager (constructor amb paràmetres amb la ruta del fitxer): O(1)
 * TransactionManager (constructor còpia): O(n) on n = nombre d'elements que hi ha a orig
 * ~TransactionManager : O(n) on n = nombre d'elements a l'arbre
 * loadFromFile: O(1)
 * showAll: O(n) en el pitjor cas, O(log(n)) casos normals
 * showAllReverse: O(n) en el pitjor cas, O(log(n)) casos normals
 * showOldest: O(n) en el pitjor cas, O(log(n)) casos normals
 * showNewest: O(n) en el pitjor cas, O(log(n)) casos normals
 * feesInTotal: O(n) en el pitjor cas, O(log(n)) casos normals
 * feesSinceTime: O(n) en el pitjor cas, O(log(n)) casos normals
 * feesInTimeInterval: O(n) en el pitjor cas, O(log(n)) casos normals
 * feesFromFile: O(n) en el pitjor cas, O(log(n)) casos normals
 * showAllAux: igual que showAll
 * showAllReverseAux: igual que showAllReverse
 * feesInTotalAux: igual que feesInTotal
 * feesSinceTimeAux: igual que feesSinceTime
 * feesInTimeIntervalAux: igual que feesInTimeInterval
 * calculateFeesInNode: O(n) en el pitjor cas (si hi ha moltes transaccions al vector)
 * ----------------------------------------------------------------------------
 */

class TransactionManager : protected BinarySearchTree<string, Transaction> {
public:
    TransactionManager(float buyingFee = 0.02, float sellingFee = 0.03); //constructor amb paràmetres
    TransactionManager(string file_path, float buyingFee = 0.02, float sellingFee = 0.03); //constructor fitxer
    TransactionManager(const TransactionManager &orig); //constructor còpia
    virtual ~TransactionManager(); //destructor

    void loadFromFile(string file_path); //carrega un fitxer a l'arbre a partir de la ruta d'un fitxer de transaccions

    void showAll() const; //imprimeix les transaccions en ordre temporal (es demana quantes transaccions es volen imprimir)

    void showAllReverse() const; //imprimeix les transaccions en ordre invers (es demana quantes transaccions es volen imprimir)

    void showOldest() const; //imprimeix les transaccions de l'instant de temps més antic

    void showNewest() const; //imprimeix les transaccions de l'instant de temps més recent

    float feesInTotal() const; //retorna la quantitat de comissions guanyades pel broker

    float feesSinceTime(string date) const; //retorna la comissió guanyada en totes les transaccions a partir d'un determinat instant de temps

    float feesInTimeInterval(pair<string, string> interval) const; //retorna la comissió guanyada en totes les transaccions en un interval de temps

    float feesFromFile(string file_path) const; //mètode per mostrar el balanç de transaccions d'unes dates donades en
    //un fitxer

private:
    float sellingFee;
    float buyingFee;

    //mètode auxiliar del mètode showAll per fer recursió
    void showAllAux(const BinaryTreeNode<string, Transaction> *aux, int &compt) const;

    //mètode auxiliar del mètode showAllReverse per fer recursió
    void showAllReverseAux(const BinaryTreeNode<string, Transaction> *aux, int &compt) const;

    //mètode auxiliar del mètode feesInTotal per fer recursió
    float feesInTotalAux(const BinaryTreeNode<string, Transaction> *aux) const;

    //mètode auxiliar del mètode feesSinceTime per fer recursió
    float feesSinceTimeAux(string date, const BinaryTreeNode<string, Transaction> *aux, float &fees) const;

    //mètode auxiliar del mètode feesInTimeInterval per fer recursió
    float feesInTimeIntervalAux(string first, string second, const BinaryTreeNode<string, Transaction> *aux, float &fees) const;

    //mètode auxiliar que farem servir als mètodes on haguem de calcular les fees, així no hem de repetir codi
    float calculateFeesInNode(const BinaryTreeNode<string, Transaction> *node) const;
};

#endif /* TRANSACTIONMANAGER_H */

