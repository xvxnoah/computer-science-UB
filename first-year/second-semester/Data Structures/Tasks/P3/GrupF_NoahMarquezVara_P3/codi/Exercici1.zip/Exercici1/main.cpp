#include <cstdlib>
#include "BinarySearchTree.h"

using namespace std;

int main(int argc, char** argv) {
    try{
        BinarySearchTree<int, int> *tree1 = new BinarySearchTree<int, int>();

        int testKeys[] = {2, 0, 8, 45, 76, 5, 3, 40};
        int testValues[] = {5, 5, 1, 88, 99, 12, 9, 11};

        for(int i = 0; i < sizeof(testKeys)/sizeof(testKeys[0]); i++){
            tree1->add(testKeys[i], testValues[i]);
        }

        cout << "\nPreOrder = { ";
        tree1->showKeysPreorder();
        cout << "}";

        cout << "\nInOrder = { ";
        tree1->showKeysInorder();
        cout << "}";

        cout << "\nPostOrder = { ";
        tree1->showKeysPostorder();
        cout << "}\n\n";

        BinarySearchTree<int, int> *tree2 = new BinarySearchTree<int, int>(*tree1);

        if(tree1->equals(*tree2)){
            cout << "\nCert\n\n";
        }else {
            cout << "\nFals\n\n";
        }

        tree1->add(1, 10);

        if(tree2->equals(*tree1)){
            cout << "\nCert\n";
        }else {
            cout << "\nFals\n";
        }
        
        delete tree1;
    } catch (invalid_argument& e){
        cout << "EXCEPTION: " << e.what() << "\n";
    }
    return 0;
}

