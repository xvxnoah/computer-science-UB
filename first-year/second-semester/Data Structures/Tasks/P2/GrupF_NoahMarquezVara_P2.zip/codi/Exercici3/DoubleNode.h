/* 
 * File:   DoubleNode.h
 * Author: Noah Márquez
 */

#ifndef DOUBLENODE_H
#define DOUBLENODE_H

template <class E>
class DoubleNode {
public:
    DoubleNode();
    DoubleNode(E element);
    const E& getElement() const; //retorna l'element que hi ha guardat al node
    DoubleNode<E>* getNext() const; //retorna l'adreça del següent node o nullptr
    void setNext(DoubleNode<E>* next); //modifica l'adreça del següent per l'adreça rebuda com a paràmetre
    DoubleNode<E>* getPrevious() const; //retorna l'adreça de l'anterior node o nullptr
    void setPrevious(DoubleNode<E>* prev); //modifica l'adreça de l'anterior per l'adreça rebuda com a paràmetre
    
private:
    E element;
    DoubleNode<E>* next;
    DoubleNode<E>* prev;
};
template <class E>
DoubleNode<E>::DoubleNode(){
    prev = next = nullptr;
}

template <class E>
DoubleNode<E>::DoubleNode(E element):DoubleNode(){
    this->element = element;
}

template <class E>
const E& DoubleNode<E>::getElement() const{
    return element;
}

template <class E>
DoubleNode<E>* DoubleNode<E>::getNext() const{
    return next;
}

template <class E>
void DoubleNode<E>::setNext(DoubleNode<E>* next){
    this->next = next;
}

template <class E>
DoubleNode<E>* DoubleNode<E>::getPrevious() const{
    return prev;
}

template <class E>
void DoubleNode<E>::setPrevious(DoubleNode<E>* prev){
    this->prev = prev;
}
#endif /* DOUBLENODE_H */

