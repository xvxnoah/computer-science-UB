/* 
 * File:   main.cpp
 * Author: Noah Márquez
 */

#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>

#include <stdexcept>
#include <exception>
#include "LinkedDeque.h"
#include "Patient.h"

using namespace std;

/**
 * Mètode per eliminar un element de l'inici de la cua i recollir les possibles
 * excepcions.
 * @param linked, LinkedDeque
 */
void eliminarFront(LinkedDeque<Patient>* linked) {
    try {
        cout << "\n";
        linked->dequeueFront();
        cout << "\n";
    } catch (exception const& ex) {
        cerr << "EXCEPTION: " << ex.what() << endl;
    }
}

/**
 * Mètode per eliminar un element del final de la cua i recollir les possibles
 * excepcions.
 * @param linked, LinkedDeque
 */
void eliminarRear(LinkedDeque<Patient>* linked) {
    try {
        cout << "\n";
        linked->dequeueBack();
        cout << "\n";
    } catch (exception const& ex) {
        cerr << "EXCEPTION: " << ex.what() << endl;
    }
}

/**
 * Mètode per obtenir l'element de l'inici de la cua i recollir les possibles
 * excepcions
 * @param linked, LinkedDeque
 */
void front(LinkedDeque<Patient>* linked) {
    try {
        cout << "\n";
        Patient pacient =linked->getFront();
        cout << "Primer pacient de la cua: \n";
        pacient.print();
        cout << "\n";
    } catch (exception const& ex) {
        cerr << "EXCEPTION: " << ex.what() << endl;
    }
}

/**
 * Mètode per obtenir l'element del final de la cua i recollir les possibles
 * excepcions
 * @param linked, LinkedDeque
 */
void rear(LinkedDeque<Patient>* linked) {
    try {
        cout << "\n";
        Patient pacient = linked->getBack();
        cout << "Darrer pacient de la cua \n";
        pacient.print();
        cout << "\n";
    } catch (exception const& ex) {
        cerr << "EXCEPTION: " << ex.what() << endl;
    }
}

/**
 * Mètode per imprimir la llista de pacients i recollir les possibles excepcions
 * @param linked, LinkedDeque
 */
void imprimir(LinkedDeque<Patient>* linked) {
    try {
        cout << "\n";
        linked->print();
    } catch (exception const& ex) {
        cerr << ex.what() << endl;
    }
}

/**
 * Mètode per inserir n entrades de pacients des de teclat (0 per finalitzar)
 * @param linked, LinkedDeque
 */
void entradaPacients(LinkedDeque<Patient>* linked) {
    int numDades;
    string identificador, nom, cognom, estat;

    do {
        cout << "Quantes entrades de pacients vols inserir? (0 per finalitzar)" << endl;
        cin >> numDades;
        //Comprovem que l'input introduït sigui correcte
        while (numDades < 0) {
            cout << "Número incorrecte, introdueix un nombre positiu: " << endl;
            cin >> numDades;
        }
        //bucle per demanar les 4 dades característiques dels pacients
        for (int i = 0; i < numDades; i++) {
            cout << "Indica l'identificador del pacient " << (i + 1) << ": " << endl;
            cin >> identificador;
            cout << "Indica el nom del pacient " << (i + 1) << ": " << endl;
            cin >> nom;
            cout << "Indica el cognom del pacient " << (i + 1) << ": " << endl;
            cin >> cognom;
            cout << "Indica l'estat del pacient " << (i + 1) << ": " << endl;
            cin >> estat;
            
            while(estat != "NOT_OK" && estat != "OK"){
                cout << "L'estat del pacient " << (i + 1) << " no és correcte." << endl;
                cout << "L'estat ha de ser 'OK' o 'NOT_OK'." << endl;
                cin >> estat;
            }

            if (estat == "NOT_OK") { //si l'estat == NOT_OK inserim al davant, altrament inserim al darrere
                Patient pacient(identificador, nom, cognom, estat);
                cout << "\n";
                linked->enqueueFront(pacient);
                cout << "\n";
            } else {
                cout << "\n";
                Patient pacient(identificador, nom, cognom, estat);
                linked->enqueueBack(pacient);
                cout << "\n";
            }
        }

    } while (numDades != 0);
}

/**
 * Mètode per llegir un fitxer amb les entrades de pacients
 * @param linked, LinkedDeque
 */
void llegirFitxer(LinkedDeque<Patient>* linked) {
    string identificador, nom, cognom, estat;
    string fitxer, line;
    ifstream meu_fitxer;

    //Demanem la ruta del fitxer, en el nostre cas 'Pacients.txt'
    cout << "Ruta al fitxer: " << endl;
    cin >> fitxer;
    cout << "Reading file " << fitxer << "..." << endl;
    cout << "\n";
    meu_fitxer.open(fitxer, ios::in); //Obrim arxiu en mode lectura

    //bucle fins al final del fitxer
    while (getline(meu_fitxer, line)) {
        //faig ús de la classe stringstream, ens permet tractar un string com un stream
        stringstream ss(line);
        getline(ss, identificador, ','); //llegim les dades ignorant les comes
        getline(ss, nom, ',');
        getline(ss, cognom, ',');
        getline(ss, estat, ',');

        if (estat == "NOT_OK") { //si l'estat == NOT_OK inserim al davant, altrament inserim al darrere
            Patient pacient(identificador, nom, cognom, estat);
            linked->enqueueFront(pacient);
            cout << "\n";
        } else {
            Patient pacient(identificador, nom, cognom, estat);
            linked->enqueueBack(pacient);
            cout << "\n";
        }
    }
    meu_fitxer.close();
}

int main() {
    int opcio, element;
    vector<string> opcions{"Llegir un fitxer amb les entrades de pacients",
        "Imprimir la cua de pacients", "Eliminar el primer pacient de la cua",
        "Eliminar el darrer pacient de la cua", "Inserir n entrades de pacients des de teclat (0 per finalitzar)",
        "Consultar el primer pacient de la cua", "Consultar el darrer pacient de la cua",
        "Sortir"};

    //crida al constructor
    LinkedDeque<Patient> *linked = new LinkedDeque<Patient>();
    
    do {
        for (int i = 0; i < opcions.size(); i++) {
            cout << (i + 1) << ".  " << opcions[i] << endl;
        }
        cin >> opcio;
        //Bucle per comprovar que la opció introduïda sigui correcte
        while (opcio < 1 || opcio > 8) {
            cout << "Opció no vàlida. Introdueix un altre nombre " << endl;
            for (int i = 0; i < opcions.size(); i++) {
                cout << (i + 1) << ".\t" << opcions[i] << endl;
            }
            cin >> opcio;
        }

        switch (opcio) {
            case 1:
                llegirFitxer(linked);
                break;
            case 2:
                imprimir(linked);
                break;
            case 3:
                eliminarFront(linked);
                break;
            case 4:
                eliminarRear(linked);
                break;
            case 5:
                entradaPacients(linked);
                break;
            case 6:
                front(linked);
                break;
            case 7:
                rear(linked);
                break;
        }
    } while (opcio != 8);
    
    delete linked; //crida al destructor
    return 0;
}

