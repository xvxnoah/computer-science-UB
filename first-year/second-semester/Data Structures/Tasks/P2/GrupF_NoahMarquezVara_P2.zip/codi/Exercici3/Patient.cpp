/* 
 * File:   Patient.cpp
 * Author: Noah Márquez
 */

#include "Patient.h"
#include <iostream>

using namespace std;

Patient::Patient() {
}

Patient::Patient(string identificador, string nom, string cognom, string estat) {
    this->identificador = identificador;
    this->nom = nom;
    this->cognom = cognom;
    this->estat = estat;
}

Patient::~Patient() {
}

void Patient::print() {
    cout << this->identificador << "," << this->nom << "," << this->cognom << "," << this->estat << endl;
}


