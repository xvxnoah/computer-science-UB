/* 
 * File:   Patient.h
 * Author: Noah Márquez
 */

#ifndef PATIENT_H
#define PATIENT_H
#include <string>

using namespace std;

class Patient {
public:
    Patient();
    Patient(string, string, string, string);
    virtual ~Patient();
    void print();
    
private:
    string identificador;
    string nom;
    string cognom;
    string estat;
};

#endif /* PATIENT_H */

