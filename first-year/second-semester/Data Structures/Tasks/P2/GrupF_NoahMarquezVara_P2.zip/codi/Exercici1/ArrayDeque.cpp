/* 
 * File:   ArrayDeque.cpp
 * Author: Noah Márquez
 */

#include "ArrayDeque.h"
#include <stdexcept>
#include <exception>
#include <iostream>

using namespace std;

/**
 * Constructor per paràmetres de la classe ArrayDeque, farem ús d'un Array circular
 * @param mida
 */
ArrayDeque::ArrayDeque(const int mida) {
    _max_size = mida;
    _data = vector<int>(mida);
    cout << "Estructura creada " << endl;
    //Inicialitzem front i rear a -1.
    _front = -1;
    _rear = -1;
}

/**
 * Inserir element a l'inici de la cua
 * @param key
 */
void ArrayDeque::enqueueFront(const int key) {
    if (this->isFull()) {
        throw out_of_range("L'estructura està plena");
    } else {
        // Si la cua està buida.
        if (isEmpty()) {
            _front = _rear = 0;
        }// Si front apunta a la primera posició
        else if (_front == 0) {
            _front = _max_size - 1;
        } else {
            _front--;
        }
        _data[_front] = key;
        cout << "Element " << key << " agregat" << endl;
        ++_size;
    }
}

/**
 * Inserir element al final de la cua
 * @param key
 */
void ArrayDeque::enqueueBack(const int key) {
    if (this->isFull()) {
        throw out_of_range("L'estructura està plena");
    } else {
        // Si la cua està buida
        if (isEmpty()) {
            _front = _rear = 0;
        }// Si rear apunta a l'última posició
        else if (_rear == _max_size - 1) {
            _rear = 0;
        } else {
            _rear++;
        }
        _data[_rear] = key;
        cout << "Element " << key << " agregat" << endl;
        ++_size;
    }
}

/**
 * Treure el primer element de la cua
 */
void ArrayDeque::dequeueFront() {
    if (this->isEmpty()) {
        throw out_of_range("L'estructura està buida");
    } else {
        // Si només hi ha un element
        if (_front == _rear) {
            cout << "Element " << _data[_front] << " eliminat" << endl;
            _front = _rear = -1;
        }// Si front apunta a l'últim element
        else if (_front == _max_size - 1) {
            cout << "Element " << _data[_front] << " eliminat" << endl;
            _front = 0;
        } else {
            cout << "Element " << _data[_front] << " eliminat" << endl;
            _front++;
        }
        --_size;
    }
}

/**
 * Treure el darrer element de la cua
 */
void ArrayDeque::dequeueBack() {
    if (this->isEmpty()) {
        throw out_of_range("L'estructura està buida");
    } else {
        // Si només hi ha un element
        if (_front == _rear) {
            cout << "Element " << _data[_rear] << " eliminat" << endl;
            _front = _rear = -1;
        }// Si rear apunta a l'element en primera posició.
        else if (_rear == 0) {
            cout << "Element " << _data[_rear] << " eliminat" << endl;
            _rear = _max_size - 1;
        } else {
            cout << "Element " << _data[_rear] << " eliminat" << endl;
            _rear--;
        }
        --_size;
    }
}

/**
 * 
 * @return true si la cua està plena. false altrament
 */
bool ArrayDeque::isFull() {
    if ((_front == 0 && _rear == _max_size - 1) || (_front == _rear + 1)) {
        return true;
    } else {
        return false;
    }
}

/**
 * 
 * @return true si la cua està buida, false altrament
 */
bool ArrayDeque::isEmpty() {
    if (_front == -1 && _rear == -1) {
        return true;
    } else {
        return false;
    }
}

/**
 * 
 * @return el primer element de la cua
 */
const int ArrayDeque::getFront() {
    if (this->isEmpty()) {
        throw out_of_range("L'estructura està buida");
    } else {
        return _data[_front];
    }
}

/**
 * 
 * @return el darrer element de la cua
 */
const int ArrayDeque::getBack() {
    if (this->isEmpty()) {
        throw out_of_range("L'estructura està buida");
    } else {
        return _data[_rear];
    }
}

/**
 * Imprimeix tots els elements de l'estructura
 */
void ArrayDeque::print() {
    int i = _front;

    if (this->isEmpty()) {
        cout << "[]" << endl;
    } else {
        cout << "[";
        while (i != _rear) {
            cout << _data[i] << ", ";
            i = (i + 1) % _max_size;
        }
        cout << _data[_rear] << "]" << endl;
    }
}




