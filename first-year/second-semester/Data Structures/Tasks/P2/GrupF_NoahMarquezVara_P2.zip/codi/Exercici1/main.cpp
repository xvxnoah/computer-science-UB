/*
 * File:   main.cpp
 * Author: Noah Márquez
 */

#include <cstdlib>
#include <iostream>
#include <vector>
#include <string>

#include "ArrayDeque.h"
#include <stdexcept>
#include <exception>

using namespace std;

/**
 * Mètode per inserir un element a l'inici de la cua i comprovar les possibles
 * excepcions.
 * @param cua, ArrayDeque
 * @param elem, element a inserir
 */
void inserirFront(ArrayDeque& cua, int elem){
    try{
        cua.enqueueFront(elem);
    } catch(exception const& ex){
        cerr << "EXCEPTION: " << ex.what() << endl;
    }
}

/**
 * Mètode per inserir un element al final de la cua i recollir les possibles
 * excepcions.
 * @param cua, ArrayDeque
 * @param elem, element a inserir
 */
void inserirRear(ArrayDeque& cua, int elem){
    try{
        cua.enqueueBack(elem);
    } catch(exception const& ex){
        cerr << "EXCEPTION: " << ex.what() << endl;
    }
}

/**
 * Mètode per eliminar un element de l'inici de la cua i recollir les possibles
 * excepcions.
 * @param cua, ArrayDeque
 */
void eliminarFront(ArrayDeque& cua){
    try{
        cua.dequeueFront();
    } catch(exception const& ex){
        cerr << "EXCEPTION: " << ex.what() << endl;
    }
}

/**
 * Mètode per eliminar un element del final de la cua i recollir les possibles
 * excepcions.
 * @param cua, ArrayDeque
 */
void eliminarRear(ArrayDeque& cua){
    try{
        cua.dequeueBack();
    } catch(exception const& ex){
        cerr << "EXCEPTION: " << ex.what() << endl;
    }
}

/**
 * Mètode per obtenir l'element de l'inici de la cua i recollir les possibles
 * excepcions
 * @param cua, ArrayDeque
 */
void front(ArrayDeque& cua){
    try{
        cout << cua.getFront() << endl;
    } catch(exception const& ex){
        cerr << "EXCEPTION: " << ex.what() << endl;
    }
}

/**
 * Mètode per obtenir l'element del final de la cua i recollir les possibles
 * excepcions
 * @param cua, ArrayDeque
 */
void rear(ArrayDeque& cua){
    try{
        cout << cua.getBack() << endl;
    } catch(exception const& ex){
        cerr << "EXCEPTION: " << ex.what() << endl;
    }
}

void casProva1() {
    cout << "-----------------------" << endl;
    cout << "    CAS DE PROVA 1:" << endl;
    cout << "-----------------------" << endl;
    ArrayDeque queue1(3);
    
    //testejem els mètodes
    inserirFront(queue1, 10);
    inserirRear(queue1, 20);
    inserirFront(queue1, 30);
    inserirRear(queue1, 40);
    queue1.print();
    
    eliminarFront(queue1);
    inserirRear(queue1, 40);
    queue1.print();
    cout << "\n";
}

void casProva2() {
    cout << "-----------------------" << endl;
    cout << "    CAS DE PROVA 2:" << endl;
    cout << "-----------------------" << endl;
    ArrayDeque queue2(3);
    
    //testejem els mètodes
    inserirFront(queue2, 10);
    front(queue2);
    inserirRear(queue2, 20);
    inserirRear(queue2, 30);
    queue2.print();
    
    eliminarRear(queue2);
    rear(queue2);
    eliminarRear(queue2);
    eliminarFront(queue2);
    eliminarFront(queue2);
    queue2.print();
    cout << "\n";
}

int main() {
    int opcio, element, mida;
    vector<string> opcions{"Inserir element al davant de la cua", "Inserir "
        "element al darrera de la cua", "Treure element pel davant de la cua",
        "Treure element pel darrera de la cua", "Consultar el primer element",
        "Consultar el darrer element", "Imprimir tot el contingut de l’ArrayDeque",
        "Sortir"};
        
    casProva1();
    casProva2();
    
    cout << "Introduiex la mida del ArrayDeque: " << endl;
    cin >> mida;

    //Bucle fins que la mida introduïda sigui correcte
    while (mida <= 0) {
        cout << "Mida incorrecte. Introdueix una nova mida: " << endl;
        cin >> mida;
    }
    //crida al constructor amb la mida introduïda
    ArrayDeque queue(mida);
    
    do {
        for (int i = 0; i < opcions.size(); i++) {
            cout << (i + 1) << ".  " << opcions[i] << endl;
        }
        cin >> opcio;
        
        //Bucle fins que la opció introduïda sigui correcte
        while (opcio < 1 || opcio > 8) {
            cout << "Opció no vàlida. Introdueix un altre nombre " << endl;
            for (int i = 0; i < opcions.size(); i++) {
                cout << (i + 1) << ".\t" << opcions[i] << endl;
            }
            cin >> opcio;
        }

        switch (opcio) {
            case 1:
                cout << "Element a inserir al davant de la cua: " << endl;
                cin >> element;
                inserirFront(queue, element);
                break;
            case 2:
                cout << "Element a inserir al darrere de la cua: " << endl;
                cin >> element;
                inserirRear(queue, element);
                break;
            case 3:
                eliminarFront(queue);
                break;
            case 4:
                eliminarRear(queue);
                break;
            case 5:
                front(queue);
                break;
            case 6:
                rear(queue);
                break;
            case 7:
                queue.print();
                break;
        }
    } while (opcio != 8);
    return 0;
}

