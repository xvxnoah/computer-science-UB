/* 
 * File:   ArrayDeque.h
 * Author: Noah Márquez
 */

#ifndef ARRAYDEQUE_H
#define ARRAYDEQUE_H
#include <stdexcept>

#include <vector>

class ArrayDeque {
public:
    ArrayDeque(const int); // constructor on s'indica la mida
    void enqueueBack(const int key); // inserir al final de la cua
    void dequeueFront(); // eliminar el primer element de la cua
    bool isFull(); // cert si està plena la cua, fals altrament
    bool isEmpty(); //cert si està buida la cua, fals altrament
    void print(); // imprimir tot el contingut de la cua
    const int getFront(); // obtenir el primer element de la cua
    void enqueueFront(const int); // inserir a l'inici de la cua
    void dequeueBack(); // eliminar el darrer element de la cua
    const int getBack(); // obtenir el darrer element de la cua
private:
    int _max_size; // mida màxima de la cua
    int _size; // nombre d'elements actuals de la cua
    std::vector<int> _data; // per guardar els elements de la cua
    int _front; //inici de l'ArrayDeque
    int _rear; //final de l'ArrayDeque
};

#endif /* ARRAYDEQUE_H */

