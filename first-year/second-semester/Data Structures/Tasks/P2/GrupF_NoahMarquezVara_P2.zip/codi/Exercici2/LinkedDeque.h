/* 
 * File:   LinkedDeque.h
 * Author: Noah Márquez
 */

#ifndef LINKEDDEQUE_H
#define LINKEDDEQUE_H

#include "DoubleNode.h"
#include <iostream>
#include <stdexcept>
#include <exception>

using namespace std;

template <class E>
class LinkedDeque {
public:
    LinkedDeque();
    virtual ~LinkedDeque();
    LinkedDeque(const LinkedDeque& q);
    void enqueueFront(const E& element);
    void enqueueBack(const E& element);
    void dequeueFront();
    void dequeueBack();

    bool isEmpty();
    void print();
    const E& getFront();
    const E& getBack();
    int size();

private:
    DoubleNode<E>* _front;
    DoubleNode<E>* _rear;
    int _size;
};

template <class E>
LinkedDeque<E>::LinkedDeque() {
    _size = 0;
    _front = nullptr;
    _rear = nullptr;
}

template <class E>
LinkedDeque<E>::LinkedDeque(const LinkedDeque& q) {
    DoubleNode<E>* newLinkedDeque; //punter per crear un nou DoubleNode
    DoubleNode<E>* actual; //punter per recòrrer la llista

    //si la llista està buida, la nova llista també
    if (q._front == nullptr) {
        _front = _rear = nullptr;
        _size = 0;
    } else {
        actual = q._front; //el punter actual apunta a la llista per ser copiada
        _size = q._size;
        _front = new DoubleNode<E>(actual->getElement());
        _front->setNext(actual->getNext());
        _front->setPrevious(actual->getPrevious());

        _rear = _front;

        actual = actual->getNext();

        while (actual != nullptr) {
            newLinkedDeque = new DoubleNode<E>(actual->getElement());
            newLinkedDeque->setNext(actual->getNext());
            newLinkedDeque->setPrevious(actual->getPrevious());
            _rear->getNext() = newLinkedDeque;
            _rear = newLinkedDeque;
            actual = actual->getNext();
        }
    }
}

template <class E>
LinkedDeque<E>::~LinkedDeque() {
    cout << "Destructor LinkedDeque\n\n";

    DoubleNode<E>* actual = _front;

    //iterem fins que actual sigui == nullptr
    while (actual) {
        DoubleNode<E>* next = actual->getNext();
        delete actual;
        actual = next;
    }
    _size = 0;
}

template <class E>
int LinkedDeque<E>::size() {
    return _size;
}

template <class E>
bool LinkedDeque<E>::isEmpty() {
    //retorna true si la llista està buida
    return size() == 0;
}

template <class E>
void LinkedDeque<E>::enqueueFront(const E& element) {
    //crida al constructor de DoubleNode amb l'element a inserir
    DoubleNode<E>* node = new DoubleNode<E>(element);
    node->setPrevious(nullptr);
    node->setNext(_front);

    //si LinkedDeque està buida
    if (isEmpty()) {
        _rear = _front = node;
    }//Insereix node a _front
    else {
        _front->setPrevious(node);
        _front = node;
    }
    _size++;
    cout << "Element " << element << " agregat" << endl;
}

template <class E>
void LinkedDeque<E>::enqueueBack(const E& element) {
    //crida al constructor de DoubleNode amb l'element a inserir
    DoubleNode<E>* node = new DoubleNode<E>(element);
    node->setPrevious(_rear);
    node->setNext(nullptr);
    
    //si LinkedDeque està buida
    if (isEmpty()) {
        _front = _rear = node;
    }//insereix node a _rear
    else {
        _rear->setNext(node);
        _rear = node;
    }
    _size++;
    cout << "Element " << element << " agregat" << endl;
}

template <class E>
void LinkedDeque<E>::dequeueFront() {
    if (isEmpty()) {
        throw out_of_range("L’estructura està buida");
    }
    //elimina el node desde _front i fa els ajustaments necessaris
    else {
        //si només hi ha un element
        if (_size == 1) {
            cout << "Element " << getFront() << " eliminat" << endl;
            delete _front;
            _front = nullptr;
            _rear = nullptr;
        } else {
            cout << "Element " << getFront() << " eliminat" << endl;
            _front = _front->getNext();
            delete _front->getPrevious();
            _front->setPrevious(nullptr);
        }
        _size--;
    }
}

template <class E>
void LinkedDeque<E>::dequeueBack() {
    if (isEmpty()) {
        throw out_of_range("L’estructura està buida");
    }
    //elimina el node desde _rear i fa els ajustaments necessaris
    else {
        //si només hi ha un element
        if (_size == 1) {
            cout << "Element " << getBack() << " eliminat" << endl;
            delete _rear;
            _rear = nullptr;
            _front = nullptr;
        } else {
            cout << "Element " << getBack() << " eliminat" << endl;
            _rear = _rear->getPrevious();
            delete _rear->getNext();
            _rear->setNext(nullptr);
        }
        _size--;
    }
}

template <class E>
const E& LinkedDeque<E>::getFront() {
    if (isEmpty()) {
        throw out_of_range("L’estructura està buida");
    } else {
        return _front->getElement();
    }
}

template <class E>
const E& LinkedDeque<E>::getBack() {
    if (isEmpty()) {
        throw out_of_range("L’estructura està buida");
    } else {
        return _rear->getElement();
    }
}

template <class E>
void LinkedDeque<E>::print() {
    //si està buida
    if (isEmpty()) {
        cout << "[]" << endl;
    } else {
        //iterem sobre la llista per imprimir el seu contingut
        DoubleNode<E>* temp = new DoubleNode<E>();
        temp = _front;
        cout << "[";
        while (temp != nullptr) {
            if (temp->getNext() == nullptr) {
                cout << temp->getElement();
                temp = temp->getNext();
            } else {
                cout << temp->getElement() << ", ";
                temp = temp->getNext();
            }
        }
        cout << "]\n";
    }
}
#endif /* LINKEDDEQUE_H */

