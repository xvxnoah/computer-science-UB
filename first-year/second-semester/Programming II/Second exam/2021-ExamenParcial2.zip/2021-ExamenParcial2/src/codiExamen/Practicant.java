/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codiExamen;


/**
 *
 * @author lauraigual
 */
public class Practicant extends Empleat{
  
    // NO CAL IMPLEMENTAR-HO
    //implementat perquè no sortís l'error
    public Practicant(String nom, String NIF){
        super(nom, NIF);
    }
}
