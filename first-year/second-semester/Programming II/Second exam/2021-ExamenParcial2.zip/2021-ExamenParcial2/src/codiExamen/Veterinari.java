package codiExamen;

public class Veterinari extends Empleat{
    public Veterinari(String nom, String NIF){
        super(nom, NIF);
    }
 
}
