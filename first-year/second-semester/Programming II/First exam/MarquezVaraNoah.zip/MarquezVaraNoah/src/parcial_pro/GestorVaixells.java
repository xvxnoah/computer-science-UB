package parcial_pro;

public class GestorVaixells {
    public static void main(String[] args) {
        Recorregut recorregut = new Recorregut("Illes Medes");
        Llanxa llanxa1 = new Llanxa("Llanxa", 5, 2);
        recorregut.afegirVaixell(llanxa1);
        
        Llanxa llanxa2 = new Llanxa("Popeye", 5, 2);
        recorregut.afegirVaixell(llanxa2);
        llanxa2.setManteniment(true);
        
        Iot iot = new Iot("Luxe", 20, 10, 1);
        recorregut.afegirVaixell(iot);
        
        System.out.println(recorregut.placesDisponibles());
        
        System.out.println(recorregut.llitsCabina());
    }
}
