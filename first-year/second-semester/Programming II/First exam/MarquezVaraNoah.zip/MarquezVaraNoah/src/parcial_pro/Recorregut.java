package parcial_pro;

import java.util.ArrayList;
import java.util.Iterator;

public class Recorregut {
    private String nom;
    private ArrayList<Vaixell> llista;
    
    public Recorregut(String nom){
        this.nom = nom;
        this.llista = new ArrayList<>();
    }
    
    public void afegirVaixell(Vaixell v){
        llista.add(v);
    }
    
    public int placesDisponibles(){
        int places = 0;
        
        for(Iterator<Vaixell> i = llista.iterator(); i.hasNext();){
            Vaixell v = i.next();
            if(!v.isManteniment()){
                places += v.totalPlacesPassatgers();
            }
        }
        return places;
    }
    
    public int llitsCabina(){
        int llits = 0;
        
        for(Iterator<Vaixell> i = llista.iterator(); i.hasNext();){
            Vaixell v = i.next();
            if(v instanceof Iot && !v.isManteniment()){
                Iot iot = (Iot) v;
                llits += iot.getLlits();
            }
        }
        return llits;
    }
}
