package parcial_pro;

public abstract class Vaixell implements InVaixell{
    private String nom;
    private int seients;
    private float tamany;
    private boolean manteniment;
    
    public Vaixell(String nom, int seients, float tamany){
        this.nom = nom;
        this.seients = seients;
        this.tamany = tamany;
        this.manteniment = false;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getSeients() {
        return seients;
    }

    public void setSeients(int seients) {
        this.seients = seients;
    }

    public float getTamany() {
        return tamany;
    }

    public void setTamany(float tamany) {
        this.tamany = tamany;
    }

    public boolean isManteniment() {
        return manteniment;
    }

    public void setManteniment(boolean manteniment) {
        this.manteniment = manteniment;
    }
    
}
