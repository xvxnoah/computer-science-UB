package parcial_pro;

public class Iot extends Vaixell{
    private int cabinaLlit;
    
    public Iot(String nom, int seients, float tamany, int cabinaLlit){
        super(nom, seients, tamany);
        this.cabinaLlit = cabinaLlit;
    }

    public int getCabinaLlit() {
        return cabinaLlit;
    }

    public void setCabinaLlit(int cabinaLlit) {
        this.cabinaLlit = cabinaLlit;
    }

    public int getLlits(){
        return this.getCabinaLlit() * 4; 
    }
    
    @Override
    public int totalPlacesPassatgers() {
        return this.getSeients() - tripulacio() + this.getLlits();
    }

    @Override
    public int tripulacio() {
        return 5;
    }
}
