package parcial_pro;

public class Llanxa extends Vaixell{
    
    public Llanxa(String nom, int seients, float tamany){
        super(nom, seients, tamany);
    }

    @Override
    public int totalPlacesPassatgers() {
        return this.getSeients() - tripulacio();
    }

    @Override
    public int tripulacio() {
        return 1;
    }
}
