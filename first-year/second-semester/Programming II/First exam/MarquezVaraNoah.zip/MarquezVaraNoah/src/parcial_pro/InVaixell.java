package parcial_pro;

public interface InVaixell {
    
    /**
     *  Permetrà calcular el nombre de places d'un vaixell.
     * @return places
     */
    public int totalPlacesPassatgers();
    
    /**
     * Retornarà el nombre de seients reservats per a la tripulació d'un
     * vaixell
     * @return seients reservats
     */
    public int tripulacio();
}
