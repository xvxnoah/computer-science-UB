package prog2.vista;

public class IniciadorClubUB {
   
    public static void main(String [] args){
        // Creem un objecte de la vista
        VistaClubUB vistaClub = new VistaClubUB();
        
        // Inicialitzem l'execució de la vista
        vistaClub.gestioClubUB();
    }
}
