﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameScript : MonoBehaviour
{
    public Text scoreText;
    public GameObject ball;

    private GameObject[] triggers;

    // Start is called before the first frame update
    void Start()
    {
        for (int i = 0; i < 100; i++) {
	        Instantiate(ball, new Vector3(-5f + 0.5f*(i % 20), 7f + (i/20)*2f, 0f), Quaternion.identity);
	    }
    }

    // Update is called once per frame
    void Update()
    {
        triggers = GameObject.FindGameObjectsWithTag("Trigger");

        int points = 0;

        foreach (GameObject trigger in triggers) {
            //if (trigger.GetComponent<TriggerScript>().staying > 0) {
                points+= trigger.GetComponent<TriggerScript>().staying;
            //}
        }

        //Debug.Log("" + points);

        scoreText.text = "Points: " + points;
    }
}
