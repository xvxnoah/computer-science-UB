using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveSphere : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        transform.position += new Vector3(-2 * Time.deltaTime, 0, 0);
        
    }

    //FixedUpdate to fix the issue of the movement
  /*  private void FixedUpdate()
    {
        transform.position += new Vector3(-2 * Time.deltaTime, 0, 0);
        
    }*/

    //when it collides with something, destroy it
    void OnCollisionEnter(Collision col)
    {
        Debug.Log("In oncollisionenter method");
        Destroy(col.gameObject);
        //GetComponent<ParticleSystem>().Play();
        //Destroy(this.gameObject);
    }
}
