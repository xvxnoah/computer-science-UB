using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Creator : MonoBehaviour
{
    public GameObject go;

    // Start is called before the first frame update
    void Start()
    { 
    
        for (float x = -5; x <=5; x+=1)
        {
            for (float y = -5; y <= 5; y += 1)
            {
                Instantiate(go, new Vector3(x, y, 0), Quaternion.identity);
            }
        }
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
