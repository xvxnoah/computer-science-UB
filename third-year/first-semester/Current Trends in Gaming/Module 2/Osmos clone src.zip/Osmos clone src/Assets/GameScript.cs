﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameScript : MonoBehaviour
{
    public GameObject player;
    public int numberOfNPCCells;
    public bool gameOver = false;
    public bool gameWon = false;

    private AudioSource source;
    public AudioClip gameWonSound;

    // Start is called before the first frame update
    void Start()
    {
        source = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    { 
        if (player.GetComponent<Player>().dead)
        {
            gameOver = true;
        }

        numberOfNPCCells = GameObject.FindGameObjectsWithTag("NPC").Length;
        if (numberOfNPCCells == 0)
        {
            if (!gameWon)
            {
                source.PlayOneShot(gameWonSound, 1);
            }
            gameWon = true;
           

        }
    }
}
