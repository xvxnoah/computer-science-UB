﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIScript : MonoBehaviour
{
    public GameObject gameOverText;
    public GameObject gameWonText; 
    public Text scoreText;
    public GameObject player;

    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        if (player != null)
        {
            scoreText.text = "Mass: " + player.transform.localScale.x;
        }

        bool gameOver = GetComponent<GameScript>().gameOver;
        if (gameOver)
        {
            gameOverText.SetActive(true);
        }

        bool gameWon = GetComponent<GameScript>().gameWon;
        if (gameWon)
        {
            gameWonText.SetActive(true);
        }
    }
}
