﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {

    private Rigidbody rb;

    private bool moving = false;

    private float rotationAngleDelta = 0.2f;

    public bool dead = false;

    // Use this for initialization
    void Start () {
        rb = GetComponent<Rigidbody>();
    }
	
	// Update is called once per frame
	void Update () {

        transform.Rotate(new Vector3(0, 0, 1), rotationAngleDelta);

        moving = false;


        if (Input.GetKey(KeyCode.DownArrow))
        {
            rb.AddForce(new Vector3(0, -5, 0));
            moving = true;
        }
        if (Input.GetKey(KeyCode.UpArrow))
        {
            rb.AddForce(new Vector3(0, 5, 0));
            moving = true;
        }
        if (Input.GetKey(KeyCode.RightArrow))
        {
            rb.AddForce(new Vector3(5, 0, 0));
            moving = true;
        }
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            rb.AddForce(new Vector3(-5, 0, 0));
            moving = true;
        }

        if (moving)
        {
            float scale = transform.localScale.x;
            scale -= 0.001f;
            transform.localScale = new Vector3(scale, scale, scale);

            float area = Mathf.PI * scale * scale;

	    if (area < 0.01f) {
		 GetComponent<Renderer>().enabled = false;
		 dead = true;
	    }
        }
    }
}
