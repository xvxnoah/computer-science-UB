﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NeutralCell : MonoBehaviour {

    private float rotationAngleDelta = 0.2f;

    private AudioSource source;
    public AudioClip planetEaten;
    public GameObject game; 

    // Use this for initialization
    void Start () {
        source = game.GetComponent<AudioSource>();

    }
	
	// Update is called once per frame
	void Update () {
        transform.Rotate(new Vector3(0, 0, 1), rotationAngleDelta);
    }


    private void OnTriggerEnter(Collider other)
    {
    }

    // stayCount allows the OnTriggerStay to be displayed less often
    // than it actually occurs.
    //private float stayCount = 0.0f;
    private void OnTriggerStay(Collider other)
    {
        float thisScale = transform.localScale.x;
        float otherScale = other.transform.localScale.x;

        float distance = Vector3.Distance(transform.position, other.transform.position);
        float overlapLength = thisScale + otherScale - distance * 2;

        Transform smallSphereTrans;
        Transform largeSphereTrans;

        if (thisScale > otherScale)
        {
            smallSphereTrans = other.transform;
            largeSphereTrans = transform;
        }
        else
        {
            largeSphereTrans = other.transform;
            smallSphereTrans = transform;
        }

        float smallScale = smallSphereTrans.localScale.x;
        float largeScale = largeSphereTrans.localScale.x;

        float smallArea = Mathf.PI * smallScale * smallScale;
        float largeArea = Mathf.PI * largeScale * largeScale;

        float overlapArea = smallArea - (Mathf.PI * (smallScale - overlapLength) * (smallScale - overlapLength)); //Find the area of the outer ring of the smaller circle
        if (overlapArea >= 0)
        {
            largeArea += overlapArea;
            smallArea -= overlapArea;

            float largeNewScale = Mathf.Sqrt(largeArea / Mathf.PI);
            largeSphereTrans.localScale = new Vector3(largeNewScale, largeNewScale, largeNewScale);

            if (smallArea > 0.01f)
            {
                float smallNewScale = Mathf.Sqrt(smallArea / Mathf.PI);
                smallSphereTrans.localScale = new Vector3(smallNewScale, smallNewScale, smallNewScale);
            }
            else
            {
                source.PlayOneShot(planetEaten, 1);
                GameObject.Destroy(smallSphereTrans.gameObject);   
            }
        }
    }

    private void OnTriggerExit(Collider other)
    {
    }
}
