#include "Lambertian.hh"

Lambertian::Lambertian(const vec3& color): Material()
{
    Kd = color;
}

Lambertian::Lambertian(const vec3& a, const vec3& d, const vec3& s, const float k):
    Material(a, d, s, k) {
}

Lambertian::Lambertian(const vec3& a, const vec3& d, const vec3& s, const float k, const float o):
    Material(a, d, s, k, o) {
}
Lambertian::~Lambertian()
{
}

bool Lambertian::isTransparent() const {
    return false;
}

bool Lambertian::scatter(const Ray& r_in, const HitInfo& rec, vec3& color, Ray & r_out) const  {
    /* Vector reflectit a la intersecció usant la normal i certa aletorietat */
    vec3 target = rec.p + rec.normal + Hitable::RandomInSphere();
    r_out =  Ray(rec.p, target-rec.p); /* Raig reflectit */
    color = Kd; /* Només reflecteix la component difosa */
    return true;
}

void Lambertian::setKd(vec3 kd) {
    this->Kd = kd;
}

vec3 Lambertian::getDiffuse(vec2 uv) const {
    return Kd;
}
