/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mediaplayer;
/**
*
* @author Esteban Fuentealba
*/
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
/* Importamos Las clases del Package Media */
import javax.media.*;
/* Tambien necesitamos importar AudioFormat del package javax.media.format para poder agregar los codecs */
import javax.media.format.AudioFormat;

public class Main {

public static void main(String[] args) {
if (args.length > 0) {
try {
/* Esta es la direccion del codec que decodifica los mp3 */
String jffmpegAudioDecoder = "net.sourceforge.jffmpeg.AudioDecoder";
/* Cargamos el codec y lo guardamos en un objeto de tipo Codec */
Codec codecAudio = (Codec) Class.forName(jffmpegAudioDecoder).newInstance();
/* Agregamos los codec al PlugInManager */
PlugInManager.addPlugIn(jffmpegAudioDecoder,
codecAudio.getSupportedInputFormats(),
new Format[]{new AudioFormat("LINEAR")},
PlugInManager.CODEC);
/* Y ahora podemos crear un objeto Player que es del JMF */
Player miPlayer = Manager.createPlayer(new URL(args[0].toString()));
/* Le ponemos Play a nuestro archivo cargado  */
miPlayer.start();
} catch (NoPlayerException ex) {
Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
} catch (MalformedURLException ex) {
Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
} catch (InstantiationException ex) {
Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
} catch (IllegalAccessException ex) {
Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
} catch (ClassNotFoundException ex) {
Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
} catch (IOException ex) {
Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
}
} else {
System.out.println("ERROR: Debes pasar como parametro la direccion de un archivo mp3");
}
}
}