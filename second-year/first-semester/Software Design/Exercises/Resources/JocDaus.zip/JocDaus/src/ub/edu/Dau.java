package ub.edu;

public class Dau {
    public int tirar() {
        return (int)(6*Math.random());
    }
}
