package ub.edu.before.view;

import javafx.stage.Stage;
import ub.edu.before.controller.Controller;

public abstract class Escena {
    protected Stage stage;
    protected Controller controller;

    public void setController(Controller controller){this.controller = controller;}

    public void setStage(Stage stage) {
        this.stage = stage;
    }

}
