package ub.edu.after.resources.services;

import ub.edu.after.resources.dao.DAOClient;

public interface AbstractFactoryData {
    DAOClient createDAOClient();
}
