package ub.edu.before.view;

import javafx.stage.Stage;
import ub.edu.before.controller.Controller;

import java.io.IOException;

public class Vista {
    protected Controller controller;

    public Vista(Stage stage, Controller controller) throws IOException{
        this.controller = controller;

        Escena login = EscenaFactory.INSTANCE.creaEscena("login-view", "LOGIN");

        login.setController(controller);
    }
}
