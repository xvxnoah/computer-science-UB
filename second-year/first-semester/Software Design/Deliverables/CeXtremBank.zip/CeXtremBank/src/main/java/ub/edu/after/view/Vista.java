package ub.edu.after.view;

import javafx.stage.Stage;
import ub.edu.after.controller.Controller;

import java.io.IOException;

public class Vista {
    protected Controller controller;

    public Vista(Stage stage, Controller controller) throws IOException{
        this.controller = controller;

        Escena login = EscenaFactory.INSTANCE.creaEscena("login-view-after", "LOGIN");

        login.setController(controller);
    }
}
