package ub.edu.after;

import javafx.application.Application;
import javafx.stage.Stage;
import ub.edu.after.controller.Controller;
import ub.edu.after.view.Vista;

public class AfterMain extends Application{
    private Controller controller;
    private Vista vista;

    @Override
    public void start(Stage stage) throws Exception {
        controller = Controller.getInstance();
        vista = new Vista(stage, controller);
    }

    public static void main(String[] args){launch();}
}
