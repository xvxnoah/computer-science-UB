package ub.edu.after.view;

import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.io.IOException;

public class EscenaLogin extends Escena {

    public Button login_btn;
    public TextField login_correu;
    public PasswordField login_pwd;
    public Button registre_btn;
    public TextField registre_correu;
    public PasswordField registre_pwd;

    @FXML
    protected void onLoginButtonClick() {
        String correu = login_correu.getText();
        String pwd = login_pwd.getText();

        String resultat = controller.loginClient(correu, pwd);

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        if(resultat.equals("Not a known client!") || resultat.equals("Incorrect password")){
            //Problema en el login:
            alert.setAlertType(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Login Error");
            alert.setContentText(resultat);
        }else{
            //Login amb èxit:
            alert.setTitle("Login done!");
            alert.setHeaderText("Login done!");
            //Fent això, canviarem l'escena quan es tanqui el diàleg
            alert.setOnCloseRequest(new EventHandler<DialogEvent>() {
                @Override
                public void handle(DialogEvent dialogEvent) {
                    try {
//                      Escena main = canviarEscena("main-view", "CeXtrem");
                        Escena main = EscenaFactory.INSTANCE.creaEscena("main-view-after", "CeXtrem");
                        EscenaMain escenaMain = ((EscenaMain)main);
                        main.setController(controller);
                        escenaMain.start();
                        stage.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            });
        }

        alert.showAndWait();
    }

    @FXML
    public void onRegistreButtonClick() {
        String correu = registre_correu.getText();
        String pwd = registre_pwd.getText();
        String resultat = controller.validateRegisterClient(correu, pwd);

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        if(resultat.equals("Already registered!")|| resultat.equals("Wrong email format") || resultat.equals("Password not strong enough")){
            //Problema en el registre:
            alert.setAlertType(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Register error");
            alert.setContentText(resultat);
        }else{
            //Registre amb èxit:
            alert.setTitle("Register done");
            alert.setHeaderText("Register done");
        }
        alert.showAndWait();
    }
}
