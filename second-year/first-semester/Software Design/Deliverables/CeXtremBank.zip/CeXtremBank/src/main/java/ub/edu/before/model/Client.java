package ub.edu.before.model;

public class Client {
    private String nom;
    private String pwd;
    private double balance;

    public Client(String nom, String pwd){
        this.nom = nom;
        this.pwd = pwd;
    }

    public Client(String nom, String pwd, double balance){
        this.nom = nom;
        this.pwd = pwd;
        this.balance = balance;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(float balance) {
        this.balance = balance;
    }

    public String withdraw(double ammount){
        if(balance >= ammount){
            this.balance -= ammount;
            return "Withdrawal succesful!";
        }
        return "Not enough money in your account!";
    }

    public String deposit(double ammount){
        if(ammount <= 0){
            return "Not a valid deposit, must be greater than 0!";
        }
        this.balance += ammount;

        return "Deposit succesful!";
    }
}
