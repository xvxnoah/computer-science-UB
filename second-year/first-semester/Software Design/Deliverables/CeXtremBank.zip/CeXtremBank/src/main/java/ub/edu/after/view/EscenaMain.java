package ub.edu.after.view;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.text.Text;
import javafx.stage.WindowEvent;

import java.io.IOException;
import java.util.Observable;
import java.util.Observer;

public class EscenaMain extends Escena implements Observer {
    public Button deposit_btn;
    public Button withdraw_btn;
    public Text info_balance;

    public void start(){
        controller.observerToClass(this);
        this.stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent windowEvent) {
                Platform.exit();
            }
        });

        info_balance.setText(Double.toString(controller.getBalanceUser()));

        deposit_btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    showDeposit();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        withdraw_btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try{
                    showWithdraw();
                } catch (IOException e){
                    e.printStackTrace();
                }
            }
        });
    }

    public void showDeposit() throws IOException{
        Escena escena = EscenaFactory.INSTANCE.creaEscena("deposit-view-after", "DEPOSIT", this.stage);
        EscenaDeposit escenaDeposit = ((EscenaDeposit) escena);
        escenaDeposit.setController(controller);
    }

    public void showWithdraw() throws IOException{
        Escena escena = EscenaFactory.INSTANCE.creaEscena("withdraw-view-after", "WITHDRAW", this.stage);
        EscenaWithdraw escenaWithdraw = ((EscenaWithdraw) escena);
        escenaWithdraw.setController(controller);
    }

    @Override
    public void update(Observable o, Object arg) {
        info_balance.setText(Double.toString(controller.getBalanceUser()));
    }
}
