package ub.edu.after.view;

import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DialogEvent;
import javafx.scene.control.TextField;

public class EscenaWithdraw extends Escena {
    public TextField ammount;
    public Button withdraw_btn;

    @FXML
    protected void onWithdrawButton(){
        double withdraw = Double.parseDouble(ammount.getText());

        String result = controller.withdraw(withdraw);

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        if(result.equals("Not enough money in your account!")){
            alert.setAlertType(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setHeaderText("WITHDRAWAL ERROR");
            alert.setContentText(result);
        }else {
            alert.setTitle("DONE");
            alert.setHeaderText("WITHDRAWAL DONE");
            alert.setContentText(result);

            alert.setOnCloseRequest(new EventHandler<DialogEvent>() {
                @Override
                public void handle(DialogEvent dialogEvent) {
                    stage.close();
                }
            });
        }
        alert.showAndWait();
    }
}
