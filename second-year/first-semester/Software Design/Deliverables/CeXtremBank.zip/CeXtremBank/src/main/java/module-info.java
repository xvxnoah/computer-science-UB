module ub.edu.cextrembank {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires org.kordamp.bootstrapfx.core;

    opens ub.edu.before.view to javafx.fxml;
    exports ub.edu.before.view;
    exports ub.edu.before;
    opens ub.edu.before to javafx.fxml;

    opens ub.edu.after.view to javafx.fxml;
    exports ub.edu.after.view;
    exports ub.edu.after;
    opens ub.edu.after to javafx.fxml;
}