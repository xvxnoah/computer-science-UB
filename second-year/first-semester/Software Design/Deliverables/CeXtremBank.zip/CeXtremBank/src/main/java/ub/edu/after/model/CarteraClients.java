package ub.edu.after.model;

import java.util.ArrayList;
import java.util.List;

public class CarteraClients {
    private List<Client> listClients;

    public CarteraClients(){listClients = new ArrayList<>();}
    public CarteraClients(List<Client> allClients){listClients = allClients;}

    public void addClient(Client client){
        if(!listClients.contains(client)){
            listClients.add(client);
        }
    }

    public Client find(String user){
        for(Client client : listClients){
            if(client.getNom().equals(user)) return client;
        }
        return null;
    }
}
