package ub.edu.after.resources.dao;

import ub.edu.after.model.Client;

public interface DAOClient extends DAO<Client> {
}
