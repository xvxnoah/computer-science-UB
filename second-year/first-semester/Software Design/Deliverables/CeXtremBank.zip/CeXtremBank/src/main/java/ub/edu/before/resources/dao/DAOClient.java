package ub.edu.before.resources.dao;

import ub.edu.before.model.Client;

public interface DAOClient extends DAO<Client>{
}
