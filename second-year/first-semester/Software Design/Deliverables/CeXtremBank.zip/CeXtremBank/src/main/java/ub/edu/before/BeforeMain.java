package ub.edu.before;

import javafx.application.Application;
import javafx.stage.Stage;
import ub.edu.before.controller.Controller;
import ub.edu.before.view.Vista;

public class BeforeMain extends Application{
    private Controller controller;
    private Vista vista;

    @Override
    public void start(Stage stage) throws Exception {
        controller = Controller.getInstance();
        vista = new Vista(stage, controller);
    }

    public static void main(String[] args){launch();}
}
