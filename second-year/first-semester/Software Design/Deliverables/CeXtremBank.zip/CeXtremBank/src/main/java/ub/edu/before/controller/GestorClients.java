package ub.edu.before.controller;

import ub.edu.before.model.CarteraClients;
import ub.edu.before.model.CeXtremBank;
import ub.edu.before.model.Client;
import ub.edu.before.resources.services.DataService;

import java.util.List;

public class GestorClients {
    private volatile static GestorClients uniqueInstance;
    private CeXtremBank ceXtremBank;
    private ValidateRegisterClient validate;

    private GestorClients(){
        ceXtremBank = CeXtremBank.getInstance();
        validate = ValidateRegisterClient.getInstance();
    }

    public static GestorClients getInstance(){
        if(uniqueInstance == null){
            synchronized (GestorClients.class){
                if(uniqueInstance == null){
                    uniqueInstance = new GestorClients();
                }
            }
        }
        return uniqueInstance;
    }

    public boolean iniCarteraClients(DataService dataService) throws Exception{
        List<Client> list = dataService.getAllClients();

        if(list != null){
            ceXtremBank.setCarteraClients(new CarteraClients(list));
            return true;
        } else return false;
    }

    public Client findClient(String user){return ceXtremBank.getCarteraClients().find(user);}

    public String loginClient(String user, String pass, DataService dataService){
        try{
            return dataService.loginClient(user, pass);
        } catch (Exception e){
            return "";
        }
    }

    public String validateRegisterClient(String user, String pass, DataService dataService){
        String validateRegister = validate.validateRegisterClient(user, pass);

        if(validateRegister.equals("Client verified!")){
            Client newClient = new Client(user, pass);
            ceXtremBank.getCarteraClients().addClient(newClient);

            dataService.registerClient(newClient);
            return validateRegister;
        }
        return validateRegister;
    }

    public double balanceUser(String user){
        return ceXtremBank.getCarteraClients().find(user).getBalance();
    }

    public String withdraw(String user, double ammount) {
        return ceXtremBank.getCarteraClients().find(user).withdraw(ammount);
    }

    public String deposit(String user, double ammount) {
        return ceXtremBank.getCarteraClients().find(user).deposit(ammount);
    }
}
