package ub.edu.before.view;

import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DialogEvent;
import javafx.scene.control.TextField;

public class EscenaDeposit extends Escena {
    public TextField ammount;
    public Button deposit_btn;

    @FXML
    protected void onDepositButton(){
        double deposit = Double.parseDouble(ammount.getText());

        String result = controller.deposit(deposit);

        Alert alert = new Alert(Alert.AlertType.INFORMATION);

        if(result.equals("Not a valid deposit, must be greater than 0!")){
            alert.setAlertType(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setHeaderText("DEPOSIT ERROR");
            alert.setContentText(result);
        }else {
            alert.setTitle("DONE");
            alert.setHeaderText("DEPOSIT DONE");
            alert.setContentText(result);

            alert.setOnCloseRequest(new EventHandler<DialogEvent>() {
                @Override
                public void handle(DialogEvent dialogEvent) {
                    stage.close();
                }
            });
        }
        alert.showAndWait();
    }

}
