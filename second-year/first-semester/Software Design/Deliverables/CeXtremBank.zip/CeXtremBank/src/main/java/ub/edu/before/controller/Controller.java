package ub.edu.before.controller;

public class Controller {
    private volatile static Controller uniqueInstance;
    private GestorBaseDades gestorBaseDades;
    private GestorClients gestorClients;
    private static String actualUser;

    private Controller(){
        try{
            gestorClients = GestorClients.getInstance();
            gestorBaseDades = GestorBaseDades.getInstance();
            gestorBaseDades.iniCartera();
        } catch (Exception e){
        }
    }

    public static Controller getInstance(){
        if(uniqueInstance == null){
            synchronized (Controller.class){
                if(uniqueInstance == null){
                    uniqueInstance = new Controller();
                }
            }
        }
        return uniqueInstance;
    }

    public String getActualUser(){
        return actualUser;
    }

    private void setActualUser(String user){
        actualUser = user;
    }

    public String validateRegisterClient(String user, String pass){
        return gestorBaseDades.registerClient(user, pass);
    }

    public double getBalanceUser(){
        return gestorClients.balanceUser(getActualUser());
    }

    public String loginClient(String user, String pass){
        String answer = gestorBaseDades.loginClient(user, pass);

        if(answer.equals("Valid login!")){
            setActualUser(user);
            return answer;
        }
        return answer;
    }

    public String withdraw(double ammount){
        return gestorClients.withdraw(getActualUser(), ammount);
    }

    public String deposit(double ammount){
        return gestorClients.deposit(getActualUser(), ammount);
    }
}
