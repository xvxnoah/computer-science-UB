package ub.edu.before.view;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.text.Text;
import javafx.stage.WindowEvent;

import java.io.IOException;

public class EscenaMain extends Escena{
    public Button deposit_btn;
    public Button withdraw_btn;
    public Text info_balance;

    public void start(){
        this.stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent windowEvent) {
                Platform.exit();
            }
        });

        info_balance.setText(Double.toString(controller.getBalanceUser()));

        deposit_btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    showDeposit();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        withdraw_btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try{
                    showWithdraw();
                } catch (IOException e){
                    e.printStackTrace();
                }
            }
        });
    }

    public void showDeposit() throws IOException{
        Escena escena = EscenaFactory.INSTANCE.creaEscena("deposit-view", "DEPOSIT", this.stage);
        EscenaDeposit escenaDeposit = ((EscenaDeposit) escena);
        escenaDeposit.setController(controller);
    }

    public void showWithdraw() throws IOException{
        Escena escena = EscenaFactory.INSTANCE.creaEscena("withdraw-view", "WITHDRAW", this.stage);
        EscenaWithdraw escenaWithdraw = ((EscenaWithdraw) escena);
        escenaWithdraw.setController(controller);
    }
}
