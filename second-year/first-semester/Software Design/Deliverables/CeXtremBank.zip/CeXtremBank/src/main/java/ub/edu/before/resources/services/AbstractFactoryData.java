package ub.edu.before.resources.services;

import ub.edu.before.resources.dao.DAOClient;

public interface AbstractFactoryData {
    DAOClient createDAOClient();
}
