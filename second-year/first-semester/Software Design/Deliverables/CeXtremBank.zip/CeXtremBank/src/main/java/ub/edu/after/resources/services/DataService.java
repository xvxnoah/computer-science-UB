package ub.edu.after.resources.services;

import ub.edu.after.model.Client;
import ub.edu.after.resources.dao.DAOClient;

import java.util.List;
import java.util.Optional;

public class DataService {
    private DAOClient daoClient;

    public DataService(AbstractFactoryData factory){
        this.daoClient = factory.createDAOClient();
    }

    public String loginClient(String user, String pass) throws Exception{
        Optional<Client> optional = daoClient.getById(user);

        if(!optional.isPresent()){
            return "Not a known client!";
        }

        Client client = optional.get();

        if(client.getPwd().equals(pass)){
            return "Valid login!";
        }

        return "Incorrect password";
    }

    public void registerClient(Client client){
        try {
            daoClient.add(client);
        } catch (Exception e){

        }
    }
    public List<Client> getAllClients() throws Exception{
        return daoClient.getAll();
    }
}
