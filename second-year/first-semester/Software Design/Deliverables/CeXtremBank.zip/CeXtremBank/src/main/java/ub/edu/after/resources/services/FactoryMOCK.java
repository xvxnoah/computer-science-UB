package ub.edu.after.resources.services;

import ub.edu.after.resources.dao.DAOClient;
import ub.edu.after.resources.dao.MOCK.DAOClientMOCK;

public class FactoryMOCK implements AbstractFactoryData {

    @Override
    public DAOClient createDAOClient() {
        return new DAOClientMOCK();
    }
}
