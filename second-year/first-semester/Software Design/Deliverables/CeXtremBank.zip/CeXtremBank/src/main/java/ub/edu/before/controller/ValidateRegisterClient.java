package ub.edu.before.controller;

import ub.edu.before.model.Client;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidateRegisterClient {
    private volatile static ValidateRegisterClient uniqueInstance;

    private ValidateRegisterClient(){}

    public static ValidateRegisterClient getInstance(){
        if(uniqueInstance == null){
            synchronized (ValidateRegisterClient.class){
                if(uniqueInstance == null){
                    uniqueInstance = new ValidateRegisterClient();
                }
            }
        }
        return uniqueInstance;
    }

    public String validateRegisterClient(String user, String pass) {
        if (isMail(user) && isPasswordSegur(pass)) {
            GestorClients gestorClients = GestorClients.getInstance();
            Client client = gestorClients.findClient(user);
            if (client != null) {
                return "Already registered!";
            } else return "Client verified!";
        } else if(!isMail(user)){
            return "Wrong email format";
        } else{
            return "Password not strong enough";
        }
    }

    private boolean isPasswordSegur(String password) {
        Pattern pattern = Pattern.compile("^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,}$");
        Matcher matcher = pattern.matcher(password);
        return matcher.find();
    }
    private boolean isMail(String correu) {
        Pattern pattern = Pattern.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
        Matcher matcher = pattern.matcher(correu);
        return matcher.find();
    }
}
