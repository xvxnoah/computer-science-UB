package ub.edu.after.resources.dao.MOCK;

import ub.edu.after.model.Client;
import ub.edu.after.resources.dao.DAOClient;

import java.util.*;

public class DAOClientMOCK implements DAOClient {
    private Map<String, Client> listClients = new HashMap<>();

    public DAOClientMOCK(){
        listClients.put("ajaleo@gmail.com", new Client("ajaleo@gmail.com", "ajaleoPassw7", 1500.0));
        listClients.put("dtomacal@yahoo.cat", new Client("dtomacal@yahoo.cat", "Qwertyft5", 546.89));
        listClients.put("heisenberg@gmail.com", new Client("heisenberg@gmail.com", "the1whoknocks"));
        listClients.put("rick@gmail.com",  new Client("rick@gmail.com", "wabalabadapdap22", 989.81));
        listClients.put("nietolopez10@gmail.com",new Client("nietolopez10@gmail.com", "pekFD91m2a",101.10));
        listClients.put("nancyarg10@yahoo.com", new Client("nancyarg10@yahoo.com", "contra10LOadc"));
        listClients.put( "CapitaCC@gmail.com",  new Client("CapitaCC@gmail.com", "Alistar10"));
        listClients.put( "nauin2@gmail.com", new Client("nauin2@gmail.com", "kaynJGL20", 45.89));
        listClients.put( "juancarlos999@gmail.com", new Client("juancarlos999@gmail.com", "staIamsA12", 93.91));
        listClients.put( "judit121@gmail.com", new Client("judit121@gmail.com", "Ordinador1"));
    }
    @Override
    public Optional<Client> getById(String id){
        return Optional.ofNullable(listClients.get(id));
    }

    @Override
    public List<Client> getAll() {
        return new ArrayList<>(listClients.values());
    }

    @Override
    public boolean add(Client client){
        if(listClients.containsKey(client.getNom())){
            return false;
        }
        listClients.put(client.getNom(), client);
        return true;
    }

    @Override
    public boolean update(Client client, String[] params) {
        client.setNom(Objects.requireNonNull(
                params[0], "Name cannot be null"));
        client.setPwd(Objects.requireNonNull(
                params[1], "Password cannot be null"));
        return listClients.replace(client.getNom(), client) != null;
    }

    @Override
    public boolean delete(Client client) throws Exception {
        return listClients.remove(client.getNom()) != null;
    }
}
