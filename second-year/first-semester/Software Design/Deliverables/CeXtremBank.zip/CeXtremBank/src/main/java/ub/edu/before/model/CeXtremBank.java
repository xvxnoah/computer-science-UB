package ub.edu.before.model;

public class CeXtremBank {
    private volatile static CeXtremBank uniqueInstance;
    private CarteraClients carteraClients;

    private CeXtremBank(){
    }

    public static CeXtremBank getInstance(){
        if(uniqueInstance == null){
            synchronized (CeXtremBank.class){
                if(uniqueInstance == null){
                    uniqueInstance = new CeXtremBank();
                }
            }
        }
        return uniqueInstance;
    }

    public CarteraClients getCarteraClients(){return carteraClients;}

    public void setCarteraClients(CarteraClients carteraClients){this.carteraClients = carteraClients;}
}
