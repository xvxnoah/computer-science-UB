package ub.edu.after.view;

import javafx.stage.Stage;
import ub.edu.after.controller.Controller;

public abstract class Escena {
    protected Stage stage;
    protected Controller controller;

    public void setController(Controller controller){this.controller = controller;}

    public void setStage(Stage stage) {
        this.stage = stage;
    }

}
