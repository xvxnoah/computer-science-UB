package ub.edu.before.resources.services;

import ub.edu.before.resources.dao.DAOClient;
import ub.edu.before.resources.dao.MOCK.DAOClientMOCK;

public class FactoryMOCK implements AbstractFactoryData{

    @Override
    public DAOClient createDAOClient() {
        return new DAOClientMOCK();
    }
}
