package ub.edu.after.controller;

import ub.edu.after.resources.services.AbstractFactoryData;
import ub.edu.after.resources.services.DataService;
import ub.edu.after.resources.services.FactoryMOCK;

public class GestorBaseDades {
    private volatile static GestorBaseDades uniqueInstance;
    private AbstractFactoryData factory;
    private DataService dataService;
    private GestorClients gestorClients;

    private GestorBaseDades(){
        factory = new FactoryMOCK();
        dataService = new DataService(factory);
        gestorClients = GestorClients.getInstance();
    }

    public static GestorBaseDades getInstance(){
        if(uniqueInstance == null){
            synchronized (GestorBaseDades.class){
                if(uniqueInstance == null){
                    uniqueInstance = new GestorBaseDades();
                }
            }
        }
        return uniqueInstance;
    }

    public void iniCartera() throws Exception{
        gestorClients.iniCarteraClients(dataService);
    }

    public String loginClient(String user, String pass){
        return gestorClients.loginClient(user, pass, dataService);
    }

    public String registerClient(String user, String pass){
        return gestorClients.validateRegisterClient(user, pass, dataService);
    }
}
