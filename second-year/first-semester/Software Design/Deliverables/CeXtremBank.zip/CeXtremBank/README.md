# Patró *Observer* aplicat a CeXtremBank
En aquesta petita aplicació he volgut implementar la interfície d'un banc en què es pot observar el 
balanç d'un client, retirar diners i ingressar diners.

A l'iniciar l'aplicació ens permet fer login (l'email i la *password* que apareixen ja serveixen
per fer login) o registrar-nos a l'aplicació del banc. Aquesta part l'he extret de la nostra pràctica
4, fent ús dels DAO (creats per inicialitzar alguns clients), DataService, AbstractFactoryData...

Un client té tres atributs: *nom/email, password i balanç*. Té dos constructors, un per inicialitzar el client
amb un cert balanç (e.g. si el client ha fet el traspàs del seu compte bancari a aquest banc) i un altre en que no
s'inicialitza el balanç (e.g. el client obre un nou compte bancari).

Un cop hem fet el login (o bé registre & login), a la pantalla principal (***EscenaMain***) es mostra el balanç actual
del client i dues opcions: *withdraw & deposit*.

Per qualsevol de les dues opcions s'obre un altre finestra demanant la quantitat a retirar/ingressar.

En el cas de voler retirar i que la quantitat introduïda sigui més gran que el balanç actual, sortirà un error.

En el cas de voler ingressar i que la quantitat sigui menor o igual a 0, sortirà un error (es podria millorar possant un
slider que només tingués valors >= 0).

##Però, per què aplicar el patró *Observer*?
Com hem dit, a la finestra principal es mostra el balanç actual, llavors sería correcte pensar que al ingressar/retirar
diners, s'actualitzés aquest balanç. Podem comprovar que sense aplicar el patró (BeforeMain) no s'actualitza el balanç a
la pantalla principal; en canvi, un cop aplicat el patró (AfterMain) podem veure com cada cop que fem una operació de les
esmentades, s'actualitza el valor.

##Extra
Diagrames de classes (before):

![VISTA GENERAL](/Users/noahmv/Documents/CeXtremBank/src/main/java/ub/edu/before/before.png "VISTA GENERAL")

![](/Users/noahmv/Documents/CeXtremBank/src/main/java/ub/edu/before/view/view-before.png)

![](/Users/noahmv/Documents/CeXtremBank/src/main/java/ub/edu/before/model/model-before.png)


Diagrames de classes (after):

![](/Users/noahmv/Documents/CeXtremBank/src/main/java/ub/edu/after/after.png "VISTA GENERAL")

![](/Users/noahmv/Documents/CeXtremBank/src/main/java/ub/edu/after/view/view-after.png)

![](/Users/noahmv/Documents/CeXtremBank/src/main/java/ub/edu/after/model/model-after.png)