package ub.edu.model;

import java.util.ArrayList;
import java.util.List;

public class CarteraExcursions {

    private List<Excursio> llistaExcursions;

    public CarteraExcursions() {
        this.llistaExcursions = new ArrayList<>();
    }

    public CarteraExcursions(List<Excursio> allExcursions) {
        llistaExcursions = allExcursions;
    }

    public List<Excursio> getLlista() {
        return llistaExcursions;
    }

    public void setLlista(List<Excursio> llista) {
        this.llistaExcursions = llista;
    }

    public Excursio find(String nomExcursio) {
        Excursio excursio = null;
        for (Excursio e : llistaExcursions) {
            if (e.getNom().equals(nomExcursio)) excursio = e;
        }
        return excursio;
    }

    public void add(Excursio excursio) {
        if (excursio != null) llistaExcursions.add(excursio);
    }

    public boolean isEmpty(){
        return llistaExcursions.isEmpty();
    }
}
