package ub.edu.model;

public class Soci {
    private String pwd;
    private String nom;
    private CarteraActivitats actRealitzades;
    private CarteraActivitats actPreferides;

    public Soci(String nom, String pwd) {
        this.pwd = pwd;
        this.nom = nom;
        this.actRealitzades=new CarteraActivitats();
        this.actPreferides=new CarteraActivitats();
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getName() {
        return nom;
    }

    public void setName(String nom) {
        this.nom = nom;
    }

    public CarteraActivitats getActivitatsRealitzades(){
        return this.actRealitzades;
    }
    public CarteraActivitats getActivitatsPreferides(){
        return this.actPreferides;
    }


    public String addActivitatPreferida(String nomAct){
        return GestorActivitats.marcarActivitatPreferida(nomAct, actPreferides);
    }

    public String addActivitatRealitzada(String nomAct){
        return GestorActivitats.marcarActivitatRealitzada(nomAct, actRealitzades);
    }

    public String addValoracio(String nomAct, int valoracio) {
        return GestorActivitats.valorarActivitat(nomAct,valoracio, actRealitzades);
    }
}