package ub.edu.resources.services;

import ub.edu.model.Activitat;
import ub.edu.model.Especie;
import ub.edu.model.Excursio;
import ub.edu.model.Soci;
import ub.edu.resources.dao.DAOActivitat;
import ub.edu.resources.dao.DAOEspecie;
import ub.edu.resources.dao.DAOExcursio;
import ub.edu.resources.dao.DAOSoci;

import java.util.List;
import java.util.Optional;

public class DataService {
    private DAOSoci daoSoci;
    private DAOActivitat daoActivitat;
    private DAOEspecie daoEspecie;
    private DAOExcursio daoExcursio;

    public DataService(AbstractFactoryData factory) {

        this.daoSoci = factory.createDAOSoci();
        this.daoActivitat = factory.createDAOActivitat();
        this.daoEspecie = factory.createDAOEspecie();
        this.daoExcursio = factory.createDAOExcursio();

        // TO DO: Crear els altres DAO de les altres estructures
    }

    public Optional<Soci> getSociByUsername(String usuari) {
        try {
            return daoSoci.getById(usuari);
        } catch (Exception e) {
            //TODO
        }
        return null;
    }

    public List<Soci> getAllSocis() throws Exception {
        return daoSoci.getAll();
    }

    public List<Activitat> getAllActivitats() throws Exception{
        return daoActivitat.getAll();
    }

    public List<Especie> getAllEspecies() throws Exception {
        return daoEspecie.getAll();
    }

    public List<Excursio> getAllExcursions() throws Exception {
        return daoExcursio.getAll();
    }

}
