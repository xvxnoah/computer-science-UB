package ub.edu.spec.llistaActivitats;

import org.concordion.api.BeforeExample;
import org.concordion.integration.junit4.ConcordionRunner;
import org.junit.runner.RunWith;
import ub.edu.controller.Controller;
import ub.edu.model.*;


@RunWith(ConcordionRunner.class)
public class llistaActivitats {
    private Controller controlador;

    @BeforeExample
    private void init() {
        controlador = new Controller();
        iniEspecies();
        iniExcursions();
    }

    public void afegirActivitats() {
        controlador.afegirActivitatRealitzada("ajaleo@gmail.com", "TORRENTISMO");
        controlador.afegirActivitatRealitzada("ajaleo@gmail.com", "BUNGEE JUMPING");
        controlador.afegirActivitatRealitzada("ajaleo@gmail.com", "KAYAK");
        controlador.afegirActivitatRealitzada("dtomacal@yahoo.cat", "KAYAK");
        controlador.afegirActivitatRealitzada("dtomacal@yahoo.cat", "PAINT BALL");
        controlador.afegirActivitatRealitzada("dtomacal@yahoo.cat", "PARAPENTE");
        controlador.afegirActivitatRealitzada("heisenberg@gmail.com", "CANYONING");
        controlador.afegirActivitatRealitzada("rick@gmail.com", "RAPPEL");
        controlador.afegirActivitatRealitzada("juancarlos999@gmail.com", "ESCALADA");
        controlador.afegirActivitatRealitzada("juancarlos999@gmail.com", "TORRENTISMO");
        controlador.afegirActivitatRealitzada("dtomacal@yahoo.cat", "BUNGEE JUMPING");

    }


    public void afegirActivitatsPreferides() {
        controlador.afegirActivitatPreferida("ajaleo@gmail.com", "TORRENTISMO");
        controlador.afegirActivitatPreferida("ajaleo@gmail.com", "BUNGEE JUMPING");
        controlador.afegirActivitatPreferida("rick@gmail.com", "RAPPEL");


    }

    public void afegirValoracions() {
        controlador.valoraActivitat("ajaleo@gmail.com", "TORRENTISMO", 4);
        controlador.valoraActivitat("ajaleo@gmail.com", "BUNGEE JUMPING", 3);
        controlador.valoraActivitat("ajaleo@gmail.com", "KAYAK", 2);
        controlador.valoraActivitat("dtomacal@yahoo.cat", "KAYAK", 5);
        controlador.valoraActivitat("dtomacal@yahoo.cat", "PAINT BALL", 1);
        controlador.valoraActivitat("dtomacal@yahoo.cat", "PARAPENTE", 5);
        controlador.valoraActivitat("rick@gmail.com", "RAPPEL", 2);
        controlador.valoraActivitat("juancarlos999@gmail.com", "ESCALADA", 4);
        controlador.valoraActivitat("juancarlos999@gmail.com", "TORRENTISMO", 1);
        controlador.valoraActivitat("dtomacal@yahoo.cat", "BUNGEE JUMPING", 3);
    }

    public Iterable<String> listCatalegActivitatsPerValoracio1() {
        return controlador.llistarCatalegActivitatsPerValoracio();
    }

    public Iterable<String> listCatalegActivitatsPerValoracio2() {
        afegirActivitats();
        afegirValoracions();
        return controlador.llistarCatalegActivitatsPerValoracio();
    }

    public Iterable<String> listCatalegActivitatsPerPreferides(String nomSoci) {
        afegirActivitats();
        afegirActivitatsPreferides();
        return controlador.llistarCatalegActivitatsPerPreferides(nomSoci);
    }
    public Iterable<String> listCatalegActivitatsRealitzades(String nomSoci) {
        afegirActivitats();
        return controlador.llistarActivitatsRealitzadesBySoci(nomSoci);
    }
    public Iterable<String> listActivitatsExcursio(String nomExcursio){
        return controlador.llistarActivitatByExcursio(nomExcursio);
    }

    private void iniEspecies(){
        GestorEspecies.addEspecie("Llúdriga");
        GestorEspecies.addEspecie("Milà Reial");
        GestorEspecies.addEspecie("Turó europeu");
    }
   private void iniExcursions(){
       Excursio excursio;

       excursio = new Excursio("Museu Miró", "29/09/2021");
       excursio.addEspecie(GestorEspecies.find("Llúdriga"));
       excursio.addEspecie(GestorEspecies.find("Turó europeu"));
       excursio.addActivitat(GestorActivitats.find("CANYONING"));
       excursio.addActivitat(GestorActivitats.find("KAYAK"));
       GestorExcursions.addExcursio(excursio);


       excursio = new Excursio("La Foradada", "04/10/2021");
       excursio.addEspecie(GestorEspecies.find("Llúdriga"));
       excursio.addActivitat(GestorActivitats.find("ESCALADA"));
       GestorExcursions.addExcursio(excursio);


       excursio = new Excursio("El camí des Correu", "10/10/2021");
       excursio.addEspecie(GestorEspecies.find("Llúdriga"));
       excursio.addEspecie(GestorEspecies.find("Turó europeu"));
       excursio.addActivitat(GestorActivitats.find("PAINT BALL"));
       GestorExcursions.addExcursio(excursio);


       GestorExcursions.addExcursio((new Excursio("Delta de l'Ebre", "11/10/2021")));
       GestorExcursions.addExcursio((new Excursio("El PedraForca", "13/10/2021")));
       GestorExcursions.addExcursio((new Excursio("Colònia Güell", "22/10/2021")));
       GestorExcursions.addExcursio((new Excursio("Castell de Cardona", "24/10/2021")));
       GestorExcursions.addExcursio((new Excursio("Aiguamolls de l'Empordà", "27/10/2021")));
       GestorExcursions.addExcursio((new Excursio("Cap de Creus i Cadaqués", "01/11/2021")));
       GestorExcursions.addExcursio((new Excursio("Aigüestortes i Sant Maurici", "03/11/2021")));
   }



}