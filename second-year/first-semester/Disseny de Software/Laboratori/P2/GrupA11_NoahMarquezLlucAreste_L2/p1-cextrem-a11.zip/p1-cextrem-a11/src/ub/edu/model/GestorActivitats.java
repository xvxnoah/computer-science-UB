package ub.edu.model;

import ub.edu.resources.services.DataService;

import java.util.ArrayList;
import java.util.List;

public class GestorActivitats {
    private static CarteraActivitats activitatsCextrem;


    public static boolean iniCarteraActivitats(DataService dataService) throws Exception {
        List<Activitat> l = dataService.getAllActivitats(); // Està a la RAM, i li demanem que agafi la base de dades
        if (l != null) {
            activitatsCextrem = new CarteraActivitats(l);
            return true;
        } else return false;
    }

    public static CarteraActivitats getActivitatsCextrem(){
        return activitatsCextrem;
    }

    public static void addActivitat(String nomAct){
        if(find(nomAct) != null){
            activitatsCextrem.addActivitat(nomAct);
        }
    }

    public static String marcarActivitatPreferida(String nomAct, CarteraActivitats actPreferides){
        if(find(nomAct) == null){
            return ("L'activitat " + nomAct + " no existeix");
        }

        if(actPreferides.find(nomAct) == null) {
            actPreferides.addActivitat(nomAct);
            return "Activitat " + nomAct + " afegida com a preferida";
        }
        return (nomAct + " ja està a la llista de preferides del soci");
    }

    public static String marcarActivitatRealitzada(String nomAct, CarteraActivitats actRealitzades){
        if(find(nomAct) == null){
            return ("L'activitat " + nomAct + " no existeix");
        }

        if(actRealitzades.find(nomAct) == null) {
            actRealitzades.addActivitat(nomAct);
            return "Activitat " + nomAct + " afegida com a realitzada";
        }
        return (nomAct + " ja està a la llista de realitzades del soci");
    }

    public static Activitat find(String nomAct){
        return activitatsCextrem.find(nomAct);
    }

    public static String valorarActivitat(String nomAct, int valoracio, CarteraActivitats actRealitzades) {
        Activitat activitat = find(nomAct);
        if(activitat == null){
            return ("L'activitat " + nomAct + " no existeix");
        }
        else{
            if (actRealitzades.find(nomAct)==null){
                return "No has realitzat l'activitat: " + nomAct +", per tant no la pots valorar";
            }
            else if (valoracio>5 || valoracio<1){
                return ("No has introduït una valoració correcte, per tant no es computarà la teva valoració");
            }
            else{
                activitat.valora(valoracio);
                return ("Has valorat l'activitat "+ nomAct + " amb una valoració de " + valoracio);
            }
        }
    }

    public static String visualitzaActivitat(String nomActivitat) {
        Activitat activitat = find(nomActivitat);
        if (activitat!=null){
            float valoracio = activitat.valoracioMitja();
            if (valoracio==-1){
                return "L'activitat "+ nomActivitat+ " no està valorada";
            }else{
                return "L'activitat " + nomActivitat + " té una valoració mitja de: " + valoracio;
            }
        }
        return "L'activitat " + nomActivitat + " no està guardada al sistema";
    }

    public static Iterable<String> llistarCatalegActivitatsPerPreferides(CarteraActivitats actPreferides) {
        return actPreferides.getIterableStringActivitatsOrdenadesAlfabeticament();
    }

    public static Iterable<String> llistarCatalegActivitatsPerValoracio() {
        return activitatsCextrem.getIterableStringActivitatsOrdenadesValoracio();
    }

    public static Iterable<String> llistarActivitatsRealitzades(CarteraActivitats activitatsRealitzades) {
        return activitatsRealitzades.getIterableStringActivitatsOrdenadesAlfabeticament();
    }

    public static Iterable<String> llistarActivitatsExcursio(CarteraActivitats activitats) {
        return activitats.getIterableStringActivitatsOrdenadesAlfabeticament();

    }

}