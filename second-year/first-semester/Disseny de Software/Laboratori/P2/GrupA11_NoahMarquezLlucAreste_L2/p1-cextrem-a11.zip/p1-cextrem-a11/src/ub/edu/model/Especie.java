package ub.edu.model;

public class Especie {
    private String nom;

    public Especie(String nom){
        this.nom = nom;
    }

    public String getNom(){
        return nom;
    }

    public void setNom(String title_cannot_be_null) {
        this.nom=title_cannot_be_null;
    }
}