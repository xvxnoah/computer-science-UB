package ub.edu.model;

import ub.edu.resources.services.DataService;

import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

public class GestorEspecies {
    private static CarteraEspecies especiesCextrem;

    public static boolean iniCarteraEspecies(DataService dataService) throws Exception {
        List<Especie> l = dataService.getAllEspecies(); // Està a la RAM, i li demanem que agafi la base de dades
        if (l != null) {
            especiesCextrem = new CarteraEspecies(l);
            return true;
        } else return false;
    }

    public static Especie find(String nomEspecie){
        return especiesCextrem.find(nomEspecie);
    }

    public static void addEspecie(String nomEspecie){
        especiesCextrem.add(new Especie(nomEspecie));
    }

    public static Iterable<String> cercaEspecie(){
        SortedSet<String> especies = new TreeSet<>();

        if(especiesCextrem.isEmpty()){
            especies.add("No hi han espècies enregistrades");
            return especies;
        }

        for(Especie especie : especiesCextrem.getLlistaEspecies()){
            especies.add(especie.getNom() + " " + GestorExcursions.comptarExcursionsEspecie(especie));
        }
        return especies;
    }
}
