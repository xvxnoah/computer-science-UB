package ub.edu.controller;

import ub.edu.model.*;
import ub.edu.resources.services.AbstractFactoryData;
import ub.edu.resources.services.DataService;
import ub.edu.resources.services.FactoryMOCK;

public class Controller {
    private AbstractFactoryData factory;
    private DataService dataService;

    public Controller() {
        factory = new FactoryMOCK();
        dataService = new DataService(factory); // Començar a crear la façana

        try {
            GestorSoci.iniCarteraSocis(dataService);
            GestorActivitats.iniCarteraActivitats(dataService);
            GestorEspecies.iniCarteraEspecies(dataService);
            GestorExcursions.iniCarteraExcursions(dataService);
        } catch (Exception e) {
            // TODO
        }

    }

    public String loguejarSoci(String username, String password){
        return GestorSoci.loguejarSoci(username, password);
    }

    public String recuperarContrassenya(String username){
        return GestorSoci.recuperarContrasenya(username);
    }

    public String findSoci(String username) {
        return GestorSoci.findSoci(username);
    }

    public String validatePassword(String b) {
        return GestorSoci.validatePassword(b);
    }

    public String validateUsername(String b) {
       return GestorSoci.validateUsername(b);
    }

    public String validateRegisterSoci(String username, String password) {
        return GestorSoci.validateRegisterSoci(username, password);
    }

    public Iterable<String> cercaExcursions(){
        return GestorEspecies.cercaEspecie();
    }

    public void afegirEspecieExcursio(String nomEspecie, String nomExcursio){
        GestorExcursions.afegirEspecieExcursio(nomEspecie, nomExcursio);
    }

    public Iterable<String> cercaEspecie(){
        return GestorEspecies.cercaEspecie();
    }

    public void afegirEspecie(String nomEspecie){
        GestorEspecies.addEspecie(nomEspecie);
    }

    public Iterable<String> llistarCatalegExcursionsPerNom() {
        return GestorExcursions.llistarCatalegExcursionsPerNom();
    }

    public Iterable<String> llistarCatalegExcursionsPerData(){
        return GestorExcursions.llistarCatalegExcursionsPerData();
    }

    public Iterable<String> llistarActivitatByExcursio(String nomExcursio) {
        return GestorExcursions.llistarActivitatsByExcursio(nomExcursio);
    }

    public Iterable<String> llistarCatalegActivitatsPerPreferides(String nomSoci){
        return GestorSoci.llistarCatalegActivitatsPerPreferides(nomSoci);
    }
    public Iterable<String> llistarCatalegActivitatsPerValoracio() {
        return GestorActivitats.llistarCatalegActivitatsPerValoracio();
    }

    public Iterable<String> llistarActivitatsRealitzadesBySoci(String username) {
        return GestorSoci.llistarActivitatsRealitzasdesBySoci(username);
    }

    public String afegirActivitatRealitzada(String nomSoci, String nomActivitat){
        return GestorSoci.addActivitatRealitzada(nomSoci, nomActivitat);
    }

    public String afegirActivitatPreferida(String nomSoci, String nomActivitat){
        return GestorSoci.addActivitatPreferida(nomSoci, nomActivitat);
    }

    public String valoraActivitat(String nomSoci, String nomActivitat, int valoracio){
        return GestorSoci.valoraActivitat(nomSoci, nomActivitat, valoracio);
    }

    public String visualitzaActivitat(String nomActivitat) {
        return GestorActivitats.visualitzaActivitat(nomActivitat);
    }

}
