package ub.edu.resources.services;

import ub.edu.resources.dao.DAOActivitat;
import ub.edu.resources.dao.DAOEspecie;
import ub.edu.resources.dao.DAOExcursio;
import ub.edu.resources.dao.DAOSoci;

public interface AbstractFactoryData {
    DAOSoci createDAOSoci();
    DAOActivitat createDAOActivitat();
    DAOEspecie createDAOEspecie();
    DAOExcursio createDAOExcursio();
}
