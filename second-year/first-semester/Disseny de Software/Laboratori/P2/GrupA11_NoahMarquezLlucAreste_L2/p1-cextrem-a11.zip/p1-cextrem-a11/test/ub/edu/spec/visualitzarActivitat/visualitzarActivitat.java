package ub.edu.spec.visualitzarActivitat;

import org.concordion.api.BeforeExample;
import org.concordion.integration.junit4.ConcordionRunner;
import org.junit.runner.RunWith;
import ub.edu.controller.Controller;

@RunWith(ConcordionRunner.class)
public class visualitzarActivitat {
    private Controller controlador;

    @BeforeExample
    private void init() {controlador = new Controller();}


    public String visualitzarActivitat(String nomActivitat){
        controlador.afegirActivitatRealitzada("ajaleo@gmail.com","KAYAK");
        controlador.valoraActivitat("ajaleo@gmail.com","KAYAK",4);
        return controlador.visualitzaActivitat(nomActivitat);
    }

}
