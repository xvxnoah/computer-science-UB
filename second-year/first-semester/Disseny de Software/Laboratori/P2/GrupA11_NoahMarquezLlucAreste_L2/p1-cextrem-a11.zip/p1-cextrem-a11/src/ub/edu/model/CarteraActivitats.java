package ub.edu.model;

import java.util.*;

public class CarteraActivitats {
    private List<Activitat> llistaActivitats;

    public  CarteraActivitats() {
        llistaActivitats = new ArrayList<>();
    }

    public  CarteraActivitats(List<Activitat> activitats) {
        llistaActivitats = new ArrayList<>(activitats);
    }

    public List<Activitat> getLlistaActivitats() {
        return llistaActivitats;
    }

    public void setLlistaActivitats(List<Activitat> llistaActivitats) {
        this.llistaActivitats = llistaActivitats;
    }

    public Activitat find(String nomActivitat) {

        for (Activitat e: llistaActivitats) {
            if (e.getNom().equals(nomActivitat)) return e;
        }
        return null;

    }

    public void addActivitat(String nomAct){
        llistaActivitats.add(new Activitat(nomAct));
    }

    public void add(Activitat activitat) {
        llistaActivitats.add(activitat);
    }

    public boolean contains(Activitat activitat) {
        return (find(activitat.getNom())!=null);
    }


    public Iterable<String> getIterableStringActivitatsOrdenadesAlfabeticament() {
        List<Activitat> sortedList = getLlistaActivitats();

        sortedList.sort(new Comparator<Activitat>() {
            @Override
            public int compare(Activitat o1, Activitat o2) {
                return o1.compare(o2);
            }
        });

        List<String> llactivitats = new ArrayList<>();
        for (Activitat s : sortedList) {
            llactivitats.add(s.getNom());
        }
        if (llistaActivitats.isEmpty()){
            llactivitats.add("No hi han activitats enregistrades");
        }

        return llactivitats;
    }


    public Iterable<String> getIterableStringActivitatsOrdenadesValoracio() {
        List<Activitat> sortedList = getLlistaActivitats();

        sortedList.sort(new Comparator<Activitat>() {
            @Override
            public int compare(Activitat o1, Activitat o2) {
                return o2.compareByValoration(o1);
            }
        });

        List<String> llactivitats = new ArrayList<>();
        for (Activitat s : sortedList) {
            if (s.valoracioMitja()!=-1){
                llactivitats.add(s.getNom());
            }
        }
        if (llactivitats.isEmpty()){
            llactivitats.add("No hi han activitats valorades enregistrades");
        }

        return llactivitats;
    }
}