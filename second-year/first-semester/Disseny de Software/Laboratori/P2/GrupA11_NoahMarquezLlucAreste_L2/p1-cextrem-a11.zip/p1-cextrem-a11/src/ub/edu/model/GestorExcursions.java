package ub.edu.model;

import ub.edu.resources.services.DataService;

import java.util.*;

public class GestorExcursions {
    private static CarteraExcursions excursionsCextrem;

    public static boolean iniCarteraExcursions(DataService dataService) throws Exception {
        List<Excursio> l = dataService.getAllExcursions(); // Està a la RAM, i li demanem que agafi la base de dades
        if (l != null) {
            excursionsCextrem = new CarteraExcursions(l);
            return true;
        } else return false;
    }

    public static void addExcursio(Excursio excursio){
        excursionsCextrem.add(excursio);
    }

    public static Excursio find(String nomExcursio){
        return excursionsCextrem.find(nomExcursio);
    }

    public static boolean containsEspecie(Especie especie, CarteraEspecies especies){
        return especies.contains(especie);
    }

    public static int comptarExcursionsEspecie(Especie especie){
        int count = 0;

        for(Excursio excursio : excursionsCextrem.getLlista()){
            if(containsEspecie(especie, excursio.getEspecies())) count++;
        }
        return count;
    }

    public static void afegirEspecieExcursio(String nomEspecie, String nomExcursio){
        Especie especie = GestorEspecies.find(nomEspecie);
        Excursio excursio = find(nomExcursio);

        if(especie == null){
            especie = new Especie(nomEspecie);
            GestorEspecies.addEspecie(nomEspecie);
        }
        excursio.getEspecies().add(especie);
    }

    public static Iterable<String> llistarCatalegExcursionsPerNom(){
        SortedSet<String> excursionsDisponibles = new TreeSet<>();

        if(excursionsCextrem.isEmpty()){
            excursionsDisponibles.add("No hi ha excursions disponibles");
        } else{
            for(Excursio e : excursionsCextrem.getLlista()){
                excursionsDisponibles.add((e.getNom()));
            }
        }
        return excursionsDisponibles;
    }

    public static Iterable<String> llistarCatalegExcursionsPerData(){
        List<Excursio> sortedList= excursionsCextrem.getLlista();

        sortedList.sort(new Comparator<Excursio>() {
            @Override
            public int compare(Excursio o1, Excursio o2) {
                return o1.getData().compareTo(o2.getData());
            }
        });

        List<String> excursionsDisponibles = new ArrayList<>();
        for(Excursio e : excursionsCextrem.getLlista()){
            excursionsDisponibles.add(e.getNom());
        }

        return excursionsDisponibles;
    }

    public static Iterable<String> llistarActivitatsByExcursio(String nomExcursio) {
        Excursio excursio = find(nomExcursio);
        if (excursio==null){
            List<String> llactivitats = new ArrayList<>();
            llactivitats.add("L'excursió "+ nomExcursio + " no existeix en el sistema");
            return llactivitats;
        }
        return GestorActivitats.llistarActivitatsExcursio(excursio.getActivitats());
    }
}
