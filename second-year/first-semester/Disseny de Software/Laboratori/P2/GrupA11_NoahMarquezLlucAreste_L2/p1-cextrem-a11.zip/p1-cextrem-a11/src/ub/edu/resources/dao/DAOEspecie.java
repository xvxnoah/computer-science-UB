package ub.edu.resources.dao;

import ub.edu.model.Especie;

public interface DAOEspecie extends DAO<Especie>{
}
