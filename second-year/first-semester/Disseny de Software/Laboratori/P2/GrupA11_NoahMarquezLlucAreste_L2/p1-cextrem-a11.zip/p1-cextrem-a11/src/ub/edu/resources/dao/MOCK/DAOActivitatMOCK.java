package ub.edu.resources.dao.MOCK;

import ub.edu.model.Activitat;
import ub.edu.resources.dao.DAOActivitat;

import java.util.*;

public class DAOActivitatMOCK implements DAOActivitat {
    private Map<String, Activitat> listActivitats = new HashMap<>();

    public DAOActivitatMOCK() {
        listActivitats.put("TORRENTISMO", new Activitat("TORRENTISMO"));
        listActivitats.put("BUNGEE JUMPING", new Activitat("BUNGEE JUMPING"));
        listActivitats.put("ESCALADA", new Activitat("ESCALADA"));
        listActivitats.put("BUCEO", new Activitat("BUCEO"));
        listActivitats.put("PAINT BALL", new Activitat("PAINT BALL"));
        listActivitats.put("KAYAK", new Activitat("KAYAK"));
        listActivitats.put("PARAPENTE", new Activitat("PARAPENTE"));
        listActivitats.put("RAPPEL", new Activitat("RAPPEL"));
        listActivitats.put("CANYONING", new Activitat("CANYONING"));
    }


    @Override
    public List<Activitat> getAll() {
        return new ArrayList<>(listActivitats.values());
    }

    @Override
    public Optional<Activitat> getById(String id) {
        return Optional.ofNullable(listActivitats.get(id));
    }

    @Override
    public boolean add(final Activitat activitat) {
        if (listActivitats.containsKey(activitat.getNom())) {
            return false;
        }
        listActivitats.put(activitat.getNom(), activitat);
        return true;
    }

    @Override
    public boolean update(final Activitat activitat, String[] params) {
        activitat.setNom(Objects.requireNonNull(
                params[0], "Name cannot be null"));
        return listActivitats.replace(activitat.getNom(), activitat) != null;
    }

    @Override
    public boolean delete(final Activitat activitat) {
        return listActivitats.remove(activitat.getNom()) != null;
    }
}















