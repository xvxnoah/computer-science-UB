package ub.edu.model;

public class Activitat {
    private String nom;
    private Valoracio val;

    public Activitat(String titol) {
        this.nom = titol;
        this.val= new Valoracio();
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void valora(int valoracio){
        val.addValoracio(valoracio);
    }
    public float valoracioMitja(){
        return val.calculaValoracio();
    }

    public int compare(Activitat o2) {
        return this.getNom().compareTo(o2.getNom());
    }

    public int compareByValoration(Activitat o2) {
        return val.compare(o2.val);
    }
}