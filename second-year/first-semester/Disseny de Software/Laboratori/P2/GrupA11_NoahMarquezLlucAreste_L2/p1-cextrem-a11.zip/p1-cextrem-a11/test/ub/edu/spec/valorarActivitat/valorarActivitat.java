package ub.edu.spec.valorarActivitat;

import org.concordion.api.BeforeExample;
import org.concordion.integration.junit4.ConcordionRunner;
import org.junit.runner.RunWith;
import ub.edu.controller.Controller;

@RunWith(ConcordionRunner.class)
public class valorarActivitat {
    private Controller controlador;

    @BeforeExample
    private void init() {
        controlador = new Controller();
    }

    public void afegirActivitat(){
        controlador.afegirActivitatRealitzada("ajaleo@gmail.com","TORRENTISMO");
        controlador.afegirActivitatRealitzada("ajaleo@gmail.com","KAYAK");
        controlador.afegirActivitatRealitzada("dtomacal@yahoo.cat","PAINT BALL");
        controlador.afegirActivitatRealitzada("dtomacal@yahoo.cat","PARAPENTE");
        controlador.afegirActivitatRealitzada("heisenberg@gmail.com","CANYONING");
        controlador.afegirActivitatRealitzada("rick@gmail.com","RAPPEL");
        controlador.afegirActivitatRealitzada("juancarlos999@gmail.com","ESCALADA");
        controlador.afegirActivitatRealitzada("juancarlos999@gmail.com","TORRENTISMO");
        controlador.afegirActivitatRealitzada("dtomacal@yahoo.cat","BUNGEE JUMPING");
    }

    public String afegirValoracio(String nomSoci, String nomAct, int valoracio){
        return controlador.valoraActivitat(nomSoci, nomAct, valoracio);
    }

    public String valorar(String nomSoci, String nomAct, int valoracio){
        afegirActivitat();
        return afegirValoracio(nomSoci, nomAct, valoracio);
    }

}