package ub.edu.resources.dao;

import ub.edu.model.Excursio;

public interface DAOExcursio extends DAO<Excursio> {
}
