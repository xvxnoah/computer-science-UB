package ub.edu.model;

import java.util.List;

public class CarteraSocis {
    private List<Soci> llistaSocis;

    public CarteraSocis(List<Soci> allSocis) {
        llistaSocis = allSocis;
    }

    public Soci find(String username) {

        for (Soci c: llistaSocis) {
            if (c.getName().equals(username)) return c;
        }
        return null;

    }

}
