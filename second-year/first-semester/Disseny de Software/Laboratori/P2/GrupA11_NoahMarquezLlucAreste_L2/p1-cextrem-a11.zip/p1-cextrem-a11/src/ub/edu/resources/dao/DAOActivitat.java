package ub.edu.resources.dao;

import ub.edu.model.Activitat;


public interface DAOActivitat extends DAO<Activitat> {

}
