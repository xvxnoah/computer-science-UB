package ub.edu.model;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class CarteraEspecies {

    private Set<Especie> llistaEspecies;

    public CarteraEspecies(){
        llistaEspecies = new HashSet<>();
    }

    public  CarteraEspecies(List<Especie> especies) {
        llistaEspecies = new HashSet<>(especies);
    }

    public Set<Especie> getLlistaEspecies() {
        return llistaEspecies;
    }

    public void setLlistaEspecies(Set<Especie> llistaEspecies) {
        this.llistaEspecies = llistaEspecies;
    }

    public Especie find(String nomEspecie) {
        for (Especie e: llistaEspecies) {
            if (e.getNom().equals(nomEspecie)) return e;
        }
        return null;
    }

    public void add(Especie especie) {
        llistaEspecies.add(especie);
    }

    public boolean contains(Especie especie) {
        return(find(especie.getNom())!=null);
   }

   public boolean isEmpty(){
        return llistaEspecies.isEmpty();
   }
}