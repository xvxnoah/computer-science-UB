package ub.edu.model;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Set;

public class Excursio {
    private String nom;
    private LocalDate data;
    private CarteraEspecies especies;
    private CarteraActivitats activitats;

    public Excursio(String titol, String dataText) {
        this.nom = titol;
        setData(dataText);
        this.especies = new CarteraEspecies();
        this.activitats = new CarteraActivitats();
    }

    public Excursio(String titol, String dataText, List<Especie> especies) {
        this.nom = titol;
        setData(dataText);
        this.especies = new CarteraEspecies(especies);
        this.activitats = new CarteraActivitats();
    }

    public Excursio(String titol, String dataText, List<Especie> especies, List<Activitat> activitats) {
        this.nom = titol;
        setData(dataText);
        this.especies = new CarteraEspecies(especies);
        this.activitats = new CarteraActivitats(activitats);
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public LocalDate getData(){
        return this.data;
    }

    public void setData(String dataText){
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        this.data = LocalDate.parse(dataText, formatter);
    }

    public CarteraEspecies getEspecies() {
        return especies;
    }

    public void setEspecies(Set<Especie> llistaEspecies) {
        this.especies.setLlistaEspecies(llistaEspecies);
    }

    public void addEspecie(Especie especie){
        especies.add(especie);
    }

    public boolean containsEspecie(Especie especie){
        return GestorExcursions.containsEspecie(especie, especies);
    }

    public CarteraActivitats getActivitats() {
        return activitats;
    }

    public void setActivitats(List<Activitat> llistaActivitats) {
        this.activitats = new CarteraActivitats(llistaActivitats);
    }

    public void addActivitat(Activitat activitat) {
        activitats.add(activitat);
    }

    public void addLlistaActivitats(List<Activitat> activitats) {
        activitats.addAll(activitats);
    }

    public boolean contains(Activitat activitat) {
        return activitats.contains(activitat);
    }

    public Activitat findActivitat(String nomActivitat) {
        return activitats.find(nomActivitat);
    }
}