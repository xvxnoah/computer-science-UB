package ub.edu.model;
//import ub.edu.resources.service.DataService;


import ub.edu.resources.services.DataService;

import java.util.ArrayList;
import java.util.List;

public class GestorSoci {
    private static CarteraSocis socisCextrem;

    public static boolean iniCarteraSocis(DataService dataService) throws Exception {
        List<Soci> l = dataService.getAllSocis(); // Està a la RAM, i li demanem que agafi la base de dades
        if (l != null) {
            socisCextrem = new CarteraSocis(l);
            return true;
        } else return false;
    }

    public static CarteraSocis getSocisCextrem(){
        return socisCextrem;
    }

    public static Soci find(String nomSoci){
        return socisCextrem.find(nomSoci);
    }

    public static String addActivitatPreferida(String nomSoci, String nomAct){
        Soci soci = find(nomSoci);
        if (soci==null){
            return "El soci "+ nomSoci + " no existeix en el sistema.";
        }
        return soci.addActivitatPreferida(nomAct);
    }

    public static String addActivitatRealitzada(String nomSoci, String nomAct){
        Soci soci = find(nomSoci);
        if (soci==null){
            return "El soci "+ nomSoci + " no existeix en el sistema.";
        }
        return soci.addActivitatRealitzada(nomAct);
    }

    public static String valoraActivitat(String nomSoci, String nomAct, int valoracio){
        Soci soci = find(nomSoci);
        if (soci==null){
            return "El soci "+ nomSoci + " no existeix en el sistema";
        }
        return soci.addValoracio(nomAct,valoracio);
    }

    public static String loguejarSoci(String username, String password){
        Soci soci = find(username);
        if (soci == null){
            return "Correu inexistent";
        }
        if (soci.getPwd().equals(password)){
            return "Login correcte";
        }
        return "Contrassenya incorrecta";
    }

    public static String recuperarContrasenya(String username){
        Soci soci = find(username);
        if(soci == null){
            return "Correu inexistent";
        }
        return soci.getPwd();
    }


    public static String findSoci(String username) {
        Soci soci = find(username);
        if (soci!=null) return "Soci existent";
        else return "Soci Desconegut";
    }

    public static Iterable<String> llistarCatalegActivitatsPerPreferides(String nomSoci) {
        Soci soci = find(nomSoci);
        if (soci==null){
            List<String> llactivitats = new ArrayList<>();
            llactivitats.add("El soci "+ nomSoci + " no existeix en el sistema");
            return llactivitats;
            }
        return GestorActivitats.llistarCatalegActivitatsPerPreferides(soci.getActivitatsPreferides());
    }

    public static Iterable<String> llistarActivitatsRealitzasdesBySoci(String username) {
        Soci soci = find(username);
        if (soci==null){
            List<String> llactivitats = new ArrayList<>();
            llactivitats.add("El soci "+ username + " no existeix en el sistema");
            return llactivitats;
        }
        return GestorActivitats.llistarActivitatsRealitzades(soci.getActivitatsRealitzades());
    }

    public static String validatePassword(String pass){
        return ValidarDadesSoci.validatePassword(pass);
    }

    public static String validateUsername(String user){
        return ValidarDadesSoci.validateUsername(user);
    }

    public static String validateRegisterSoci(String user, String pass){
        return ValidarDadesSoci.validateRegisterSoci(user, pass);
    }
}
