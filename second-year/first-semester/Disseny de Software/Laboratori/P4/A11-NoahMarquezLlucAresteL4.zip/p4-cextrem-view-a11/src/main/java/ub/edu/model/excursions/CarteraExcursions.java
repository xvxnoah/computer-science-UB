package ub.edu.model.excursions;

import java.util.*;

public class CarteraExcursions {

    private List<Excursio> llistaExcursions;

    public CarteraExcursions() {
        this.llistaExcursions = new ArrayList<>();
    }

    public CarteraExcursions(List<Excursio> allExcursions) {
        llistaExcursions = allExcursions;
    }

    public List<Excursio> getLlista() {
        return llistaExcursions;
    }

    public void setLlista(List<Excursio> llista) {
        this.llistaExcursions = llista;
    }

    public Excursio find(String nomExcursio) {
        Excursio excursio = null;
        for (Excursio e : llistaExcursions) {
            if (e.getNom().equals(nomExcursio)) excursio = e;
        }
        return excursio;
    }

    public void add(Excursio excursio) {
        if (excursio != null) llistaExcursions.add(excursio);
    }

    public boolean isEmpty(){
        return llistaExcursions.isEmpty();
    }

    public Iterable<String> llistarCatalegExcursionsEspecies(String especie){
        SortedSet<String> excursionsDisponibles = new TreeSet<>();

        if(this.isEmpty()){
            excursionsDisponibles.add("No hi ha espècies disponibles");
        } else{
            for(Excursio e : this.getLlista()){
                if(e.getOrigenLoc().getEspecies().find(especie) != null){
                    excursionsDisponibles.add(e.getNom());
                }
                if(e.getDestiLoc().getEspecies().find(especie) != null){
                    excursionsDisponibles.add(e.getNom());
                }
            }
        }

        return excursionsDisponibles;
    }

    public Iterable<String> llistarCatalegExcursions(CarteraExcursions excursions){
        SortedSet<String> excursionsDisponibles = new TreeSet<>();

        if(excursions.isEmpty()){
            excursionsDisponibles.add("No hi ha excursions disponibles");
        } else{
            for(Excursio e : excursions.getLlista()){
                excursionsDisponibles.add((e.getNom()));
            }
        }
        return excursionsDisponibles;
    }

    public Iterable<String> llistarCatalegExcursionsPerData(CarteraExcursions excursions){
        List<Excursio> sortedList= excursions.getLlista();

        sortedList.sort(new Comparator<Excursio>() {
            @Override
            public int compare(Excursio o1, Excursio o2) {
                return o1.getData().compareTo(o2.getData());
            }
        });

        List<String> excursionsDisponibles = new ArrayList<>();
        for(Excursio e : excursions.getLlista()){
            excursionsDisponibles.add(e.getNom());
        }

        return excursionsDisponibles;
    }

    public Iterable<String> llistarCatalegExcursionsLocalitat(CarteraExcursions excursions, String localitat){
        SortedSet<String> excursionsDisponibles = new TreeSet<>();

        if(excursions.isEmpty()){
            excursionsDisponibles.add("No hi ha excursions disponibles");
        } else{
            for(Excursio e : excursions.getLlista()){
                if(e.getDesti().equals(localitat) || e.getOrigen().equals(localitat)){
                    excursionsDisponibles.add(e.getNom());
                }
            }
        }
        return excursionsDisponibles;
    }
}
