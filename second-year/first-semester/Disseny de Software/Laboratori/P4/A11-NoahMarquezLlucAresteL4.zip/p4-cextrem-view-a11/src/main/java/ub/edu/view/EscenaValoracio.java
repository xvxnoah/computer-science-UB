package ub.edu.view;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.List;

public class EscenaValoracio extends Escena{
    public Button valoracioNumerica_btn;
    public Button valoracioLike_btn;
    public Button valoracioDislike_btn;
    public Text activitatValorar_text;

    public void setValoracio(String activitatAValorar){
        activitatValorar_text.setText(activitatAValorar);

        valoracioLike_btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                String resultat = controller.valoraActivitat(controller.getActualUser(), activitatAValorar, "ValoracioLike", 1);
                handleErrors(alert, resultat, activitatAValorar);
                stage.close();
            }
        });

        valoracioDislike_btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                String resultat = controller.valoraActivitat(controller.getActualUser(), activitatAValorar, "ValoracioDislike", 1);
                handleErrors(alert, resultat, activitatAValorar);
                stage.close();
            }
        });

        valoracioNumerica_btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try{
                    mostrarFinestraValoracioNumerica(activitatAValorar);
                } catch (IOException e){
                    e.printStackTrace();
                }
            }
        });
    }

    private void handleErrors(Alert alert, String resultat, String activitatAValorar) {
        if(resultat.equals("No has realitzat l'activitat: " + activitatAValorar +", per tant no la pots valorar")||
                resultat.equals("Ja has valorat l'activitat "+ activitatAValorar + " anteriorment")) {
            alert.setAlertType(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Error al valorar");
            alert.setContentText(resultat);
        } else{
            alert.setTitle("Èxit");
            alert.setHeaderText(activitatAValorar + " valorada correctament!");
            alert.setContentText(resultat);
        }
        alert.showAndWait();
    }

    public void mostrarFinestraValoracioNumerica(String activitat) throws IOException{
        Escena escena = EscenaFactory.INSTANCE.creaEscena("valoracio-numerica-view", "VALORAR NUMÈRICAMENT", stage.getOwner());
        EscenaValoracioNumerica escenaValoracioNumerica = ((EscenaValoracioNumerica)escena);
        escenaValoracioNumerica.setController(controller);
        escenaValoracioNumerica.setValoracioNumerica(activitat);
        stage.close();
    }
}
