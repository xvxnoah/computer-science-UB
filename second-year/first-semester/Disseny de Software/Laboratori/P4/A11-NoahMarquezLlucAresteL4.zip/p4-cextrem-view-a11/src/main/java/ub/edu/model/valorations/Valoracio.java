package ub.edu.model.valorations;

import java.util.*;

public class Valoracio {
    private String idActivitat;
    private Map<String, ValoracioStrategy> valoracions=new HashMap<>();

    public Valoracio(){
        valoracions.put("ValoracioNumerica",new ValoracioNumerica());
        valoracions.put("ValoracioLike",new ValoracioLike());
        valoracions.put("ValoracioDislike",new ValoracioDislike());
    }
    public Valoracio(String idActivitat, int numval, int sumaval, int numlikes, int numdislikes){
        this.idActivitat=idActivitat;
        valoracions.put("ValoracioNumerica",new ValoracioNumerica(numval,sumaval));
        valoracions.put("ValoracioLike",new ValoracioLike(numlikes));
        valoracions.put("ValoracioDislike",new ValoracioDislike(numdislikes));
    }

    private ValoracioStrategy getValoracio(String tipusValoracio){
        return valoracions.get(tipusValoracio);
    }

    public String getIdActivitat(){
        return idActivitat;
    }

    public List<String> getInfoValoracions(){
        List<String> info = new ArrayList<>();

        for (Map.Entry<String, ValoracioStrategy> entry : valoracions.entrySet()) {
            ValoracioStrategy vs = entry.getValue();

            String informacio = vs.getInfo();

            info.add(informacio);
        }

        return info;
    }

    public String addValoracio(String tipusValoracio, int valoracio, String nomAct){
        ValoracioStrategy vs=getValoracio(tipusValoracio);
        vs.addValoracio(valoracio);
        return "Has valorat l'activitat " + nomAct + " amb una valoració de " + vs.getValor(valoracio);
    }

    public Map<String, ValoracioStrategy> getValoracions() {
        return valoracions;
    }

    public int compare(Valoracio val, String tipusVal){
        ValoracioStrategy vs1 = valoracions.get(tipusVal);
        ValoracioStrategy vs2 = val.getValoracions().get(tipusVal);

        Float t = vs1.calculaValoracio();
        Float v = vs2.calculaValoracio();
        return t.compareTo(v);
    }

    public float calculaValoracio(String tipusVal){
        ValoracioStrategy vs = valoracions.get(tipusVal);

        return vs.calculaValoracio();
    }
}