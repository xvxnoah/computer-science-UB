package ub.edu.resources.dao.MOCK;

import ub.edu.model.activities.Activitat;
import ub.edu.resources.dao.DAOActivitatsRealitzades;

import java.lang.reflect.Array;
import java.util.*;

public class DAOActivitatsRealitzadesMOCK implements DAOActivitatsRealitzades {
    private HashMap<String, List<String>> listRealitzades = new HashMap<>();

    public DAOActivitatsRealitzadesMOCK(){
        listRealitzades.put("ajaleo@gmail.com", Arrays.asList("TORRENTISMO", "BUNGEE JUMPING", "KAYAK", "BADMINTON", "VOLLEY"));
        listRealitzades.put("dtomacal@yahoo.cat", Arrays.asList("PAINT BALL", "PARAPENTE", "BUNGEE JUMPING", "FERLAPRACTICA", "PROGRAMAR", "BADMINTON", "VOLLEY"));
        listRealitzades.put("heisenberg@gmail.com", Arrays.asList("CANYONING"));
        listRealitzades.put("juancarlos999@gmail.com", Arrays.asList("ESCALADA", "TORRENTISMO", "FERLAPRACTICA", "PROGRAMAR", "BADMINTON", "VOLLEY"));
        listRealitzades.put("rick@gmail.com", Arrays.asList("RAPPEL", "BADMINTON", "VOLLEY"));
    }

    @Override
    public Optional<Activitat> getById(String id) throws Exception {
        return Optional.empty();
    }

    @Override
    public List<Activitat> getAll() throws Exception {
        return null;
    }

    @Override
    public Collection<List<String>> getAllAct(){
        return listRealitzades.values();
    }

    @Override
    public List<String> getAllSocis() {
        return new ArrayList<>(listRealitzades.keySet());
    }

    @Override
    public boolean add(Activitat activitat) throws Exception {
        return false;
    }

    @Override
    public boolean update(Activitat activitat, String[] params) throws Exception {
        return false;
    }

    @Override
    public boolean delete(Activitat activitat) throws Exception {
        return false;
    }
}
