package ub.edu.controller;

import ub.edu.model.CeXtrem;
import ub.edu.model.activities.Activitat;
import ub.edu.model.activities.CarteraActivitats;
import ub.edu.resources.services.DataService;

import java.util.List;
import java.util.Observer;

public class GestorActivitats {
    private volatile static GestorActivitats uniqueInstance;
    private CeXtrem ceXtrem;

    private GestorActivitats(){
        ceXtrem = CeXtrem.getInstance();
    }
    public static GestorActivitats getInstance(){
        if(uniqueInstance == null){
            synchronized (GestorActivitats.class){
                if(uniqueInstance == null){
                    uniqueInstance = new GestorActivitats();
                }
            }
        }
        return uniqueInstance;
    }

    public boolean iniCarteraActivitats(DataService dataService) throws Exception {
        List<Activitat> l = dataService.getAllActivitats(); // Està a la RAM, i li demanem que agafi la base de dades
        if (l != null) {
            ceXtrem.setCarteraActivitats(new CarteraActivitats(l));
            return true;
        } else return false;
    }

    public Activitat find(String nomAct){
        return ceXtrem.getCarteraActivitats().find(nomAct);
    }

    public Iterable<String> llistarCatalegActivitatsAlfabeticament(CarteraActivitats activitats) {
        return activitats.getActivitatsOrdenadesAlfabeticament();
    }

    public Iterable<String> llistarTop10ActivitatsValorades(String tipusVal){
        return ceXtrem.getCarteraActivitats().getTop10Valorades(tipusVal);
    }

    public List<Activitat> llistarTop10ActivitatsRealitzades(){
        return ceXtrem.getCarteraActivitats().getTop10Realitzades();
    }

    public String getInfoActivitat(String activitat){
        CarteraActivitats carteraActivitats= ceXtrem.getCarteraActivitats();
        return carteraActivitats.getInfoActivitat(activitat);
    }

    public void observersForActivitat(Observer o) {
        ceXtrem.addObsCarteraActivitats(o);
    }

    public String getNomExc(String activitat) {
        return ceXtrem.getCarteraActivitats().getNomExc(activitat);
    }

    public float calcValoracio(String activitat, String tipusVal) {
        return ceXtrem.getCarteraActivitats().calcValoracio(activitat,tipusVal);
    }
}