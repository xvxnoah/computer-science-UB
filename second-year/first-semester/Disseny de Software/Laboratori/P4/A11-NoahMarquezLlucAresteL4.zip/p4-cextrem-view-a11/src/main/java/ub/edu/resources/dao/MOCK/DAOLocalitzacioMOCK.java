package ub.edu.resources.dao.MOCK;

import ub.edu.model.localitzacions.Localitzacio;
import ub.edu.resources.dao.DAOLocalitzacio;

import java.util.*;

public class DAOLocalitzacioMOCK implements DAOLocalitzacio {

    private Map<String, Localitzacio> localitzacioMap = new HashMap<>();

    public DAOLocalitzacioMOCK() {
        addLocalitzacio("Sabadell", "https://goo.gl/maps/bzyR4pWs2XZNT4279");
        addLocalitzacio("Barcelona", "https://goo.gl/maps/jEYowf3j3y7Sxas16");
        addLocalitzacio("Terrassa", "https://goo.gl/maps/pMUCRByUpLhchYrQ8");
        addLocalitzacio("Esporles", "https://goo.gl/maps/L83WMMGLonfaDkLQ7");
        addLocalitzacio("Banyalbufar", "https://goo.gl/maps/qJwVUbVRX9AhvfDa9");
        addLocalitzacio("Salou", "https://goo.gl/maps/x7ZNprAZT3sv1Wvy8");
        addLocalitzacio("Delta", "https://goo.gl/maps/mFbEonwCh5RbU1A4A");
        addLocalitzacio("Saldes", "https://goo.gl/maps/bj98YWjGqU6R5iTJA");
        addLocalitzacio("Pedraforca", "https://goo.gl/maps/hcBLNbYru5mLJUCj6");
        addLocalitzacio("Manresa", "https://goo.gl/maps/Red2kp7s9RP19s3X9");
        addLocalitzacio("Solsona", "https://goo.gl/maps/827MNaLH6GVDMaZ57");
        addLocalitzacio("Cardona", "https://goo.gl/maps/cpKkXYeAqUVU4EXH7");
        addLocalitzacio("Figueres", "https://goo.gl/maps/ZPmBsN5vUJYWW7mY7");
        addLocalitzacio("Aiguamolls", "https://goo.gl/maps/DLKyKaoLhn2KbWELA");
        addLocalitzacio("Roses", "https://goo.gl/maps/4hCUpBokrXD9RYPs7");
        addLocalitzacio("Cadaqués", "https://goo.gl/maps/YtkLmoN9XZzedh5Y9");
        addLocalitzacio("Llavorsí", "https://goo.gl/maps/ivR6RwTt8xDNvs5t6");
        addLocalitzacio("Parc Nacional", "https://goo.gl/maps/S2drqBFdkPM2yhRK7");
    }

    private void addLocalitzacio(String nom, String web){
        localitzacioMap.put(nom, new Localitzacio(nom, web));
    }

    @Override
    public List<Localitzacio> getAll() {
        return new ArrayList<>(localitzacioMap.values());
    }

    @Override
    public Optional<Localitzacio> getById(String id) {
        return Optional.ofNullable(localitzacioMap.get(id));
    }

    @Override
    public boolean add(final Localitzacio localitzacio) {

        if (getById(localitzacio.getNom()).isPresent()) {
            return false;
        }
        localitzacioMap.put(localitzacio.getNom(), localitzacio);
        return true;
    }

    @Override
    public boolean update(final Localitzacio localitzacio, String[] params) {
        localitzacio.setNom(Objects.requireNonNull(
                params[0], "Title cannot be null"));
        return localitzacioMap.replace(localitzacio.getNom(), localitzacio) != null;
    }

    @Override
    public boolean delete(final Localitzacio localitzacio) {
        return localitzacioMap.remove(localitzacio.getNom()) != null;
    }
}