package ub.edu.model.valorations;

import ub.edu.controller.Controller;

public class ValoracioNumerica implements ValoracioStrategy{
    private int sumaValoracions;
    private int numValoracions;


    public ValoracioNumerica(){
        sumaValoracions=0;
        numValoracions=0;
    }

    public ValoracioNumerica(int numValoracions, int sumaValoracions){
        this.numValoracions=numValoracions;
        this.sumaValoracions=sumaValoracions;
    }

    @Override
    public void addValoracio(int valoracio){
        sumaValoracions += valoracio;
        numValoracions += 1;
    }

    @Override
    public float calculaValoracio(){
        if (numValoracions==0){
            return -1;
        }
        return (float)sumaValoracions / (float)numValoracions;
    }

    @Override
    public String getValor(int valoracio) {
        return Integer.toString(valoracio);
    }

    @Override
    public String getInfo(){
        float valoracioMitja = calculaValoracio();

        if(valoracioMitja != -1) return "Valoració mitja: " + valoracioMitja + "\n";
        return "Valoració mitja: X\n";
    }
}
