package ub.edu.model;

import ub.edu.controller.Controller;
import ub.edu.model.activities.CarteraActivitats;
import ub.edu.model.especies.CarteraEspecies;
import ub.edu.model.excursions.CarteraExcursions;
import ub.edu.model.localitzacions.CarteraLocalitzacions;
import ub.edu.model.soci.CarteraSocis;

import java.util.Observer;

public class CeXtrem{
    private volatile static CeXtrem uniqueInstance;
    private CarteraSocis carteraSocis;
    private CarteraActivitats carteraActivitats;
    private CarteraExcursions carteraExcursions;
    private CarteraEspecies carteraEspecies;
    private CarteraLocalitzacions carteraLocalitzacions;

    private CeXtrem(){
    }

    public void addObsCarteraActivitats(Observer o){
        carteraActivitats.addObs(o);
    }
    public static CeXtrem getInstance(){
        if(uniqueInstance == null){
            synchronized (CeXtrem.class){
                if(uniqueInstance == null){
                    uniqueInstance = new CeXtrem();
                }
            }
        }
        return uniqueInstance;
    }

    public CarteraSocis getCarteraSocis() {
        return carteraSocis;
    }

    public CarteraEspecies getCarteraEspecies(){
        return carteraEspecies;
    }

    public CarteraActivitats getCarteraActivitats() {
        return carteraActivitats;
    }

    public CarteraExcursions getCarteraExcursions() {
        return carteraExcursions;
    }

    public void setCarteraActivitats(CarteraActivitats carteraActivitats) {
        this.carteraActivitats = carteraActivitats;
    }

    public void setCarteraExcursions(CarteraExcursions carteraExcursions) {
        this.carteraExcursions = carteraExcursions;
    }

    public void setCarteraSocis(CarteraSocis carteraSocis) {
        this.carteraSocis = carteraSocis;
    }

    public void setCarteraEspecies(CarteraEspecies carteraEspecies) {
        this.carteraEspecies = carteraEspecies;
    }

    public void setCarteraLocalitzacions(CarteraLocalitzacions carteraLocalitzacions) {
        this.carteraLocalitzacions = carteraLocalitzacions;
    }

    public CarteraLocalitzacions getCarteraLocalitzacions() {
        return carteraLocalitzacions;
    }
}
