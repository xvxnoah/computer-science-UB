package ub.edu.model.valorations;

public interface ValoracioStrategy {
    public void addValoracio(int valoracio);

    public float calculaValoracio();

    public String getValor(int valoracio);

    public String getInfo();
}
