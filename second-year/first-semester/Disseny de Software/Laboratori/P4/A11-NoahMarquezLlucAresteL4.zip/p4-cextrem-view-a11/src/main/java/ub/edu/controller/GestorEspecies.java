package ub.edu.controller;

import ub.edu.model.CeXtrem;
import ub.edu.model.especies.CarteraEspecies;
import ub.edu.model.especies.Especie;
import ub.edu.resources.services.DataService;

import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

public class GestorEspecies {
    private volatile static GestorEspecies uniqueInstance;
    private CeXtrem ceXtrem;

    private GestorEspecies(){
        ceXtrem = CeXtrem.getInstance();
    }

    public static GestorEspecies getInstance(){
        if(uniqueInstance == null){
            synchronized (GestorEspecies.class){
                if(uniqueInstance == null){
                    uniqueInstance = new GestorEspecies();
                }
            }
        }
        return uniqueInstance;
    }

    public boolean iniCarteraEspecies(DataService dataService) throws Exception {
        List<Especie> l = dataService.getAllEspecies(); // Està a la RAM, i li demanem que agafi la base de dades
        if (l != null) {
            ceXtrem.setCarteraEspecies(new CarteraEspecies(l));
            return true;
        } else return false;
    }

    public Especie find(String nomEspecie, String idExc){
        return ceXtrem.getCarteraEspecies().find(nomEspecie, idExc);
    }

    public Especie find(String nomEspecie){
        return ceXtrem.getCarteraEspecies().find(nomEspecie);
    }

    public Iterable<String> llistarCatalegEspecies() {
        return ceXtrem.getCarteraEspecies().llistarCatalegEspecies();
    }
}