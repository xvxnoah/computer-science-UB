package ub.edu.model.activities;

import ub.edu.model.valorations.Valoracio;

import java.util.*;

public class Activitat{
    private String nom;
    private String idExc;
    private int copsRealitzada;
    private Valoracio valoracio;

    public Activitat(String titol) {
        this.nom = titol;
    }

    public Activitat(String titol, String idExc) {
        this.nom = titol;
        this.idExc = idExc;
    }

    public void iniValoracio() {
        this.valoracio = new Valoracio();
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getIdExc() {
        return idExc;
    }

    public int getCopsRealitzada() {
        return copsRealitzada;
    }

    public void incrementCopsRealitzada(){
        this.copsRealitzada += 1;
    }

    public Valoracio getValoracio() {
        return valoracio;
    }

    public void setValoracio(Valoracio valoracio) {
        this.valoracio = valoracio;
    }

    public String valora(String tipusValoracio, int val) {
        return valoracio.addValoracio(tipusValoracio, val, nom);
    }

    public float calcValoracio(String tipusValoracio){
        return valoracio.calculaValoracio(tipusValoracio);
    }

    public List<String> getInfoValoracions(){
        return valoracio.getInfoValoracions();
    }

    public int comparebyNom(Activitat o2) {
        return this.getNom().compareTo(o2.getNom());
    }

    public int compareByValoration(Activitat o2, String tipusVal) {
        return valoracio.compare(o2.valoracio, tipusVal);
    }

    public int compareByRealitzades(Activitat o2){
        Integer numRealitzadesActivitat1 = this.copsRealitzada;
        Integer numRealitzadesActivitat2 = o2.getCopsRealitzada();

        return numRealitzadesActivitat2.compareTo(numRealitzadesActivitat1);
    }
}
