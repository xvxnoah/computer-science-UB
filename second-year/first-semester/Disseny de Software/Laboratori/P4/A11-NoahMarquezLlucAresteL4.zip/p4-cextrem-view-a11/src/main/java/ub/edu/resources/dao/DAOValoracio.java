package ub.edu.resources.dao;

import ub.edu.model.valorations.Valoracio;

public interface DAOValoracio extends DAO<Valoracio> {
}
