package ub.edu.resources.dao;

import ub.edu.model.localitzacions.Localitzacio;

public interface DAOLocalitzacio extends DAO<Localitzacio> {
}
