package ub.edu.view;

import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.WindowEvent;

import java.io.IOException;
import java.util.List;

public class EscenaExcursionsLocalitat extends Escena {
    private static final double ESPAI_ENTRE_BOTONS = 30;
    public Text localitat_text;
    public AnchorPane excursions_pane;
    public Button excursio_btn;


    public void setLocalitat(String localitat) {
        // TODO: Fer canvis per no mostrar dades dummy:
        localitat_text.setText(localitat);
        popularExcursions(localitat);
    }
    private void popularExcursions(String localitat){
        Iterable<String> iterableExcursions= controller.llistarCatalegExcursionsLocalitat(localitat);

        List<Node> excursionsPaneChildrem = excursions_pane.getChildren();

        double width = excursio_btn.getWidth();
        double height = excursio_btn.getHeight();
        double layoutX = excursio_btn.getLayoutX();
        double layoutY = excursio_btn.getLayoutY();
        //Instanciem un botó per cada localitzacio
        for (String excursio : iterableExcursions){
            Button new_btn = createExcursioButton(excursio, width, height, layoutX, layoutY);
            excursionsPaneChildrem.add(new_btn);
            layoutY += ESPAI_ENTRE_BOTONS;
        }
        //Actualitzem la mida del pane que conté els botons perque es pugui fer scroll cap abaix si hi ha més botons dels que caben al pane
        excursions_pane.setPrefHeight(layoutY);
        //Esborrem excursio_btn, que l'utilitzavem únicament com a referència per la mida dels botons
        excursionsPaneChildrem.remove(excursio_btn);
    }

    private Button createExcursioButton(String excursio, double width, double height, double layoutX, double layoutY){
        Button new_btn = new Button();
        new_btn.setPrefWidth(width);
        new_btn.setPrefHeight(height);
        new_btn.setText(excursio);
        new_btn.setLayoutX(layoutX);
        new_btn.setLayoutY(layoutY);
        new_btn.setAlignment(Pos.BASELINE_LEFT);
        new_btn.setOnMouseClicked(event ->
        {
            if (event.getButton() == MouseButton.PRIMARY)
            {
                try {
                    mostrarFinestraExcursio(excursio);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else if (event.getButton() == MouseButton.SECONDARY)
            {
                try {
                    mostrarFinestraActivitatsExcursio(excursio);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        return new_btn;
    }

    private void mostrarFinestraExcursio(String excursio) throws IOException {
        Escena escena = EscenaFactory.INSTANCE.creaEscena("excursio-view", excursio, stage.getOwner());
        EscenaExcursio escenaExcursio = ((EscenaExcursio)escena);
        escenaExcursio.setController(controller);
        escenaExcursio.setExcursio(excursio);

        stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent windowEvent){
                escenaExcursio.stage.close();
            }
        });
    }

    private void mostrarFinestraActivitatsExcursio(String excursio) throws IOException {
        Escena escena = EscenaFactory.INSTANCE.creaEscena("activitatsexcursio-view", excursio, stage.getOwner());
        EscenaActivitatsExcursio escenaActExcursio = ((EscenaActivitatsExcursio)escena);
        escenaActExcursio.setController(controller);
        escenaActExcursio.setExcursio(excursio);

        stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent windowEvent){
                escenaActExcursio.stage.close();
            }
        });
    }
}
