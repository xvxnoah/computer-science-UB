package ub.edu.resources.dao;

import ub.edu.model.especies.Especie;

public interface DAOEspecie extends DAO<Especie>
{

}
