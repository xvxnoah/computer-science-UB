package ub.edu.controller;

import ub.edu.model.CeXtrem;
import ub.edu.model.especies.CarteraEspecies;
import ub.edu.model.especies.Especie;
import ub.edu.model.localitzacions.CarteraLocalitzacions;
import ub.edu.model.localitzacions.Localitzacio;
import ub.edu.resources.services.DataService;

import java.util.*;

public class GestorLocalitzacions {
    private volatile static GestorLocalitzacions uniqueInstance;
    private CeXtrem ceXtrem;

    private GestorLocalitzacions(){
        ceXtrem = CeXtrem.getInstance();
    }

    public static GestorLocalitzacions getInstance(){
        if(uniqueInstance == null){
            synchronized (GestorExcursions.class){
                if(uniqueInstance == null){
                    uniqueInstance = new GestorLocalitzacions();
                }
            }
        }
        return uniqueInstance;
    }

    public boolean iniCarteraLocalitzacions(DataService dataService) throws Exception {
        List<Localitzacio> l = dataService.getAllLocalitzacions(); // Està a la RAM, i li demanem que agafi la base de dades
        if (l != null) {
            ceXtrem.setCarteraLocalitzacions(new CarteraLocalitzacions(l));
            return true;
        } else return false;
    }

    public Localitzacio findLocalitzacio(String localitzacio){
        return ceXtrem.getCarteraLocalitzacions().find(localitzacio);
    }

    public String getWebLocalitzacio(String localitzacio){
        Localitzacio loc = findLocalitzacio(localitzacio);
        return loc.getWeb();
    }

    public Iterable<String> getEspeciesLocalitzacio(String localitzacio){
        return ceXtrem.getCarteraLocalitzacions().getEspeciesLocalitzacio(localitzacio);
    }

    public Iterable<String> llistarCatalegLocalitats() {
        return ceXtrem.getCarteraLocalitzacions().llistarCatalegLocalitats();
    }
}
