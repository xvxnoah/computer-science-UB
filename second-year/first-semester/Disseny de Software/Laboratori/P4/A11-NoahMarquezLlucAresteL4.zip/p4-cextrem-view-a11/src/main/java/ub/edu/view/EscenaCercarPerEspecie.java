package ub.edu.view;

import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.stage.WindowEvent;

import java.io.IOException;
import java.util.List;

public class EscenaCercarPerEspecie extends Escena{
    private static final double ESPAI_ENTRE_BOTONS = 30;
    public Button especie_btn;
    public AnchorPane especie_pane;

    public void start() {
        popularEspecies();
    }

    private void popularEspecies(){
        Iterable<String> iterableEspecies= controller.llistarCatalegEspecies();
        List<Node> especiePaneChildren = especie_pane.getChildren();

        double width = especie_btn.getWidth();
        double height = especie_btn.getHeight();
        double layoutX = especie_btn.getLayoutX();
        double layoutY = especie_btn.getLayoutY();
        //Instanciem un botó per cada localitzacio
        for (String especie : iterableEspecies){
            Button new_btn = createEspecieButton(especie, width, height, layoutX, layoutY);
            especiePaneChildren.add(new_btn);
            layoutY += ESPAI_ENTRE_BOTONS;
        }
        //Actualitzem la mida del pane que conté els botons perque es pugui fer scroll cap abaix si hi ha més botons dels que caben al pane
        especie_pane.setPrefHeight(layoutY);
        //Esborrem excursio_btn, que l'utilitzavem únicament com a referència per la mida dels botons
        especiePaneChildren.remove(especie_btn);
    }

    private Button createEspecieButton(String especie, double width, double height, double layoutX, double layoutY){
        Button new_btn = new Button();
        new_btn.setPrefWidth(width);
        new_btn.setPrefHeight(height);
        new_btn.setText(especie);
        new_btn.setLayoutX(layoutX);
        new_btn.setLayoutY(layoutY);
        new_btn.setAlignment(Pos.BASELINE_LEFT);
        new_btn.setOnMouseClicked(event ->
        {
            if (event.getButton() == MouseButton.PRIMARY)
            {
                try {
                    mostrarFinestraExcursionsEspecie(especie);
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        });
        return new_btn;
    }

    private void mostrarFinestraExcursionsEspecie(String especie) throws IOException {
        //Nova finestra
        Escena escena = EscenaFactory.INSTANCE.creaEscena("excursionsespecie-view", especie, stage.getOwner());
        EscenaExcursionsEspecie escenaExcursionsEspecie = ((EscenaExcursionsEspecie)escena);
        escenaExcursionsEspecie.setController(controller);
        escenaExcursionsEspecie.setEspecie(especie);

        stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent windowEvent) {
                escenaExcursionsEspecie.stage.close();
            }
        });
    }
}
