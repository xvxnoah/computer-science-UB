package ub.edu.model.activities;

import ub.edu.model.CeXtrem;

import java.util.*;

public class CarteraActivitats extends Observable{
    private List<Activitat> llistaActivitats;

    public  CarteraActivitats() {
        llistaActivitats = new ArrayList<>();
    }

    public  CarteraActivitats(List<Activitat> activitats) {
        llistaActivitats = new ArrayList<>(activitats);
    }

    public List<Activitat> getLlistaActivitats() {
        return llistaActivitats;
    }

    public Activitat find(String nomActivitat) {
        for (Activitat e: llistaActivitats) {
            if (e.getNom().equals(nomActivitat)) return e;
        }
        return null;
    }

    public void add(String nomAct){
        llistaActivitats.add(new Activitat(nomAct));
    }

    public void add(Activitat activitat) {
        if(!llistaActivitats.contains(activitat)){
            llistaActivitats.add(activitat);
        }
    }

    public void addObs(Observer o){
        this.addObserver(o);
    }

    public Iterable<String> getActivitatsOrdenadesAlfabeticament() {
        List<Activitat> sortedList = getLlistaActivitats();

        sortedList.sort(new Comparator<Activitat>() {
            @Override
            public int compare(Activitat o1, Activitat o2) {
                return o1.comparebyNom(o2);
            }
        });

        List<String> llactivitats = new ArrayList<>();
        for (Activitat s : sortedList) {
            llactivitats.add(s.getNom());
        }
        if (llistaActivitats.isEmpty()){
            llactivitats.add("No hi han activitats enregistrades");
        }

        return llactivitats;
    }

    public Iterable<String> getTop10Valorades(String tipusVal) {
        List<Activitat> sortedList = getLlistaActivitats();

        sortedList.sort(new Comparator<Activitat>() {
            @Override
            public int compare(Activitat o1, Activitat o2) {
                return o2.compareByValoration(o1, tipusVal);
            }
        });

        List<String> llactivitats = new ArrayList<>();

        Iterator<Activitat> it = sortedList.iterator();

        int j=0;
        Activitat s;
        while(it.hasNext() && j<10) {
            s=it.next();

            if (s.calcValoracio(tipusVal)!=-1){
                llactivitats.add(s.getNom());
            }
            j++;
        }

        return llactivitats;
    }

    public List<Activitat> getTop10Realitzades(){
        List<Activitat> sortedList = getLlistaActivitats();

        sortedList.sort(Activitat::compareByRealitzades);

        List<Activitat> llactivitats = new ArrayList<>();

        Iterator<Activitat> it = sortedList.iterator();

        Activitat s;
        while(it.hasNext() && llactivitats.size() < 10) {
            s=it.next();
            if(s.getCopsRealitzada() != 0){
                llactivitats.add(s);
            }
        }

        return llactivitats;
    }

    public String marcarActivitatRealitzada(String nomAct, CarteraActivitats actRealitzades){
        CeXtrem ceXtrem = CeXtrem.getInstance();

        Activitat activitatCartera = ceXtrem.getCarteraActivitats().find(nomAct);

        // A la cartera de realitzades del soci
        Activitat activitat = actRealitzades.find(nomAct);

        // Si no l'ha realitzat anteriorment
        if(activitat == null) {
            activitatCartera.incrementCopsRealitzada();
            actRealitzades.add(activitatCartera);
            setChanged();
            notifyObservers("Realitzades");
            return "Activitat " + nomAct + " afegida com a realitzada";
        }
        return (nomAct + " ja està a la llista de realitzades del soci");
    }

    public String marcarActivitatPreferida(String nomAct, CarteraActivitats actPreferides){
        // Si no està a la cartera de preferides del soci
        if(find(nomAct) == null) {
            actPreferides.add(nomAct);
            return "Activitat " + nomAct + " afegida com a preferida";
        }
        return (nomAct + " ja està a la llista de preferides del soci");
    }

    public String valorarActivitat(String nomAct,String tipusVal, int valoracio, CarteraActivitats actRealitzades, CarteraActivitats actValorades) {
        Activitat act = actRealitzades.find(nomAct);

        // Si no ha realitzat l'activitat
        if (act==null){
            return "No has realitzat l'activitat: " + nomAct +", per tant no la pots valorar";
        }

        // Si ja l'ha valorat anteriorment
        if(actValorades.find(nomAct) != null){
            return "Ja has valorat l'activitat "+ nomAct + " anteriorment";
        }
        actValorades.add(act);

        // Agafem l'activitat de la cartera general per tal d'afegir-hi la valoració
        CeXtrem ceXtrem = CeXtrem.getInstance();
        Activitat activitat = ceXtrem.getCarteraActivitats().find(nomAct);

        String resultat = activitat.valora(tipusVal,valoracio);

        if(resultat.equals("Has valorat l'activitat " + nomAct + " amb una valoració de " + valoracio)||
                resultat.equals("Has valorat l'activitat " + nomAct + " amb una valoració de Like")||
                resultat.equals("Has valorat l'activitat " + nomAct + " amb una valoració de Dislike")){
            // Notifiquem als observers
            setChanged();
            notifyObservers(tipusVal);
        }
        return resultat;
    }

    public String getInfoActivitat(String activitat){
        Activitat ac = find(activitat);

        StringBuilder info = new StringBuilder();

        List<String> infoValoracions = ac.getInfoValoracions();

        for(String item : infoValoracions){
            info.append(item);
        }

        return info.toString();
    }

    public String getNomExc(String activitat) {
        Activitat activitat1=find(activitat);
        return activitat1.getIdExc();
    }

    public float calcValoracio(String activitat, String tipusVal) {
        Activitat activitat1=find(activitat);
        return activitat1.calcValoracio(tipusVal);
    }
}