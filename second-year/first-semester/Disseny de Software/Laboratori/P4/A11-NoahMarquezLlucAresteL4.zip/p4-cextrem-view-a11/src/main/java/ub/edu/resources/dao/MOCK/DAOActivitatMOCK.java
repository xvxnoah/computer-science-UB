package ub.edu.resources.dao.MOCK;

import ub.edu.model.activities.Activitat;
import ub.edu.resources.dao.DAOActivitat;

import java.util.*;

public class DAOActivitatMOCK implements DAOActivitat {
    private Map<String, Activitat> listActivitats = new HashMap<>();

    public DAOActivitatMOCK() {
        listActivitats.put("TORRENTISMO", new Activitat("TORRENTISMO", "El PedraForca"));
        listActivitats.put("BUNGEE JUMPING", new Activitat("BUNGEE JUMPING", "El camí des Correu"));
        listActivitats.put("ESCALADA", new Activitat("ESCALADA", "La Foradada"));
        listActivitats.put("BUCEO", new Activitat("BUCEO", "Aiguamolls de l'Empordà"));
        listActivitats.put("PAINT BALL", new Activitat("PAINT BALL", "Museu Miró"));
        listActivitats.put("KAYAK", new Activitat("KAYAK", "Aigüestortes i Sant Maurici"));
        listActivitats.put("PARAPENTE", new Activitat("PARAPENTE", "Cap de Creus i Cadaqués"));
        listActivitats.put("RAPPEL", new Activitat("RAPPEL", "Delta de l'Ebre"));
        listActivitats.put("CANYONING", new Activitat("CANYONING", "Aiguamolls de l'Empordà"));
        listActivitats.put("PROGRAMAR", new Activitat("PROGRAMAR", "Colònia Güell"));
        listActivitats.put("FERLAPRACTICA", new Activitat("FERLAPRACTICA", "Museu Miró"));
        listActivitats.put("BADMINTON", new Activitat("BADMINTON", "El camí des Correu"));
        listActivitats.put("VOLLEY", new Activitat("VOLLEY", "Cap de Creus i Cadaqués"));
        listActivitats.put("ESTUDIARPELFINAL", new Activitat("ESTUDIARPELFINAL", "El PedraForca"));
    }

    @Override
    public List<Activitat> getAll() {
        return new ArrayList<>(listActivitats.values());
    }

    @Override
    public Optional<Activitat> getById(String id) {
        return Optional.ofNullable(listActivitats.get(id));
    }

    @Override
    public boolean add(final Activitat activitat) {
        if (listActivitats.containsKey(activitat.getNom())) {
            return false;
        }
        listActivitats.put(activitat.getNom(), activitat);
        return true;
    }

    @Override
    public boolean update(final Activitat activitat, String[] params) {
        activitat.setNom(Objects.requireNonNull(
                params[0], "Name cannot be null"));
        return listActivitats.replace(activitat.getNom(), activitat) != null;
    }

    @Override
    public boolean delete(final Activitat activitat) {
        return listActivitats.remove(activitat.getNom()) != null;
    }
}















