package ub.edu.resources.dao;

import ub.edu.model.excursions.Excursio;

public interface DAOExcursio extends DAO<Excursio> {
}
