package ub.edu.controller;

import ub.edu.model.soci.Soci;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidarDadesSoci {
    private volatile static ValidarDadesSoci uniqueInstance;

    private ValidarDadesSoci(){
    }

    public static ValidarDadesSoci getInstance(){
        if(uniqueInstance == null){
            synchronized (ValidarDadesSoci.class){
                if(uniqueInstance == null){
                    uniqueInstance = new ValidarDadesSoci();
                }
            }
        }
        return uniqueInstance;
    }

    public String validateRegisterSoci(String username, String password) {
        if (isMail(username) && isPasswordSegur(password)) {
            GestorSoci gestorSoci=GestorSoci.getInstance();
            Soci Soci = gestorSoci.findSoci(username);
            if (Soci != null) {
                return "Soci Duplicat";
            } else return "Soci Validat";
        } else if(!isMail(username)){
            return "Correu en format incorrecte";
        } else{
            return "Contrassenya no segura";
        }
    }

    private boolean isPasswordSegur(String password) {
        Pattern pattern = Pattern.compile("^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,}$");
        Matcher matcher = pattern.matcher(password);
        return matcher.find();
    }
    private boolean isMail(String correu) {
        Pattern pattern = Pattern.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
        Matcher matcher = pattern.matcher(correu);
        return matcher.find();
    }
}