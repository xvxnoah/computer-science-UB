package ub.edu.resources.dao;

import ub.edu.model.activities.Activitat;

public interface DAOActivitat extends DAO<Activitat> {

}
