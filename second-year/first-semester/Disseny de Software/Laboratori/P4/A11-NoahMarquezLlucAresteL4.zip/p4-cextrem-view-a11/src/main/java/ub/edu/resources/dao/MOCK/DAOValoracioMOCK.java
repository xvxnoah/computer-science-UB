package ub.edu.resources.dao.MOCK;

import ub.edu.model.activities.Activitat;
import ub.edu.model.valorations.Valoracio;
import ub.edu.resources.dao.DAOValoracio;

import java.util.*;

public class DAOValoracioMOCK implements DAOValoracio {
    private Map<String, Valoracio> listValoracions = new HashMap<>();
    public DAOValoracioMOCK(){
        listValoracions.put("TORRENTISMO",new Valoracio("TORRENTISMO",2,5,7,2));
        listValoracions.put("BUNGEE JUMPING",new Valoracio("BUNGEE JUMPING",1,3,4,1));
        listValoracions.put("KAYAK",new Valoracio("KAYAK",2,7,3,5));
        listValoracions.put("PAINT BALL",new Valoracio("PAINT BALL",1,1,5,0));
        listValoracions.put("PARAPENTE",new Valoracio("PARAPENTE",1,5,2,0));
        listValoracions.put("RAPPEL",new Valoracio("RAPPEL",1,2,6,1));
        listValoracions.put("ESCALADA",new Valoracio("ESCALADA",1,4,0,0));
        listValoracions.put("FERLAPRACTICA",new Valoracio("FERLAPRACTICA",2,3,8,2));
        listValoracions.put("PROGRAMAR",new Valoracio("PROGRAMAR",2,9,10,2));
        listValoracions.put("BADMINTON",new Valoracio("BADMINTON",4,5,9,3));
        listValoracions.put("VOLLEY",new Valoracio("VOLLEY",4,17,1,4));
        listValoracions.put("BUCEO", new Valoracio("BUCEO", 0, 0, 6, 0));
        listValoracions.put("CANYONING", new Valoracio("CANYONING", 0, 0, 0, 3));
    }

    @Override
    public Optional<Valoracio> getById(String id) throws Exception {
        return Optional.empty();
    }

    @Override
    public List<Valoracio> getAll() throws Exception {
        return new ArrayList<>((listValoracions.values()));
    }

    @Override
    public boolean add(Valoracio valoracio) throws Exception {
        return false;
    }

    @Override
    public boolean update(Valoracio valoracio, String[] params) throws Exception {
        return false;
    }

    @Override
    public boolean delete(Valoracio valoracio) throws Exception {
        return false;
    }
}
