package ub.edu.model.valorations;


public class ValoracioLike implements ValoracioStrategy{
    private int numLikes;

    public ValoracioLike(){
        numLikes=0;
    }

    public ValoracioLike(int numLikes){
        this.numLikes=numLikes;
    }

    @Override
    public void addValoracio(int valoracio){
        if (valoracio == 1) numLikes++;
    }

    @Override
    public float calculaValoracio(){
        if(numLikes == 0) return -1;
        return numLikes;
    }

    @Override
    public String getValor(int valoracio){
        return "Like";
    }

    @Override
    public String getInfo(){
        if (numLikes != 0) return "Likes: "+ numLikes + "\n";
        return "Likes: 0\n";
    }
}