package ub.edu.resources.dao.MOCK;

import org.jetbrains.annotations.NotNull;
import ub.edu.model.especies.Especie;
import ub.edu.resources.dao.DAOEspecie;

import java.util.*;

public class DAOEspecieMOCK implements DAOEspecie{
    private Map<String, Especie> listEspecies = new HashMap<>();

    public DAOEspecieMOCK() {
        addEspecie("Llúdriga", "Barcelona");
        addEspecie("Gripau", "Sabadell");
        addEspecie("Serp", "Banyalbufar");
        addEspecie( "Sargantana", "Delta");
        addEspecie( "Voltor", "Pedraforca");
        addEspecie( "Garsa", "Cardona");
        addEspecie("Guineu", "Aiguamolls");
        addEspecie("Senglar", "Cadaqués");
        addEspecie( "Perdiu", "Parc Nacional");
        addEspecie("Marieta", "Terrassa");
        addEspecie("Papallona", "Esporles");
        addEspecie("Saltamarti", "Salou");
        addEspecie("Borinot", "Saldes");
        addEspecie("Granota", "Manresa");
        addEspecie("Canari", "Solsona");
        addEspecie("Corb", "Figueres");
        addEspecie("Elefant", "Roses");
        addEspecie("Lleo", "Llavorsí");
    }

    private void addEspecie(String nom, String idLocalitzacio) {
        listEspecies.put(nom, new Especie(nom, idLocalitzacio));
    }

    @Override
    public List<Especie> getAll() {
        return new ArrayList<>(listEspecies.values());
    }

    @Override
    public Optional<Especie> getById(String id) {
        return Optional.ofNullable(listEspecies.get(id));
    }

    @Override
    public boolean add(final Especie especie) {
        if (getById(especie.getNom()).isPresent()) {
            return false;
        }
        listEspecies.put(especie.getNom(), especie);
        return true;
    }

    @Override
    public boolean update(final Especie especie, String[] params) {
        especie.setNom(Objects.requireNonNull(
                params[0], "Title cannot be null"));
        return listEspecies.replace(especie.getNom(), especie) != null;
    }

    @Override
    public boolean delete(final @NotNull Especie especie) {
        return listEspecies.remove(especie.getNom()) != null;
    }

}
