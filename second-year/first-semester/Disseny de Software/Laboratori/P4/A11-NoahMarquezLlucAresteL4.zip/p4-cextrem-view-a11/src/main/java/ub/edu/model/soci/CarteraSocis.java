package ub.edu.model.soci;

import ub.edu.model.soci.Soci;

import java.util.ArrayList;
import java.util.List;

public class CarteraSocis {
    private List<Soci> llistaSocis;

    public CarteraSocis() {
        llistaSocis = new ArrayList<>();
    }
    public CarteraSocis(List<Soci> allSocis) {
        llistaSocis = allSocis;
    }

    public void addSoci (Soci soci){
        llistaSocis.add(soci);
    }

    public Soci find(String username) {
        for (Soci c: llistaSocis) {
            if (c.getName().equals(username)) return c;
        }
        return null;

    }

}