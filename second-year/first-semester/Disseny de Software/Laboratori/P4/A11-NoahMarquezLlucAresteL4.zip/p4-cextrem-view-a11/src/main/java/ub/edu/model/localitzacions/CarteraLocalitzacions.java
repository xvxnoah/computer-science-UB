package ub.edu.model.localitzacions;

import ub.edu.model.especies.Especie;
import ub.edu.model.excursions.Excursio;

import java.util.ArrayList;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

public class CarteraLocalitzacions {
    private List<Localitzacio> llistaLocalitzacions;

    public CarteraLocalitzacions() {
        this.llistaLocalitzacions = new ArrayList<>();
    }

    public CarteraLocalitzacions(List<Localitzacio> allLocalitzacions) {
        llistaLocalitzacions = allLocalitzacions;
    }

    public List<Localitzacio> getLlista() {
        return llistaLocalitzacions;
    }

    public void setLlista(List<Localitzacio> llista) {
        this.llistaLocalitzacions = llista;
    }

    public Localitzacio find(String nomLocalitzacio) {
        Localitzacio localitzacio = null;
        for (Localitzacio e : llistaLocalitzacions) {
            if (e.getNom().equals(nomLocalitzacio)) localitzacio = e;
        }
        return localitzacio;
    }

    public void add(Localitzacio localitzacio) {
        if (localitzacio != null) llistaLocalitzacions.add(localitzacio);
    }

    public boolean isEmpty(){
        return llistaLocalitzacions.isEmpty();
    }

    public Iterable<String> llistarCatalegLocalitats(){
        SortedSet<String> localitzacionsDisponibles = new TreeSet<>();

        if(this.isEmpty()){
            localitzacionsDisponibles.add("No hi ha localitzacions disponibles");
        } else{
            for(Localitzacio localitzacio : this.getLlista()){
                localitzacionsDisponibles.add(localitzacio.getNom());
            }
        }
        return localitzacionsDisponibles;
    }

    public Iterable<String> getEspeciesLocalitzacio(String localitzacio){
        Localitzacio lcl = find(localitzacio);

        List<String> especiesLcl = new ArrayList<>();

        List<Especie> especiesLocalitzacio = lcl.getEspecies().getLlistaEspecies();

        for(Especie especie : especiesLocalitzacio){
            especiesLcl.add(especie.getNom());
        }

        return especiesLcl;
    }
}
