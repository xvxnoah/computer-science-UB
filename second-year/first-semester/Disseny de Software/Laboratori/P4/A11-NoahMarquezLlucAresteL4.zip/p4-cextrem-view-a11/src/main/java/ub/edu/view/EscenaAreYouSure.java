package ub.edu.view;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.text.Text;

import java.io.IOException;

public class EscenaAreYouSure extends Escena{
    public Button closeApp_btn;
    public Button signOut_btn;

    public void start(){
        closeApp_btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                Platform.exit();
            }
        });

        signOut_btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try{
                    Escena login = EscenaFactory.INSTANCE.creaEscena("login-view", "Login");

                    //Li enviem la finestra (stage) i el controlador a la nova escena
                    login.setController(controller);
                    stage.close();
                } catch (IOException e){
                    e.printStackTrace();
                }
            }
        });
    }
}
