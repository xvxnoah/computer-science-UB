package ub.edu.model.soci;

import ub.edu.controller.Controller;
import ub.edu.controller.GestorActivitats;
import ub.edu.model.activities.CarteraActivitats;

import java.util.Observer;

public class Soci {
    private String pwd;
    private String nom;
    private CarteraActivitats actRealitzades;
    private CarteraActivitats actPreferides;
    private CarteraActivitats actValorades;

    public Soci(String nom, String pwd) {
        this.pwd = pwd;
        this.nom = nom;
    }

    public void iniCarteres(){
        this.actRealitzades=new CarteraActivitats();
        this.actPreferides=new CarteraActivitats();
        this.actValorades=new CarteraActivitats();
    }

    public void addObs(Observer o){
        actRealitzades.addObs(o);
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getName() {
        return nom;
    }

    public void setName(String nom) {
        this.nom = nom;
    }

    public CarteraActivitats getActivitatsRealitzades(){
        return this.actRealitzades;
    }
    public CarteraActivitats getActivitatsPreferides(){
        return this.actPreferides;
    }

    public String addActivitatPreferida(String nomAct){
        return actPreferides.marcarActivitatPreferida(nomAct, actPreferides);
    }

    public String addActivitatRealitzada(String nomAct){
        return actRealitzades.marcarActivitatRealitzada(nomAct, actRealitzades);
    }

    public String addValoracio(String nomAct,String tipusVal, int valoracio) {
        return actRealitzades.valorarActivitat(nomAct, tipusVal, valoracio, actRealitzades, actValorades);
    }
}