package ub.edu.view;

import javafx.scene.control.Hyperlink;
import javafx.scene.control.ListView;
import javafx.scene.text.Text;

public class EscenaLocalitzacio extends Escena{

    public Text ubicacio_text;
    public Hyperlink link_text;
    public ListView especies_list;

    public void setLocalitzacio(String nomLocalitzacio) {
        // TODO: Fer canvis per no mostrar dades dummy:
        ubicacio_text.setText(nomLocalitzacio);
        link_text.setText(controller.getWebLocalitzacio(nomLocalitzacio));
        Iterable<String> especies = controller.getEspeciesLocalitzacio(nomLocalitzacio);

        for(String especie : especies){
            especies_list.getItems().add(especie);
        }
    }
}
