package ub.edu.resources.services;

import ub.edu.resources.dao.*;
import ub.edu.resources.dao.MOCK.*;

public class FactoryMOCK implements AbstractFactoryData{
    @Override
    public DAOSoci createDAOSoci() {
        return new DAOSociMOCK();
    }

    @Override
    public DAOActivitat createDAOActivitat(){ return new DAOActivitatMOCK();}

    @Override
    public DAOEspecie createDAOEspecie(){ return new DAOEspecieMOCK();}

    @Override
    public DAOExcursio createDAOExcursio() { return new DAOExcursioMOCK();}

    @Override
    public DAOLocalitzacio createDAOLocalitzacio() { return new DAOLocalitzacioMOCK();}

    @Override
    public DAOValoracio createDAOValoracio() { return new DAOValoracioMOCK(); }

    @Override
    public DAOActivitatsRealitzades createDAOActivitatsRealitzades() { return new DAOActivitatsRealitzadesMOCK();}
}
