package ub.edu.view;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

import java.io.IOException;


public class EscenaExcursio extends Escena{

    public Text excursio_text;
    public Text data_text;
    public Button origen_btn;
    public Button desti_btn;
    public Button activitats_btn;

    public void setExcursio(String nomExcursio) {
        excursio_text.setText(nomExcursio);
        // TODO: Fer canvis per no mostrar dades dummy:
        data_text.setText(controller.getDataExcursio(nomExcursio).toString());
        origen_btn.setText(controller.getOrigenExcursio(nomExcursio));
        desti_btn.setText(controller.getDestiExcursio(nomExcursio));
        origen_btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    mostrarFinestraLocalitzacio(origen_btn.getText());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        desti_btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    mostrarFinestraLocalitzacio(desti_btn.getText());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        activitats_btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    mostrarFinestraActivitatsExcursio(nomExcursio);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void mostrarFinestraLocalitzacio(String localitzacio) throws IOException {
        Escena escena = EscenaFactory.INSTANCE.creaEscena("localitzacio-view", localitzacio, stage.getOwner());
        EscenaLocalitzacio escenaLocalitzacio = ((EscenaLocalitzacio)escena);
        escenaLocalitzacio.setController(controller);
        escenaLocalitzacio.setLocalitzacio(localitzacio);
        stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent windowEvent) {
                escenaLocalitzacio.stage.close();
                stage.close();
            }
        });

        if(!stage.isShowing()){
            escenaLocalitzacio.stage.close();
        }
    }

    private void mostrarFinestraActivitatsExcursio(String excursio) throws IOException {
        Escena escena = EscenaFactory.INSTANCE.creaEscena("activitatsexcursio-view", excursio, stage.getOwner());
        EscenaActivitatsExcursio escenaActExcursio = ((EscenaActivitatsExcursio)escena);
        escenaActExcursio.setController(controller);
        escenaActExcursio.setExcursio(excursio);
        stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent windowEvent) {
                escenaActExcursio.stage.close();
            }
        });
    }
}
