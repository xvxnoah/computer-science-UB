package ub.edu.resources.dao;

import ub.edu.model.activities.Activitat;

import java.util.Collection;
import java.util.List;

public interface DAOActivitatsRealitzades extends DAO<Activitat>{
    Collection<List<String>> getAllAct();
    List<String> getAllSocis();
}
