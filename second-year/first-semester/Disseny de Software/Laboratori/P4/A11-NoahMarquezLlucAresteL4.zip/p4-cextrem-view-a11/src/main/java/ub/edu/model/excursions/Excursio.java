package ub.edu.model.excursions;

import ub.edu.model.localitzacions.Localitzacio;
import ub.edu.model.activities.Activitat;
import ub.edu.model.activities.CarteraActivitats;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class Excursio {
    private String nom;
    private Localitzacio origen;
    private Localitzacio desti;
    private String idOrigen;
    private String idDesti;
    private LocalDate data;
    private CarteraActivitats activitats;

    public Excursio(String titol, String dataText, String origen, String desti) {
        this.nom = titol;
        this.idOrigen = origen;
        this.idDesti = desti;
        setData(dataText);
    }

    public void iniCarteres(){
        this.activitats = new CarteraActivitats();
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public LocalDate getData(){
        return this.data;
    }

    public void setData(String dataText){
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        this.data = LocalDate.parse(dataText, formatter);
    }

    public void setOrigen(Localitzacio origen) {
        this.origen = origen;
    }

    public String getOrigen() {
        return idOrigen;
    }

    public void setDesti(Localitzacio desti) {
        this.desti = desti;
    }

    public String getDesti() {
        return idDesti;
    }

    public CarteraActivitats getActivitats() {
        return activitats;
    }

    public void setActivitats(List<Activitat> llistaActivitats) {
        this.activitats = new CarteraActivitats(llistaActivitats);
    }

    public Localitzacio getOrigenLoc(){
        return origen;
    }

    public Localitzacio getDestiLoc(){
        return desti;
    }
}