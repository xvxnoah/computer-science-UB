package ub.edu.resources.services;

import ub.edu.controller.GestorActivitats;
import ub.edu.controller.GestorExcursions;
import ub.edu.controller.GestorLocalitzacions;
import ub.edu.controller.GestorSoci;
import ub.edu.model.activities.Activitat;
import ub.edu.model.especies.Especie;
import ub.edu.model.excursions.Excursio;
import ub.edu.model.localitzacions.Localitzacio;
import ub.edu.model.soci.Soci;
import ub.edu.model.valorations.Valoracio;
import ub.edu.resources.dao.*;

import java.util.*;

public class DataService {
    private DAOSoci daoSoci;
    private DAOActivitat daoActivitat;
    private DAOEspecie daoEspecie;
    private DAOExcursio daoExcursio;
    private DAOLocalitzacio daoLocalitzacio;
    private DAOValoracio daoValoracio;
    private DAOActivitatsRealitzades daoActivitatsRealitzades;

    public DataService(AbstractFactoryData factory){
        this.daoSoci = factory.createDAOSoci();
        this.daoActivitat = factory.createDAOActivitat();
        this.daoEspecie = factory.createDAOEspecie();
        this.daoExcursio = factory.createDAOExcursio();
        this.daoLocalitzacio = factory.createDAOLocalitzacio();
        this.daoValoracio = factory.createDAOValoracio();
        this.daoActivitatsRealitzades = factory.createDAOActivitatsRealitzades();
    }

    public void relateEspeciesLocalitzacions() throws Exception{
        for(Especie especie : getAllEspecies()){
            if(especie.getIdLocalitzacio() != null){
                GestorLocalitzacions gestorLocalitzacions = GestorLocalitzacions.getInstance();
                Localitzacio localitzacio = gestorLocalitzacions.findLocalitzacio(especie.getIdLocalitzacio());
                localitzacio.getEspecies().add(especie);
            }
        }
    }

    public void relateExcursionsLocalitzacions() throws Exception{
        for(Excursio excursio : getAllExcursions()){
            GestorLocalitzacions gestorLocalitzacions = GestorLocalitzacions.getInstance();
            if(excursio.getOrigen() != null){
                Localitzacio localitzacio = gestorLocalitzacions.findLocalitzacio(excursio.getOrigen());
                excursio.setOrigen(localitzacio);
            }
            if(excursio.getDesti() != null){
                Localitzacio localitzacio = gestorLocalitzacions.findLocalitzacio(excursio.getDesti());
                excursio.setDesti(localitzacio);
            }
        }
    }

    public void relateActivitatsExcursions() throws Exception{
        for(Activitat activitat : getAllActivitats()){
            if(activitat.getIdExc() != null){
                GestorExcursions gestorExcursions=GestorExcursions.getInstance();
                Excursio excursio = gestorExcursions.find(activitat.getIdExc());
                excursio.getActivitats().add(activitat);
            }
        }
    }

    public void relateActivitatsValoracions() throws Exception{
        for(Valoracio valoracio : getAllValorations()){
            if(valoracio.getIdActivitat() != null){
                GestorActivitats gestorActivitats = GestorActivitats.getInstance();
                Activitat activitat = gestorActivitats.find(valoracio.getIdActivitat());
                activitat.setValoracio(valoracio);
            }
        }
    }

    public void relateSocisActsRealitzades(){
        int sociActual, posLlista;
        GestorSoci gestorSoci = GestorSoci.getInstance();
        GestorActivitats gestorActivitats = GestorActivitats.getInstance();
        Soci soci;
        Activitat activitat;

        sociActual = 0;

        for(String emailSoci : getSocisRealitzades()){
            soci = gestorSoci.findSoci(emailSoci);
            posLlista = 0;
            for(List<String> listRealitzades: getAllRealitzades()){
                if(sociActual == posLlista){
                    for(String act : listRealitzades){
                        activitat = gestorActivitats.find(act);
                        activitat.incrementCopsRealitzada();
                        soci.getActivitatsRealitzades().add(activitat);
                    }
                }
                posLlista++;

            }
            sociActual++;
        }
    }

    public String loguejarSoci(String username, String password) throws Exception{
        Optional<Soci> optional = daoSoci.getById(username);

        if(!optional.isPresent()){
            return "Correu inexistent";
        }

        Soci soci = optional.get();

        if(soci.getPwd().equals(password)){
            return "Login correcte";
        }

        return "Contrassenya incorrecta";
    }

    public String recuperarContrassenya(String username) throws Exception{
        Optional<Soci> optional = daoSoci.getById(username);

        if(!optional.isPresent()){
            return "Correu inexistent";
        }

        Soci soci = optional.get();
        return soci.getPwd();
    }

    public void registerSoci(String user, String pass){
        try{
            daoSoci.add(new Soci(user, pass));
        } catch (Exception e){

        }
    }

    public void inicialitzaCarteres() throws Exception{
        for(Soci soci : getAllSocis()){
            soci.iniCarteres();
        }

        for(Excursio excursio : getAllExcursions()){
            excursio.iniCarteres();
        }

        for(Activitat activitat : getAllActivitats()){
            activitat.iniValoracio();
        }

        for(Localitzacio localitzacio : getAllLocalitzacions()){
            localitzacio.iniCartera();
        }
    }

    public List<Soci> getAllSocis() throws Exception {
        return daoSoci.getAll();
    }

    public List<Activitat> getAllActivitats() throws Exception{
        return daoActivitat.getAll();
    }

    public List<Especie> getAllEspecies() throws Exception {
        return daoEspecie.getAll();
    }

    public List<Excursio> getAllExcursions() throws Exception {
        return daoExcursio.getAll();
    }

    public List<Localitzacio> getAllLocalitzacions() throws Exception {
        return daoLocalitzacio.getAll();
    }

    public List<Valoracio> getAllValorations() throws Exception{
        return daoValoracio.getAll();
    }

    public Collection<List<String>> getAllRealitzades(){
        return daoActivitatsRealitzades.getAllAct();
    }

    public List<String> getSocisRealitzades() {return daoActivitatsRealitzades.getAllSocis();}
}