package ub.edu.resources.services;

import ub.edu.resources.dao.*;

public interface AbstractFactoryData {
    DAOSoci createDAOSoci();
    DAOActivitat createDAOActivitat();
    DAOEspecie createDAOEspecie();
    DAOExcursio createDAOExcursio();
    DAOLocalitzacio createDAOLocalitzacio();
    DAOValoracio createDAOValoracio();
    DAOActivitatsRealitzades createDAOActivitatsRealitzades();
}
