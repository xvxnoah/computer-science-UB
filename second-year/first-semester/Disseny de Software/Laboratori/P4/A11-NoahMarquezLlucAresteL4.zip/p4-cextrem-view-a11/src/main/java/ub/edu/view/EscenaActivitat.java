package ub.edu.view;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.text.Text;

import java.io.IOException;
import java.util.Observable;
import java.util.Observer;


public class EscenaActivitat extends Escena implements Observer {

    public Text activitat_text;
    public Text data_text;
    public Button apuntarse_btn;
    public Button valorar_btn;
    private String nomActivitat;

    public void setActivitat(String nomActivitat) {
        this.nomActivitat = nomActivitat;
        activitat_text.setText(nomActivitat);
        data_text.setText(controller.getDadesActivitat(nomActivitat));
        controller.observersToClasses(this);
        apuntarse_btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                String resultat = controller.afegirActivitatRealitzada(controller.getActualUser(), nomActivitat);

                if(resultat.equals(nomActivitat + " ja està a la llista de realitzades del soci")){
                    alert.setAlertType(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText("Error al apuntar-se");
                    alert.setContentText(resultat);
                } else{
                    alert.setTitle("Èxit");
                    alert.setHeaderText("Apuntat correctament");
                    alert.setContentText(resultat);
                }
                alert.showAndWait();
            }
        });

        valorar_btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try{
                    mostrarFinestraValoracio(nomActivitat);
                } catch (IOException e){
                    e.printStackTrace();
                }
            }
        });
    }

    public void mostrarFinestraValoracio(String nomActivitat) throws IOException {
        Escena escena = EscenaFactory.INSTANCE.creaEscena("valoracio-view", "VALORAR", stage.getOwner());
        EscenaValoracio escenaValoracio = ((EscenaValoracio)escena);
        escenaValoracio.setController(controller);
        escenaValoracio.setValoracio(nomActivitat);

    }


    @Override
    public void update(Observable o, Object arg) {
        String res = arg.toString();
        if(res.startsWith("Valoracio")){
            data_text.setText(controller.getDadesActivitat(nomActivitat));
        }
    }
}
