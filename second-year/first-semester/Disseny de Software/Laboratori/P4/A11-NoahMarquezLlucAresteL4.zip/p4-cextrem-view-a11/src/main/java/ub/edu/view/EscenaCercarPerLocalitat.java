package ub.edu.view;

import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.stage.WindowEvent;

import java.io.IOException;
import java.util.List;

public class EscenaCercarPerLocalitat extends Escena{
    private static final double ESPAI_ENTRE_BOTONS = 30;
    public Button localitat_btn;
    public AnchorPane localitat_pane;

    public void start() {
        popularLocalitats();
    }
    private void popularLocalitats(){
        Iterable<String> iterableLocalitats= controller.llistarCatalegLocalitats();
        List<Node> localitatPaneChildren = localitat_pane.getChildren();

        double width = localitat_btn.getWidth();
        double height = localitat_btn.getHeight();
        double layoutX = localitat_btn.getLayoutX();
        double layoutY = localitat_btn.getLayoutY();
        //Instanciem un botó per cada localitzacio
        for (String localitat : iterableLocalitats){
            Button new_btn = createLocalitatButton(localitat, width, height, layoutX, layoutY);
            localitatPaneChildren.add(new_btn);
            layoutY += ESPAI_ENTRE_BOTONS;
        }
        //Actualitzem la mida del pane que conté els botons perque es pugui fer scroll cap abaix si hi ha més botons dels que caben al pane
        localitat_pane.setPrefHeight(layoutY);
        //Esborrem excursio_btn, que l'utilitzavem únicament com a referència per la mida dels botons
        localitatPaneChildren.remove(localitat_btn);
    }

    private Button createLocalitatButton(String localitat, double width, double height, double layoutX, double layoutY){
        Button new_btn = new Button();
        new_btn.setPrefWidth(width);
        new_btn.setPrefHeight(height);
        new_btn.setText(localitat);
        new_btn.setLayoutX(layoutX);
        new_btn.setLayoutY(layoutY);
        new_btn.setAlignment(Pos.BASELINE_LEFT);
        new_btn.setOnMouseClicked(event ->
        {
            if (event.getButton() == MouseButton.PRIMARY)
            {
                try {
                    mostrarFinestraExcursionsLocalitat(localitat);
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        });
        return new_btn;
    }

    private void mostrarFinestraExcursionsLocalitat(String localitat) throws IOException {
        Escena escena = EscenaFactory.INSTANCE.creaEscena("excursionslocalitat-view", localitat, stage.getOwner());
        EscenaExcursionsLocalitat escenaExcursionsLocalitat = ((EscenaExcursionsLocalitat)escena);
        escenaExcursionsLocalitat.setController(controller);
        escenaExcursionsLocalitat.setLocalitat(localitat);

        stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent windowEvent) {
                escenaExcursionsLocalitat.stage.close();
            }
        });


    }
}
