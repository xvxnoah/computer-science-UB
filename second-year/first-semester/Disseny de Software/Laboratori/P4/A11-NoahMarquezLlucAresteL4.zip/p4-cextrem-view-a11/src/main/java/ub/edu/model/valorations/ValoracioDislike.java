package ub.edu.model.valorations;


public class ValoracioDislike implements ValoracioStrategy {
    private int numDisLikes;

    public ValoracioDislike() {
        numDisLikes = 0;
    }

    public ValoracioDislike(int numDisLikes){
        this.numDisLikes=numDisLikes;
    }

    @Override
    public void addValoracio(int valoracio) {
        if (valoracio == 1) numDisLikes++;
    }

    @Override
    public float calculaValoracio() {
        if (numDisLikes == 0) return -1;
        return numDisLikes;
    }

    @Override
    public String getValor(int valoracio) {
        return "Dislike";
    }

    @Override
    public String getInfo() {
        if (numDisLikes != 0) return "Dislikes: "+ numDisLikes + "\n";
        return "Dislikes: 0\n";
    }
}
