package ub.edu.view;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Slider;
import javafx.scene.text.Text;

public class EscenaValoracioNumerica extends Escena{
    public Button valorar_btn;
    public Slider valorar_slide;
    public Text info_text;
    public Text activitatAValorar;


    public void setValoracioNumerica(String activitatAValorar){
        info_text.setText("Selecciona una valoració entre 1 - 5 estrelles:");
        this.activitatAValorar.setText(activitatAValorar);
    }

    @FXML
    protected void onValorarButtonClick(){
        int valoracio = (int) valorar_slide.getValue();

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        String resultat = controller.valoraActivitat(controller.getActualUser(), activitatAValorar.getText(), "ValoracioNumerica", valoracio);
        handleErrors(alert, resultat, activitatAValorar.getText());
        stage.close();
    }

    private void handleErrors(Alert alert, String resultat, String activitatAValorar) {
        if(resultat.equals("No has realitzat l'activitat: " + activitatAValorar +", per tant no la pots valorar")){
            alert.setAlertType(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Error al valorar");
            alert.setContentText(resultat);
        } else if(resultat.equals("Ja has valorat l'activitat "+ activitatAValorar + " anteriorment")){
            alert.setAlertType(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Error al valorar");
            alert.setContentText(resultat);
        } else{
            alert.setTitle("Èxit");
            alert.setHeaderText(activitatAValorar + " valorada correctament!");
            alert.setContentText(resultat);
        }
        alert.showAndWait();
    }
}
