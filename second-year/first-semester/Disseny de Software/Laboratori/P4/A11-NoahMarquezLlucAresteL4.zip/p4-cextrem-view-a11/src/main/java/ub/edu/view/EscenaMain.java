package ub.edu.view;

import javafx.beans.property.SimpleStringProperty;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.stage.WindowEvent;
import ub.edu.model.activities.Activitat;

import java.io.IOException;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

public class EscenaMain extends Escena implements Observer {
    private static final double ESPAI_ENTRE_BOTONS = 30;

    public Button excursio_btn;
    public AnchorPane excursions_pane;
    public TableColumn excursioFetaColumn;
    public TableView tableTop10Fetes;
    public TableColumn activitatFetaColumn;
    public TableColumn vegadesFetaColumn;
    public TableView tableTop10ValoradesNumericament;
    public TableColumn excursioValNumColumn;
    public TableColumn activitatValNumColumn;
    public TableColumn valoracioValNumColumn;
    public TableView tableTop10Likes;
    public TableColumn excursioValLikesColumn;
    public TableColumn activitatValLikesColumn;
    public TableColumn nombreLikesColumn;
    public TableView tableTop10Dislikes;
    public TableColumn excursioValDislikesColumn;
    public TableColumn activitatValDislikesColumn;
    public TableColumn nombreDislikesColumn;

    public void start() throws IOException{
        popularExcursionsPerNom();
        popularTopActivitatsFetes();
        popularTopActivitatsValorades();
        popularTopActivitatsLikes();
        popularTopActivitatsDislikes();
        controller.observersToClasses(this);
        stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent windowEvent){
                try{
                    onCloseButton();
                } catch (IOException e){
                    e.printStackTrace();
                }
            }
        });
    }

    @Override
    public void update(Observable o, Object arg) {
        switch ((String) arg){
            case "Realitzades": popularTopActivitatsFetes();
                break;
            case "ValoracioNumerica": popularTopActivitatsValorades();
                break;
            case "ValoracioLike": popularTopActivitatsLikes();
                break;
            case "ValoracioDislike": popularTopActivitatsDislikes();
                break;
            default:
                break;
        }
    }

    /*
    * Aquesta inner Class la associarem als items de la taula en el mètode popularTopActivitatsFetes
    * Seguir aquesta estructura per popular taules
    * */
    public static class ActivitatTop {
        //Cal deixar aquests atributs com finals per poder popular la taula en el mètode popularTopActivitatsFetes
        private final SimpleStringProperty nomExcursio;
        private final SimpleStringProperty nomActivitat;
        private final SimpleStringProperty puntuacio;

        ActivitatTop(String nomExcursio, String nomActivitat, Float puntuacio){
            this.nomExcursio = new SimpleStringProperty(nomExcursio); //Excursió a la qual pertany l'activitat
            this.nomActivitat = new SimpleStringProperty(nomActivitat);
            this.puntuacio = new SimpleStringProperty(puntuacio.toString());
        }

        ActivitatTop(String nomExcursio, String nomActivitat, int puntuacio){
            this.nomExcursio = new SimpleStringProperty(nomExcursio); //Excursió a la qual pertany l'activitat
            this.nomActivitat = new SimpleStringProperty(nomActivitat);
            this.puntuacio = new SimpleStringProperty(String.valueOf(puntuacio));
        }

        public String getNomExcursio() {
            return nomExcursio.get();
        }

        public String getNomActivitat() {
            return nomActivitat.get();
        }

        public String getPuntuacio() {
            return puntuacio.get();
        }

    }
    private void popularTopActivitatsFetes() {
        //Aquí posem a quins atributs de la classe EspecieVista correspon cada columna de la taula:
        excursioFetaColumn.setCellValueFactory(new PropertyValueFactory<ActivitatTop, String>("nomExcursio"));
        activitatFetaColumn.setCellValueFactory(new PropertyValueFactory<ActivitatTop, String>("nomActivitat"));
        vegadesFetaColumn.setCellValueFactory(new PropertyValueFactory<ActivitatTop, String>("puntuacio"));
        // TODO: Fer canvis per no mostrar dades dummy

        List<Activitat> top10Realitzades = controller.llistar10ActivitatsMesRealitzades();
        tableTop10Fetes.getItems().clear();

        for(Activitat activitat : top10Realitzades){
            tableTop10Fetes.getItems().add(new ActivitatTop(activitat.getIdExc(), activitat.getNom(), activitat.getCopsRealitzada()));
        }
    }

    private void popularTopActivitatsValorades() {
        //Aquí posem a quins atributs de la classe EspecieVista correspon cada columna de la taula:
        excursioValNumColumn.setCellValueFactory(new PropertyValueFactory<ActivitatTop, String>("nomExcursio"));
        activitatValNumColumn.setCellValueFactory(new PropertyValueFactory<ActivitatTop, String>("nomActivitat"));
        valoracioValNumColumn.setCellValueFactory(new PropertyValueFactory<ActivitatTop, String>("puntuacio"));
        // TODO: Fer canvis per no mostrar dades dummy

        Iterable<String> top10Valorades = controller.llistar10ActivitatsMillorValorades("ValoracioNumerica");
        tableTop10ValoradesNumericament.getItems().clear();

        for(String activitat : top10Valorades){
            tableTop10ValoradesNumericament.getItems().add(new ActivitatTop(controller.getNomExc(activitat), activitat, controller.calcValoracio(activitat,"ValoracioNumerica")));
        }
    }

    private void popularTopActivitatsLikes(){
        //Aquí posem a quins atributs de la classe EspecieVista correspon cada columna de la taula:
        excursioValLikesColumn.setCellValueFactory(new PropertyValueFactory<ActivitatTop, String>("nomExcursio"));
        activitatValLikesColumn.setCellValueFactory(new PropertyValueFactory<ActivitatTop, String>("nomActivitat"));
        nombreLikesColumn.setCellValueFactory(new PropertyValueFactory<ActivitatTop, String>("puntuacio"));
        // TODO: Fer canvis per no mostrar dades dummy

        Iterable<String> top10Likes = controller.llistar10ActivitatsMillorValorades("ValoracioLike");
        tableTop10Likes.getItems().clear();

        for(String activitat : top10Likes){
            tableTop10Likes.getItems().add(new ActivitatTop(controller.getNomExc(activitat), activitat, (int)controller.calcValoracio(activitat,"ValoracioLike")));
        }

    }

    private void popularTopActivitatsDislikes(){
        //Aquí posem a quins atributs de la classe EspecieVista correspon cada columna de la taula:
        excursioValDislikesColumn.setCellValueFactory(new PropertyValueFactory<ActivitatTop, String>("nomExcursio"));
        activitatValDislikesColumn.setCellValueFactory(new PropertyValueFactory<ActivitatTop, String>("nomActivitat"));
        nombreDislikesColumn.setCellValueFactory(new PropertyValueFactory<ActivitatTop, String>("puntuacio"));
        // TODO: Fer canvis per no mostrar dades dummy

        Iterable<String> top10Dislikes = controller.llistar10ActivitatsMillorValorades("ValoracioDislike");
        tableTop10Dislikes.getItems().clear();

        for(String activitat : top10Dislikes){
            tableTop10Dislikes.getItems().add(new ActivitatTop(controller.getNomExc(activitat), activitat, (int)controller.calcValoracio(activitat,"ValoracioDislike")));
        }

    }

    private void popularExcursionsPerNom(){
        // TODO: Aquest mètode únicament mostra la llista d'excursions sense ordenar.
        // Cal modificar el mètode llistarCatalegExcursions del controlador
        Iterable<String> excursions = controller.llistarCatalegExcursionsPerNom();
        popularExcursions(excursions);
    }

    private void popularExcursionsPerData(){
        // TODO: Aquest mètode únicament mostra la llista d'excursions sense ordenar.
        // Cal modificar el mètode llistarCatalegExcursionsPerData del controlador
        Iterable<String> excursions = controller.llistarCatalegExcursionsPerData();
        popularExcursions(excursions);
    }

    private void popularExcursions(Iterable<String> iterableExcursions){
        List<Node> excursionsPaneChildren = excursions_pane.getChildren();

        double width = excursio_btn.getWidth();
        double height = excursio_btn.getHeight();
        double layoutX = excursio_btn.getLayoutX();
        double layoutY = excursio_btn.getLayoutY();
        //Instanciem un botó per cada excursió
        for (String excursio : iterableExcursions){
            String data = controller.getDataExcursio(excursio).toString();
            Button new_btn = createExcursioButton(excursio, data + " | " + excursio, width, height, layoutX, layoutY);
            excursionsPaneChildren.add(new_btn);
            layoutY += ESPAI_ENTRE_BOTONS;
        }
        //Actualitzem la mida del pane que conté els botons perque es pugui fer scroll cap abaix si hi ha més botons dels que caben al pane
        excursions_pane.setPrefHeight(layoutY);
        //Esborrem excursio_btn, que l'utilitzavem únicament com a referència per la mida dels botons
        excursionsPaneChildren.remove(excursio_btn);
    }

    /*
    * Crea un botó de dimensions width x height, colocat a la posició (layoutX, layoutY)
    * */
    private Button createExcursioButton(String excursio, String text, double width, double height, double layoutX, double layoutY){
        Button new_btn = new Button();
        new_btn.setPrefWidth(width);
        new_btn.setPrefHeight(height);
        new_btn.setText(text);
        new_btn.setLayoutX(layoutX);
        new_btn.setLayoutY(layoutY);
        new_btn.setAlignment(Pos.BASELINE_LEFT);
        new_btn.setOnMouseClicked(event ->
        {
            if (event.getButton() == MouseButton.PRIMARY)
            {
                try {
                    mostrarFinestraExcursio(excursio);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else if (event.getButton() == MouseButton.SECONDARY)
            {
                try {
                    mostrarFinestraActivitatsExcursio(excursio);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        return new_btn;
    }

    private void mostrarFinestraExcursio(String excursio) throws IOException {
        //Nova finestra
        Escena escena = EscenaFactory.INSTANCE.creaEscena("excursio-view", excursio, this.stage);
        EscenaExcursio escenaExcursio = ((EscenaExcursio)escena);
        escenaExcursio.setController(controller);
        escenaExcursio.setExcursio(excursio);

        stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent windowEvent){
                try{
                    escenaExcursio.stage.close();
                    onCloseButton();
                } catch (IOException e){
                    e.printStackTrace();
                }
            }
        });
    }

    private void mostrarFinestraActivitatsExcursio(String excursio) throws IOException {
        //Nova finestra
        Escena escena = EscenaFactory.INSTANCE.creaEscena("activitatsexcursio-view", excursio, this.stage);
        EscenaActivitatsExcursio escenaActExcursio = ((EscenaActivitatsExcursio)escena);
        escenaActExcursio.setController(controller);
        escenaActExcursio.setExcursio(excursio);

        stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent windowEvent){
                try{
                    escenaActExcursio.stage.close();
                    onCloseButton();
                } catch (IOException e){
                    e.printStackTrace();
                }
            }
        });
    }

    public void onOrdenarPerNomButtonClick(ActionEvent actionEvent) {
        buidarExcursions();
        popularExcursionsPerNom();
    }

    public void onOrdenarPerDataButtonClick(ActionEvent actionEvent) {
        buidarExcursions();
        popularExcursionsPerData();
    }

    public void onCloseButton() throws IOException{
        Escena escena = EscenaFactory.INSTANCE.creaEscena("areyousure-view", "ARE YOU REALLY SURE?");
        EscenaAreYouSure escenaAreYouSure = ((EscenaAreYouSure)escena);
        escenaAreYouSure.setController(controller);
        escenaAreYouSure.start();
    }

    public void onCercarPerLocalitatButtonClick() throws IOException {
        Escena escena = EscenaFactory.INSTANCE.creaEscena("cercarperlocalitat-view", "CERCAR PER LOCALITAT", this.stage);
        EscenaCercarPerLocalitat escenaCercarPerLocalitat = ((EscenaCercarPerLocalitat)escena);
        escenaCercarPerLocalitat.setController(controller);
        escenaCercarPerLocalitat.start();

        stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent windowEvent){
                try{
                    escenaCercarPerLocalitat.stage.close();
                    onCloseButton();
                } catch (IOException e){
                    e.printStackTrace();
                }
            }
        });
    }
    
    public void onCercarPerEspeciesButtonClick() throws IOException {
        Escena escena = EscenaFactory.INSTANCE.creaEscena("cercarperespecie-view", "CERCAR PER ESPÈCIE", this.stage);
        EscenaCercarPerEspecie escenaCercarPerEspecie = ((EscenaCercarPerEspecie)escena);
        escenaCercarPerEspecie.setController(controller);
        escenaCercarPerEspecie.start();

        stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent windowEvent){
                try{
                    escenaCercarPerEspecie.stage.close();
                    onCloseButton();
                } catch (IOException e){
                    e.printStackTrace();
                }
            }
        });
    }

    private void buidarExcursions(){
        List<Node> excursionsPaneChildren = excursions_pane.getChildren();
        for (int i = 0; i < excursionsPaneChildren.size(); i++){
            excursionsPaneChildren.remove(excursionsPaneChildren.get(i));
        }
    }
}
