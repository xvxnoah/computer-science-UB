package ub.edu.model.especies;

import java.util.*;

public class CarteraEspecies {

    private List<Especie> llistaEspecies;

    public CarteraEspecies(){
        llistaEspecies = new ArrayList<>();
    }

    public CarteraEspecies(List<Especie> especies) {
        llistaEspecies = new ArrayList<>(especies);
    }

    public List<Especie> getLlistaEspecies() {
        return llistaEspecies;
    }

    public Especie find(String nomEspecie) {
        for (Especie e: llistaEspecies) {
            if (e.getNom().equals(nomEspecie)) return e;
        }
        return null;
    }

    public Especie find(String nomEspecie, String idLocalitzacio) {
        for (Especie e: llistaEspecies) {
            if (e.getNom().equals(nomEspecie) && e.getIdLocalitzacio().equals(idLocalitzacio)) return e;
        }
        return null;
    }

    public void add(Especie especie) {
        llistaEspecies.add(especie);
    }

    public boolean isEmpty(){
        return llistaEspecies.isEmpty();
    }

    public Iterable<String> llistarCatalegEspecies(){
        SortedSet<String> especiesDisponibles = new TreeSet<>();

        if(this.isEmpty()){
            especiesDisponibles.add("No hi ha espècies disponibles");
        } else{
            for(Especie especie : this.getLlistaEspecies()){
                especiesDisponibles.add(especie.getNom());
            }
        }

        return especiesDisponibles;
    }
}