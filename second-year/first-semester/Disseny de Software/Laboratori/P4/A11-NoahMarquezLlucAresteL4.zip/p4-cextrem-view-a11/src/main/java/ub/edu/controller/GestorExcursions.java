package ub.edu.controller;

import ub.edu.model.CeXtrem;
import ub.edu.model.activities.Activitat;
import ub.edu.model.excursions.CarteraExcursions;
import ub.edu.model.excursions.Excursio;
import ub.edu.resources.services.DataService;

import java.time.LocalDate;
import java.util.*;

public class GestorExcursions {
    private volatile static GestorExcursions uniqueInstance;
    private CeXtrem ceXtrem;

    private GestorExcursions(){
        ceXtrem = CeXtrem.getInstance();
    }

    public static GestorExcursions getInstance(){
        if(uniqueInstance == null){
            synchronized (GestorExcursions.class){
                if(uniqueInstance == null){
                    uniqueInstance = new GestorExcursions();
                }
            }
        }
        return uniqueInstance;
    }



    public boolean iniCarteraExcursions(DataService dataService) throws Exception {
        List<Excursio> l = dataService.getAllExcursions(); // Està a la RAM, i li demanem que agafi la base de dades
        if (l != null) {
            ceXtrem.setCarteraExcursions(new CarteraExcursions(l));
            return true;
        } else return false;
    }

    public Excursio find(String nomExcursio){
        return ceXtrem.getCarteraExcursions().find(nomExcursio);
    }

    public Iterable<String> llistarCatalegExcursions(){
        return ceXtrem.getCarteraExcursions().llistarCatalegExcursions(ceXtrem.getCarteraExcursions());
    }

    public Iterable<String> llistarCatalegExcursionsPerData(){
        return ceXtrem.getCarteraExcursions().llistarCatalegExcursionsPerData(ceXtrem.getCarteraExcursions());
    }

    public Iterable<String> llistarActivitatsByExcursio(String nomExcursio) {
        Excursio excursio = find(nomExcursio);
        GestorActivitats gestorActivitats=GestorActivitats.getInstance();
        return gestorActivitats.llistarCatalegActivitatsAlfabeticament(excursio.getActivitats());
    }

    public Iterable<String> llistarCatalegExcursionsLocalitat(String localitat) {
        return ceXtrem.getCarteraExcursions().llistarCatalegExcursionsLocalitat(ceXtrem.getCarteraExcursions(), localitat);
    }

    public LocalDate getDataExcursio(String nomExcursio){
        Excursio excursio = find(nomExcursio);
        return excursio.getData();
    }

    public String getOrigenExcursio(String nomExcursio){
        Excursio excursio = find(nomExcursio);
        return excursio.getOrigen();
    }

    public String getDestiExcursio(String nomExcursio){
        Excursio excursio = find(nomExcursio);
        return excursio.getDesti();
    }

    public Iterable<String> llistarCatalegExcursionsEspecie(String especie) {
        return ceXtrem.getCarteraExcursions().llistarCatalegExcursionsEspecies(especie);
    }
}