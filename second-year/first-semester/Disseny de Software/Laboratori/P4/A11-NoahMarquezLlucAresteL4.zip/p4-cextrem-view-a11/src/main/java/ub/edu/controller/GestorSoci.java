package ub.edu.controller;

import ub.edu.model.CeXtrem;
import ub.edu.model.soci.CarteraSocis;
import ub.edu.model.soci.Soci;
import ub.edu.resources.services.DataService;

import java.util.List;
import java.util.Observer;

public class GestorSoci {
    private volatile static GestorSoci uniqueInstance;
    private CeXtrem ceXtrem;
    private ValidarDadesSoci validate;

    private GestorSoci(){
        ceXtrem = CeXtrem.getInstance();
        validate = ValidarDadesSoci.getInstance();
    }
    public static GestorSoci getInstance(){
        if(uniqueInstance == null){
            synchronized (GestorSoci.class){
                if(uniqueInstance == null){
                    uniqueInstance = new GestorSoci();
                }
            }
        }
        return uniqueInstance;
    }


    public boolean iniCarteraSocis(DataService dataService) throws Exception {
        List<Soci> l = dataService.getAllSocis(); // Està a la RAM, i li demanem que agafi la base de dades
        if (l != null) {
            ceXtrem.setCarteraSocis(new CarteraSocis(l));
            return true;
        } else return false;
    }

    public Soci findSoci(String nomSoci){
        return ceXtrem.getCarteraSocis().find(nomSoci);
    }

    public String addActivitatPreferida(String nomSoci, String nomAct){
        Soci soci = findSoci(nomSoci);
        return soci.addActivitatPreferida(nomAct);
    }

    public String addActivitatRealitzada(String nomSoci, String nomAct){
        Soci soci = findSoci(nomSoci);
        return soci.addActivitatRealitzada(nomAct);
    }

    public String valoraActivitat(String nomSoci, String nomAct, String tipusVal, int valoracio){
        Soci soci = findSoci(nomSoci);
        return soci.addValoracio(nomAct,tipusVal,valoracio);
    }

    public String loguejarSoci(String username, String password, DataService dataService){
        try{
            return dataService.loguejarSoci(username, password);
        } catch(Exception e){
            return "";
        }
    }

    public String recuperarContrasenya(String username, DataService dataService){
        try{
            return dataService.recuperarContrassenya(username);
        } catch(Exception e){
            return "";
        }
    }

    public Iterable<String> llistarCatalegActivitatsPerPreferides(String nomSoci) {
        Soci soci = ceXtrem.getCarteraSocis().find(nomSoci);
        GestorActivitats gestorActivitats=GestorActivitats.getInstance();
        return gestorActivitats.llistarCatalegActivitatsAlfabeticament(soci.getActivitatsPreferides());
    }

    public Iterable<String> llistarActivitatsRealitzasdesBySoci(String username) {
        Soci soci = ceXtrem.getCarteraSocis().find(username);
        GestorActivitats gestorActivitats=GestorActivitats.getInstance();
        return gestorActivitats.llistarCatalegActivitatsAlfabeticament(soci.getActivitatsRealitzades());
    }

    public String validateRegisterSoci(String user, String pass, DataService dataService){
        String validateRegister = validate.validateRegisterSoci(user, pass);
        if(validateRegister.equals("Soci Validat")){
            Soci newSoci = new Soci(user, pass);
            newSoci.iniCarteres();
            ceXtrem.getCarteraSocis().addSoci(newSoci);

            dataService.registerSoci(user, pass);
            return validateRegister;
        }
        return validateRegister;
    }

    public void observersForSoci(Observer o, String username) {
        Soci soci = findSoci(username);
        soci.addObs(o);
    }
}