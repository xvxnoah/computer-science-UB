package ub.edu.model.localitzacions;

import ub.edu.model.especies.CarteraEspecies;

public class Localitzacio {
    private String nom;
    private String web;
    private CarteraEspecies especies;

    public Localitzacio(String nom){
        this.nom = nom;
    }

    public Localitzacio(String nom, String web){
        this.nom = nom;
        this.web = web;
    }

    public void iniCartera(){
        this.especies = new CarteraEspecies();
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getNom() {
        return nom;
    }

    public void setEspecies(CarteraEspecies especies) {
        this.especies = especies;
    }

    public CarteraEspecies getEspecies() {
        return especies;
    }

    public String getWeb() {
        return web;
    }
}
