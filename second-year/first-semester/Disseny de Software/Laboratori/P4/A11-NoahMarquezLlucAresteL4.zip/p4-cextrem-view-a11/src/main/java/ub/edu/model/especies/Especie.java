package ub.edu.model.especies;

public class Especie {
    private String nom;
    private String idLocalitzacio;

    public Especie(String nom){
        this.nom = nom;
        this.idLocalitzacio = null;
    }

    public Especie(String nom, String idLocalitzacio){
        this.nom = nom;
        this.idLocalitzacio = idLocalitzacio;
    }

    public String getNom(){
        return nom;
    }

    public void setNom(String title_cannot_be_null) {
        this.nom=title_cannot_be_null;
    }

    public String getIdLocalitzacio() {
        return idLocalitzacio;
    }
}