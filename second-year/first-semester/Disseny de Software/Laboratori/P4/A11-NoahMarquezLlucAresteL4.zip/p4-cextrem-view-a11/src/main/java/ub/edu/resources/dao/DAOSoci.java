package ub.edu.resources.dao;

import ub.edu.model.soci.Soci;

public interface DAOSoci extends DAO<Soci> {
}
