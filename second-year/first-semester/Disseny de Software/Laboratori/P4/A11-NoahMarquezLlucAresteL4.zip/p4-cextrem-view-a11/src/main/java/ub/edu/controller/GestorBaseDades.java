package ub.edu.controller;

import ub.edu.resources.services.AbstractFactoryData;
import ub.edu.resources.services.DataService;
import ub.edu.resources.services.FactoryMOCK;

public class GestorBaseDades {
    private volatile static GestorBaseDades uniqueInstance;
    private AbstractFactoryData factory;
    private DataService dataService;
    private GestorSoci gestorSoci;
    private GestorEspecies gestorEspecies;
    private GestorExcursions gestorExcursions;
    private GestorActivitats gestorActivitats;
    private GestorLocalitzacions gestorLocalitzacions;

    private GestorBaseDades(){
        factory = new FactoryMOCK();
        dataService = new DataService(factory); // Començar a crear la façana
        gestorSoci = GestorSoci.getInstance();
        gestorActivitats=GestorActivitats.getInstance();
        gestorEspecies= GestorEspecies.getInstance();
        gestorExcursions=GestorExcursions.getInstance();
        gestorLocalitzacions = GestorLocalitzacions.getInstance();
    }


    public static GestorBaseDades getInstance(){
        if(uniqueInstance == null){
            synchronized (GestorBaseDades.class){
                if(uniqueInstance == null){
                    uniqueInstance = new GestorBaseDades();
                }
            }
        }
        return uniqueInstance;
    }

    public void iniCarteres() throws Exception{
        gestorSoci.iniCarteraSocis(dataService);
        gestorActivitats.iniCarteraActivitats(dataService);
        gestorEspecies.iniCarteraEspecies(dataService);
        gestorExcursions.iniCarteraExcursions(dataService);
        gestorLocalitzacions.iniCarteraLocalitzacions(dataService);

        dataService.inicialitzaCarteres();
        dataService.relateEspeciesLocalitzacions();
        dataService.relateActivitatsExcursions();
        dataService.relateActivitatsValoracions();
        dataService.relateSocisActsRealitzades();
        dataService.relateExcursionsLocalitzacions();
    }

    public String loguejarSoci(String username, String password){
        return gestorSoci.loguejarSoci(username, password, dataService);
    }

    public String recuperarContrassenya(String username){
        return gestorSoci.recuperarContrasenya(username, dataService);
    }

    public String registerSoci(String username, String password){
        return gestorSoci.validateRegisterSoci(username, password, dataService);
    }
}