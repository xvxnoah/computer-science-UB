package ub.edu.controller;

import ub.edu.model.activities.Activitat;

import java.time.LocalDate;
import java.util.*;

public class Controller {
    private volatile static Controller uniqueInstance;
    private GestorSoci gestorSoci;
    private GestorActivitats gestorActivitats;
    private GestorEspecies gestorEspecies;
    private GestorExcursions gestorExcursions;
    private GestorBaseDades gestorBaseDades;
    private GestorLocalitzacions gestorLocalitzacions;
    private static String actualUser;

    private Controller() {
        try {
            gestorSoci=GestorSoci.getInstance();
            gestorActivitats=GestorActivitats.getInstance();
            gestorEspecies= GestorEspecies.getInstance();
            gestorExcursions=GestorExcursions.getInstance();
            gestorBaseDades = GestorBaseDades.getInstance();
            gestorLocalitzacions = GestorLocalitzacions.getInstance();
            gestorBaseDades.iniCarteres();

        } catch (Exception e) {
        }
    }

    public static Controller getInstance(){
        if(uniqueInstance == null){
            synchronized (Controller.class){
                if(uniqueInstance == null){
                    uniqueInstance = new Controller();
                }
            }
        }
        return uniqueInstance;
    }

    public String getActualUser(){
        return actualUser;
    }

    private void setActualUser(String user){
        actualUser = user;
    }


    // Validem el Soci a la capa de persistencia i no a memoria, per seguretat en les possibles sincronitzacions
    public String validateRegisterSoci(String username, String password) {
        return gestorBaseDades.registerSoci(username, password);
    }

    public String loguejarSoci(String username, String password){
        String resposta = gestorBaseDades.loguejarSoci(username, password);

        if (resposta.equals("Login correcte")){
            setActualUser(username);
            return resposta;
        }

        return resposta;
    }

    public String recuperarContrassenya(String username){
        return gestorBaseDades.recuperarContrassenya(username);
    }

    public String getDadesActivitat(String activitat){
        return gestorActivitats.getInfoActivitat(activitat);
    }

    public LocalDate getDataExcursio(String excursio) {
        return gestorExcursions.getDataExcursio(excursio);
    }
    public String getOrigenExcursio(String excursio) {
        return gestorExcursions.getOrigenExcursio(excursio);
    }
    public String getDestiExcursio(String excursio) {
        return gestorExcursions.getDestiExcursio(excursio);
    }

    public String getWebLocalitzacio(String localitzacio){return gestorLocalitzacions.getWebLocalitzacio(localitzacio);}

    public Iterable<String> getActivitatsExcursio(String excursio){
        return gestorExcursions.llistarActivitatsByExcursio(excursio);
    }

    public Iterable<String> getEspeciesLocalitzacio(String localitzacio){
        return gestorLocalitzacions.getEspeciesLocalitzacio(localitzacio);
    }

    public Iterable<String> llistarCatalegExcursionsPerNom() {
        return gestorExcursions.llistarCatalegExcursions();
    }

    public Iterable<String> llistarCatalegExcursionsPerData(){
        return gestorExcursions.llistarCatalegExcursionsPerData();
    }

    public Iterable<String> llistarCatalegLocalitats() {
        return gestorLocalitzacions.llistarCatalegLocalitats();
    }

    public Iterable<String> llistarCatalegEspecies(){return gestorEspecies.llistarCatalegEspecies();}

    public Iterable<String> llistarCatalegActivitatsPerPreferides(String nomSoci){
        return gestorSoci.llistarCatalegActivitatsPerPreferides(nomSoci);
    }

    public Iterable<String> llistarActivitatsRealitzadesBySoci(String username) {
        return gestorSoci.llistarActivitatsRealitzasdesBySoci(username);
    }

    public Iterable<String> llistarCatalegExcursionsLocalitat(String localitat) {
        return gestorExcursions.llistarCatalegExcursionsLocalitat(localitat);
    }

    public Iterable<String> llistar10ActivitatsMillorValorades(String tipusVal){
        return gestorActivitats.llistarTop10ActivitatsValorades(tipusVal);
    }

    public List<Activitat> llistar10ActivitatsMesRealitzades(){
        return gestorActivitats.llistarTop10ActivitatsRealitzades();
    }

    public String afegirActivitatRealitzada(String nomSoci, String nomActivitat){
        return gestorSoci.addActivitatRealitzada(nomSoci, nomActivitat);
    }

    public String afegirActivitatPreferida(String nomSoci, String nomActivitat){
        return gestorSoci.addActivitatPreferida(nomSoci, nomActivitat);
    }

    public String valoraActivitat(String nomSoci, String nomActivitat, String tipusVal, int valoracio){
        return gestorSoci.valoraActivitat(nomSoci, nomActivitat, tipusVal, valoracio);
    }

    public void observersToClasses(Observer o){
        gestorSoci.observersForSoci(o,getActualUser());
        gestorActivitats.observersForActivitat(o);
    }

    public Iterable<String> llistarCatalegExcursionsEspecie(String especie) {
        return gestorExcursions.llistarCatalegExcursionsEspecie(especie);
    }

    public String getNomExc(String activitat) {
        return gestorActivitats.getNomExc(activitat);
    }

    public float calcValoracio(String activitat, String tipusVal) {
        return gestorActivitats.calcValoracio(activitat,tipusVal);
    }
}
