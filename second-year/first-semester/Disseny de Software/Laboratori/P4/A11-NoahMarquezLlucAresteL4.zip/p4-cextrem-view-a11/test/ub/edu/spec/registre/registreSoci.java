package ub.edu.spec.registre;

import org.concordion.api.BeforeExample;
import org.concordion.integration.junit4.ConcordionRunner;
import org.junit.runner.RunWith;
import ub.edu.controller.Controller;
import ub.edu.controller.ValidarDadesSoci;

@RunWith(ConcordionRunner.class)
public class registreSoci {
    private Controller controlador;

    @BeforeExample
    private void init() {
        controlador = Controller.getInstance();
    }

    public String isValidRegistre(String sociName, String password) {
        return controlador.validateRegisterSoci(sociName, password);
    }
}
