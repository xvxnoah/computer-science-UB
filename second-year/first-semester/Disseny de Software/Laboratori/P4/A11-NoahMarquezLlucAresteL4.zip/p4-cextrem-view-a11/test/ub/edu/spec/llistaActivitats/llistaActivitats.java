package ub.edu.spec.llistaActivitats;

import org.concordion.api.BeforeExample;
import org.concordion.integration.junit4.ConcordionRunner;
import org.junit.runner.RunWith;
import ub.edu.controller.Controller;
import ub.edu.controller.GestorActivitats;
import ub.edu.controller.GestorExcursions;
import ub.edu.model.excursions.Excursio;

@RunWith(ConcordionRunner.class)
public class llistaActivitats {
    private Controller controlador;

    @BeforeExample
    private void init() {
        controlador = Controller.getInstance();
    }

    public Iterable<String> listCatalegActivitatsRealitzades(String nomSoci){
        return controlador.llistarActivitatsRealitzadesBySoci(nomSoci);
    }

    public Iterable<String> listCatalegActivitatsPerPreferides(String nomSoci){
        return controlador.llistarCatalegActivitatsPerPreferides(nomSoci);
    }

    public Iterable<String> listCatalegActPreferidesTest(String nomSoci, String activitat){
        controlador.afegirActivitatPreferida(nomSoci, activitat);
        return controlador.llistarCatalegActivitatsPerPreferides(nomSoci);
    }

    public Iterable<String> listCatalegActivitatsPerValoracio(String tipusValoracio){
        return controlador.llistar10ActivitatsMillorValorades(tipusValoracio);
    }

    public Iterable<String> listActivitatsExcursio(String nomExc){
        return controlador.getActivitatsExcursio(nomExc);
    }

}