package ub.edu.spec.marcarRealitzada;

import org.concordion.api.BeforeExample;
import org.concordion.integration.junit4.ConcordionRunner;
import org.junit.runner.RunWith;
import ub.edu.controller.Controller;

@RunWith(ConcordionRunner.class)
public class marcarRealitzada {
    private Controller controlador;

    @BeforeExample
    private void init() {
        controlador = Controller.getInstance();
    }

    public String marcarActivitatRealitzada(String nomSoci, String nomAct){
        return controlador.afegirActivitatRealitzada(nomSoci, nomAct);
    }

    public String marcarActivitatJaRealitzada(String nomSoci, String nomAct){
        controlador.afegirActivitatRealitzada(nomSoci, nomAct);
        return controlador.afegirActivitatRealitzada(nomSoci, nomAct);
    }
}
