package ub.edu.spec.visualitzarActivitat;

import org.concordion.api.BeforeExample;
import org.concordion.integration.junit4.ConcordionRunner;
import org.junit.runner.RunWith;
import ub.edu.controller.Controller;

@RunWith(ConcordionRunner.class)
public class visualitzarActivitat {
    private Controller controlador;

    @BeforeExample
    private void init() {
        controlador = Controller.getInstance();
    }


    public String visualitzarActivitat(String nomActivitat){
        return controlador.getDadesActivitat(nomActivitat);
    }

}
