package ub.edu.spec.marcarPreferida;

import org.concordion.api.BeforeExample;
import org.concordion.integration.junit4.ConcordionRunner;
import org.junit.runner.RunWith;
import ub.edu.controller.Controller;

@RunWith(ConcordionRunner.class)
public class marcarPreferida {
    private Controller controlador;

    @BeforeExample
    private void init() {
        controlador = Controller.getInstance();
    }

    public String marcarActivitatPreferida(String nomSoci, String nomAct){
        return controlador.afegirActivitatPreferida(nomSoci, nomAct);
    }

    public String marcarActivitatJaPreferida(String nomSoci, String nomAct){
        controlador.afegirActivitatPreferida(nomSoci, nomAct);
        return controlador.afegirActivitatPreferida(nomSoci, nomAct);
    }
}
