package ub.edu.spec.valorarActivitat;

import org.concordion.api.BeforeExample;
import org.concordion.integration.junit4.ConcordionRunner;
import org.junit.runner.RunWith;
import ub.edu.controller.Controller;

@RunWith(ConcordionRunner.class)
public class valorarActivitat {
    private Controller controlador;

    @BeforeExample
    private void init() {
        controlador = Controller.getInstance();
    }

    public String afegirValoracio(String nomSoci, String nomAct, String tipusVal, int valoracio){
        return controlador.valoraActivitat(nomSoci, nomAct, tipusVal, valoracio);
    }
    public String afegirValoracio(String nomSoci, String nomAct, String tipusVal){
        return controlador.valoraActivitat(nomSoci, nomAct, tipusVal, 1);
    }
}