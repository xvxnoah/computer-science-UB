package ub.edu.model;


import java.util.ArrayList;
import java.util.List;

public class Soci {
    private String pwd;
    private String nom;
    private List<Activitat> llistaAct;
    private List<Activitat> llistaActPreferides;


    public Soci(String nom, String pwd) {
        this.pwd = pwd;
        this.nom = nom;
        this.llistaAct=new ArrayList<>();
        this.llistaActPreferides=new ArrayList<>();
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getName() {
        return nom;
    }

    public void setName(String nom) {
        this.nom = nom;
    }

    public List<Activitat> getLlistaAct(){
        return this.llistaAct;
    }
    public List<Activitat> getLlistaActPreferides(){
        return this.llistaActPreferides;
    }

    public void addActivitat(Activitat activitat){
        llistaAct.add(activitat);
    }

    public void addActivitatPreferida(Activitat activitat){
        String nomAct = activitat.getNom();
        if (findPreferida(nomAct)==null){
            llistaActPreferides.add(activitat);
        }
    }

    private Activitat findPreferida(String nom){
        for (Activitat c: llistaActPreferides) {
            if (c.getNom().equals(nom)) return c;
        }
        return null;
    }

    public Activitat find(String nom) {
        for (Activitat c: llistaAct) {
            if (c.getNom().equals(nom)) return c;
        }
        return null;
    }

}