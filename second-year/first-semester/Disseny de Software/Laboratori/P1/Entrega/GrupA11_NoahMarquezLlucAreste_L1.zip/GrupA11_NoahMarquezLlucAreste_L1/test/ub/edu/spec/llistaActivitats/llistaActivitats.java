package ub.edu.spec.llistaActivitats;

import org.concordion.api.BeforeExample;
import org.concordion.integration.junit4.ConcordionRunner;
import org.junit.runner.RunWith;
import ub.edu.controller.Controller;
import ub.edu.model.Soci;

@RunWith(ConcordionRunner.class)
public class llistaActivitats {
    private Controller controlador;

    @BeforeExample
    private void init() {
        controlador = new Controller();
    }

    public void afegirActivitats() {
        controlador.afegirActivitat("ajaleo@gmail.com", "TORRENTISMO");
        controlador.afegirActivitat("ajaleo@gmail.com", "BUNGEE JUMPING");
        controlador.afegirActivitat("ajaleo@gmail.com", "KAYAK");
        controlador.afegirActivitat("dtomacal@yahoo.cat", "KAYAK");
        controlador.afegirActivitat("dtomacal@yahoo.cat", "PAINT BALL");
        controlador.afegirActivitat("dtomacal@yahoo.cat", "PARAPENTE");
        controlador.afegirActivitat("heisenberg@gmail.com", "CANYONING");
        controlador.afegirActivitat("rick@gmail.com", "RAPPEL");
        controlador.afegirActivitat("juancarlos999@gmail.com", "ESCALADA");
        controlador.afegirActivitat("juancarlos999@gmail.com", "TORRENTISMO");
        controlador.afegirActivitat("dtomacal@yahoo.cat", "BUNGEE JUMPING");

    }
    public void afegirActivitatsPreferides() {
        controlador.afegirActivitatPreferida("ajaleo@gmail.com", "TORRENTISMO");
        controlador.afegirActivitatPreferida("ajaleo@gmail.com", "BUNGEE JUMPING");
        controlador.afegirActivitatPreferida("rick@gmail.com", "RAPPEL");


    }

    public void afegirValoracions() {
        controlador.valoraActivitat("ajaleo@gmail.com", "TORRENTISMO", 4);
        controlador.valoraActivitat("ajaleo@gmail.com", "BUNGEE JUMPING", 3);
        controlador.valoraActivitat("ajaleo@gmail.com", "KAYAK", 2);
        controlador.valoraActivitat("dtomacal@yahoo.cat", "KAYAK", 5);
        controlador.valoraActivitat("dtomacal@yahoo.cat", "PAINT BALL", 1);
        controlador.valoraActivitat("dtomacal@yahoo.cat", "PARAPENTE", 5);
        controlador.valoraActivitat("heisenberg@gmail.com", "CANYONING", 1);
        controlador.valoraActivitat("rick@gmail.com", "RAPPEL", 2);
        controlador.valoraActivitat("juancarlos999@gmail.com", "ESCALADA", 4);
        controlador.valoraActivitat("juancarlos999@gmail.com", "TORRENTISMO", 1);
        controlador.valoraActivitat("dtomacal@yahoo.cat", "BUNGEE JUMPING", 3);
    }


    public Iterable<String> listCatalegActivitatsPerValoracio1() {
        return controlador.llistarCatalegActivitatsPerValoracio();
    }

    public Iterable<String> listCatalegActivitatsPerValoracio2() {
        afegirActivitats();
        afegirValoracions();
        return controlador.llistarCatalegActivitatsPerValoracio();
    }

    public Iterable<String> listCatalegActivitatsPerPreferides(String nomSoci) {
        afegirActivitats();
        afegirActivitatsPreferides();
        return controlador.llistarCatalegActivitatsPerPreferides(nomSoci);
    }
}