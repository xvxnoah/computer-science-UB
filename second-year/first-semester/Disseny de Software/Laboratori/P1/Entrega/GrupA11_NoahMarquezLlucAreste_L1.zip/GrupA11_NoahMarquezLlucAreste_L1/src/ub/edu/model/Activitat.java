package ub.edu.model;

public class Activitat {
    private String nom;
    private int sumaValoracions = 0;
    private int numValoracions = 0;

    public Activitat(String titol) {
        this.nom = titol;
    }

    public Activitat(String titol, int valoracio) {
        this.nom = titol;
        this.sumaValoracions += valoracio;
        this.numValoracions += 1;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void addValoracio(int valoracio){
        sumaValoracions += valoracio;
        numValoracions += 1;
    }

    public float calculaValoracio(){
        if (numValoracions==0){
            return -1;
        }
        return (float)sumaValoracions / (float)numValoracions;
    }

}
