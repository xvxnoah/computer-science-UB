package ub.edu.spec.valorarActivitat;

import org.concordion.api.BeforeExample;
import org.concordion.integration.junit4.ConcordionRunner;
import org.junit.runner.RunWith;
import ub.edu.controller.Controller;

@RunWith(ConcordionRunner.class)
public class valorarActivitat {
    private Controller controlador;

    @BeforeExample
    private void init() {
        controlador = new Controller();
    }

    public void afegirActivitat(){
        controlador.afegirActivitat("ajaleo@gmail.com","TORRENTISMO");
        controlador.afegirActivitat("ajaleo@gmail.com","KAYAK");
        controlador.afegirActivitat("dtomacal@yahoo.cat","PAINT BALL");
        controlador.afegirActivitat("dtomacal@yahoo.cat","PARAPENTE");
        controlador.afegirActivitat("heisenberg@gmail.com","CANYONING");
        controlador.afegirActivitat("rick@gmail.com","RAPPEL");
        controlador.afegirActivitat("juancarlos999@gmail.com","ESCALADA");
        controlador.afegirActivitat("juancarlos999@gmail.com","TORRENTISMO");
        controlador.afegirActivitat("dtomacal@yahoo.cat","BUNGEE JUMPING");
    }

    public String afegirValoracion(String nomSoci, String nomAct, int valoracio){
        return controlador.valoraActivitat(nomSoci, nomAct, valoracio);
    }

    public String valorar(String nomSoci, String nomAct, int valoracio){
        afegirActivitat();
        return afegirValoracion(nomSoci, nomAct, valoracio);
    }
}