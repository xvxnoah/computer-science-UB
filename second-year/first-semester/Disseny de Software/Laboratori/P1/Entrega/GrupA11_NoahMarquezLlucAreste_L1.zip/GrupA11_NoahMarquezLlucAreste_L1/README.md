# CeXtrem

Codi base de la pràctica 1: DS 2021-22

Trobareu dins de la carpeta doc, el diagrama de casos d'ús i un fitxer amb les històries d'usuari associades a les primeres funcionalitats.

El codi està organitzat a la carpeta src i a la carpeta test
