#include "msp432p401r.h"
#include <stdio.h>
#include <stdint.h>
#include "lib_PAE2.h"

/* LLibreries ajuda */
#include <helper.h>
#include <interrupt.h>
#include <uart.h>
#include <control_robot.h>

/* Aquest define s'haur� de descomentar en cas de voler fer servir el simulador*/
//#define SIMULACIO "simulacio"

/* Inici timers */
void init_timers(void){
    // De moment deshabilitem el timer de 1 ms, ya que nomes s'activara al utilizar la funcio delay_t
    // Timer a 1ms
    TA0CTL |= TASSEL_1 + TACLR;                 // Usem ACLK (2^15 Hz), reiniciem el comptador
    TA0CCTL0 &= ~(CAP+CCIFG);                   // Deshabilitem el mode "capture" (treballem en mode "compare") y quitem el flag d'interrupcio
    TA0CCTL0 |= CCIE;                           // Habilitem les interrupcions (Per CCR0)
    TA0CCR0 = 33;                               // 32768hz / 32 = 1024hz ~= 1ms

    // Timer a 1ms (Para el timeout)
    TA1CTL |= TASSEL_1 + MC_1 + TACLR;          // Usem ACLK (2^15 Hz), reiniciem el comptador
    TA1CCTL0 &= ~(CAP+CCIFG);                   // Deshabilitem el mode "capture" (treballem en mode "compare") y quitem el flag d'interrupcio
    TA1CCTL0 |= CCIE;                           // Habilitem les interrupcions (Per CCR0)
    TA1CCR0 = 33;                               // 32768hz / 32768 ~= 1hz ~= 1000ms ~= 1sec

}

void main(void)
{
    WDTCTL = WDTPW + WDTHOLD;       // stop watchdog timer

    // Cridem a les funcions d'inicialitzacio
    init_ucs_24MHz();
    init_timers();

    // Segons en quin mode de la UART haguem seleccionat, es crida a una funcio de configuracio de la UART o a una altra
    #ifdef SIMULACIO
        init_UART_SIMULACIO();
    #else
        init_UART();
    #endif

    // Cridem a la funcio d'inicialitzacio de les interrupcions
    init_interrupciones();

    // En aquest punt del programa ja esta la UART del mode seleccionat degudament configurada, i les interrupcions i timers tambe
    // aixi que podem cridar a diverses funcions de la llibreria d'usuari per tal de realitzar moviments especifics amb el robot

    // Com a primera comprovacio cridem a la seguent funcio que estableix un moviment continu de les rodes del robot
    wheelMode();

    // Una possible funcio de moviment de rodes a cridar es moure cap a la dreta
    turnRight(400);

    /* Altres crides possibles de la nostra llibreria */
    //forward(1000);
    //turnOnItselfLeft(400);
    //turnLeft(400);

    // Bucle infinit, per evitar que finalitzi l'execucio del programa
    while(true){
        ;
    }
}

// Interrupcions per al TIMER DE 1 MS
void TA0_0_IRQHandler(void) {

    TA0CCTL0 &= ~CCIE;      // Deshabilitem interrupcions mentres tractem aquesta

    timer_ms_count++;       // Augmentem el temps actual

    TA0CCTL0 &= ~CCIFG;     // Quitem el flag d'interrupcio
    TA0CCTL0 |= CCIE;       // Habilitem les interrupcions
}

