#include <msp432p401r.h>
#include <stdio.h>
#include <stdint.h>
#include <helper.h>
#include <uart.h>
#include <lib_PAE.h>

// Funcio per a que les rodes girin de forma continua
void wheelMode(void){

    byte bID = BROADCASTING; // No obtenim resposta en aquest mode
    byte bInstruction = WRITE_DATA;
    byte bParameterLength = 5;
    byte bParameters[16];

    // Comencem per la direccio 0x06 (6)
    bParameters[0] = CW_ANGLE_LIMIT_L;

    // Dades a escriure
    bParameters[1] = 0;  // CW_ANGLE_LIMIT_L = 0
    bParameters[2] = 0;  // CW_ANGLE_LIMIT_H = 0
    bParameters[3] = 0;  // CCW_ANGLE_LIMIT_L = 0
    bParameters[4] = 0;  // CCW_ANGLE_LIMIT_H = 0

    // Enviem les dades
    TxPacket(bID, bParameterLength, bInstruction, bParameters);
}

// Funcio per moure una roda amb o sense rotacio i una certa velocitat
void moveWheel(byte ID, bool rotation, unsigned int speed)
{
    // Variable de tipus struct RxReturn que guarda el paquet que retorna els moduls
    struct RxReturn returnPacket;
    // Variables que indiquen la velocitat
    byte speed_H,speed_L;
    speed_L = speed;

    if(speed<1024){ // Velocitat max. 1023

        if(rotation){ // Rotation == 1
            speed_H = (speed >> 8)+4;   // Moure a la dreta (CW)
        }else{
            speed_H = speed >> 8;       // Moure a la esquerra (CCW)
        }

        byte bInstruction = WRITE_DATA;
        byte bParameterLength = 3;
        byte bParameters[16];

        // Comencem per la direccio 0x20 (32)
        bParameters[0] = MOV_SPEED_L;

        // Escribim la velocitat y la direccio
        bParameters[1] = speed_L;
        bParameters[2] = speed_H;

        // Cridem a la funcio TxPacket per tal d'enviar el paquet d'instruccions
        TxPacket(ID, bParameterLength, bInstruction, bParameters);
        // Assignem a la variable creada anteriorment returnPacket el paquet de dades retornat
        returnPacket = RxPacket();

    }
}

// Funcio per aturar les dues rodes
void stop(void)
{
    //Cridem a la funcio moveWheel per possar la rotacio i la velocitat a 0 d'ambdues rodes
    moveWheel(RIGHT_WHEEL, 0, 0);
    moveWheel(LEFT_WHEEL, 0, 0);
}

// Funcio per moure nomes la roda dreta i aixi girar a l'esquerra
void turnLeft(unsigned int speed){
    if(speed < 1024){
        moveWheel(RIGHT_WHEEL, RIGHT, speed);
        moveWheel(LEFT_WHEEL, RIGHT, 0);
    }
}

// Funcio per moure nomes la roda dreta i aixi girar a l'esquerra (amb un cert angle)
void turnLeftD(unsigned int degree){
    moveWheel(RIGHT_WHEEL, RIGHT, 300);
    moveWheel(LEFT_WHEEL, RIGHT, 0);
    delay_t(degree*28.5);
    stop();
}

// Funcio per girar les dues rodes a la dreta a la vegada i aixi que el robot doni una volta a si mateix per l'esquerra
void turnOnItselfLeft(unsigned int speed)
{
    if(speed < 1024){
        moveWheel(RIGHT_WHEEL, RIGHT, speed);
        moveWheel(LEFT_WHEEL, RIGHT, speed);
    }
}

// Funcio per moure nomes la roda esquerra i aixi girar a la dreta
void turnRight(unsigned int speed)
{
    if(speed < 1024){
        moveWheel(RIGHT_WHEEL, LEFT, 0);
        moveWheel(LEFT_WHEEL, LEFT, speed);
    }
}

// Funcio per moure nomes la roda esquerra i aixi girar a la dreta (amb un cert angle)
void turnRightD(unsigned int degree)
{
    moveWheel(RIGHT_WHEEL, LEFT, 0);
    moveWheel(LEFT_WHEEL, LEFT, 300);
    delay_t(degree*28.5);
    stop();
}

// Funcio per girar les dues rodes a l'esquerra a la vegada i aix� que el robot doni una volta a si mateix per la dreta
void turnOnItselfRight(unsigned int speed)
{
    if(speed < 1024){
        moveWheel(RIGHT_WHEEL, LEFT, speed);
        moveWheel(LEFT_WHEEL, LEFT, speed);
    }
}

// Funcio que mou el robot cap a endavant
void forward(unsigned int speed)
{
    if(speed < 1024){
        moveWheel(RIGHT_WHEEL, RIGHT, speed);
        moveWheel(LEFT_WHEEL, LEFT, speed);
    }
}

// Funcio que mou el robot cap a endarrere
void backward(unsigned int speed)
{
    if(speed < 1024){
        moveWheel(RIGHT_WHEEL, LEFT, speed);
        moveWheel(LEFT_WHEEL, RIGHT, speed);
    }
}

// Funcio que encen el led del motor
void motorLed(byte ID, bool status)
{
    // Variable de tipus struct RxReturn que guarda el paquet que retorna els moduls
    struct RxReturn returnPacket;
    byte bInstruction = WRITE_DATA;
    byte bParameterLength = 2;
    byte bParameters[16];
    bParameters[0] = M_LED;
    bParameters[1] = status;

    // Cridem a la funcio TxPacket per tal d'enviar el paquet d'instruccions
    TxPacket(ID, bParameterLength, bInstruction, bParameters);
    // Assignem a la variable creada anteriorment returnPacket el paquet de dades retornat
    returnPacket = RxPacket();
}

// Funcio que llegeix informacio del sensor el ID del qual s'ha passat per parametre
int readSensor(byte ID, byte sensor)
{
    // Variable de tipus struct RxReturn que guarda el paquet que retorna els moduls
    struct RxReturn returnPacket;

    byte bInstruction = READ_DATA;
    byte bParameterLength = 2;
    byte bParameters[16];
    bParameters[0] = sensor;
    bParameters[1] = 1;

    // Cridem a la funcio TxPacket per tal d'enviar el paquet d'instruccions
    TxPacket(ID, bParameterLength, bInstruction, bParameters);
    // Assignem a la variable creada anteriorment returnPacket el paquet de dades retornat
    returnPacket = RxPacket();

    return returnPacket.StatusPacket[5];
}
