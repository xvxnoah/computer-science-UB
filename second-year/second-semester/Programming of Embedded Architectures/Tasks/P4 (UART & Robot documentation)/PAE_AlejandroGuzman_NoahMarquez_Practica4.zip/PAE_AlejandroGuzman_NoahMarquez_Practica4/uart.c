#include <msp432p401r.h>
#include <stdint.h>
#include <stdio.h>
#include <helper.h>

uint32_t current_time = 0; // Variable que se usa en el Timer0
byte received_data;
byte read_data_UART;
/* Per tal de fer servir el codi en l'emulador cal descomentar el define */
//#define SIMULACIO "simulating"

// Funcio time_out es True si el temps del comptador (current_time) supera el temps que hem passat com a parametre (time)
bool time_out(int time){
    return (current_time>=time);
}


// Sentit: Rebre dades
void sentit_dades_Rx(void)
{ //Configuracio del Half Duplex dels motors: Recepcio
    P3OUT &= ~BIT0; //El pin P3.0 (DIRECTION_PORT) el posem a 0 (Rx)
}

// Sentit: Enviar les dades
void sentit_dades_Tx(void)
{ //Configuracio del Half Duplex dels motors: Transmissio
    P3OUT |= BIT0; //El pin P3.0 (DIRECTION_PORT) el posem a 1 (Tx)
}

// Configuracio de la UART en mode simulacio (aplicacio programada amb Phyton)
// La UART funciona en mode simulacio configurant la UCA0 situada en el port 1 (pin 1.0 de direction port, 1.2 UCA0RXD, 1.3 UCA2TXD).
void init_UART_SIMULACIO(void){
    // A continuacio configurem tres registres importants de la UCA0 amb les caracteristiques que volem que
    // tingui la UART configurada
    UCA0CTLW0 |= UCSWRST;        // Fem un reset de la USCI i es desactiva
    UCA0CTLW0 |= UCSSEL__SMCLK;  // UCSYNC=0 mode asíncron
                                // UCMODEx=0 seleccionem mode UART
                                // UCSPB=0 nomes 1 stop bit
                                // UC7BIT=0 8 bits de dades
                                // UCMSB=0 bit de menys pes primer
                                // UCPAR=x no es fa servir bit de paritat
                                // UCPEN=0 sense bit de paritat

    UCA0MCTLW = UCOS16;  // Triem SMCLK (24MHz) com a font del clock BRCLK
    UCA0BRW = 3;         // Prescaler de BRCLK fixat a 13 (UCA0BR0 = (24MHz / 115200 kb/s) / 16. Com SMCLK va a 24MHz
                         // volem un baud rate de 115,200kb/s i fem sobre-mostreig
                         // de 16

                        // Necessitem sobre-mostreig -> bit 0 = UCOS16 = 1



    // Configurem els pins de la UART
    // Bacnkchannel UART -> UCA0 (versio emulada)
    // P1.2 = RX, P1.3 = TX

    P1SEL0 |= BIT2 | BIT3;      // I/O function: P1.2 UART0RX, P1.3 UART0TX
    P1SEL1 &= ~(BIT2 | BIT3);

    P3SEL0 &= ~BIT0;            // Port 3.0 com I/O digital
    P3SEL1 &= ~BIT0;
    P3DIR |= BIT0;              // Port 3.0 com a sortida (Data Direction: selector Tx/Rx)
    P3OUT &= ~BIT0;             // Inicialitzem el port P3.0 a 0 (Rx)
    UCA0CTLW0 &= ~UCSWRST;      // Reactivem la linia de comunicacions serie
    UCA0IE |= UCRXIE;
}

// Configuracio de la UART en mode real, utilitzant els moduls Dynamixel i el sensor del robot de laboratori
// La UART funciona en mode real configurant la UCA2 situada en el port 3 (pin 3.0 de direction port, 3.2 UCA0RXD, 3.3 UCA2TXD).
void init_UART(void)
{
    // A continuacio configurem tres registres importants de la UCA2 amb les caracteristiques que volem que
   // tingui la UART configurada
    UCA2CTLW0 |= UCSWRST;           //Fem un reset de la USCI, desactiva la USCI
    UCA2CTLW0 |= UCSSEL__SMCLK;     //UCSYNC=0 mode asincron
                                    //UCMODEx=0 seleccionem mode UART
                                    //UCSPB=0 nomes 1 stop bit
                                    //UC7BIT=0 8 bits de dades
                                    //UCMSB=0 bit de menys pes primer
                                    //UCPAR=x ja que no es fa servir bit de paritat
                                    //UCPEN=0 sense bit de paritat
                                    //Triem SMCLK (16MHz) com a font del clock BRCLK

    UCA2MCTLW = UCOS16;             // Necessitem sobre-mostreig => bit 0 = UCOS16 = 1
    UCA2BRW = 3;                    //Prescaler de BRCLK fixat a 3. Com SMCLK va a24MHz,
                                    //volem un baud rate de 500kb/s i fem sobre-mostreig de 16
                                    //el rellotge de la UART ha de ser de 8MHz (24MHz/3).

    //Configurem els pins de la UART
    // P3.2 = RX, P3.3 = TX, P3.0 = Direction port
    P3SEL0 |= BIT2 | BIT3; //I/O funcio: P3.3 = UART2TX, P3.2 = UART2RX
    P3SEL1 &= ~ (BIT2 | BIT3);

    //Configurem pin de seleccio del sentit de les dades Transmissio/Recepecio
    P3SEL0 &= ~BIT0; //Port P3.0 com GPIO
    P3SEL1 &= ~BIT0;
    P3DIR |= BIT0; //Port P3.0 com sortida (Data Direction selector Tx/Rx)
    P3OUT &= ~BIT0; //Inicialitzem Sentit Dades a 0 (Rx)
    UCA2CTLW0 &= ~UCSWRST; //Reactivem la linia de comunicacions serie
    UCA2IE |= UCRXIE; //Aixo nomes s'ha d'activar quan tinguem la rutina de recepcio
}

// Enviar un byte per la UART en mode simulacio
void TxUAC0(byte bTxdData)
{
    while(!TXD0_READY); // Espera a que estigui preparat el buffer de transmissio
    UCA0TXBUF = bTxdData;
}

// Enviar un byte por la UART en mode real
void TxUAC2(byte bTxdData)
{
    while(!TXD2_READY); // Espera a que estigui preparat el buffer de transmissio
    UCA2TXBUF = bTxdData;
}

//TxPacket() 3 parametres: ID del Dynamixel, Mida dels parametres, Instruction byte. torna la mida del "Return packet"
byte TxPacket(byte bID, byte bParameterLength, byte bInstruction, byte bParameters[16])
{
    byte bCount,bCheckSum,bPacketLength;
    byte TxBuffer[32];

    if(bParameters[0] <= 5){ // Comprovacio per seguretat
        return 0;
    }

    sentit_dades_Tx();  //El pin P3.0 (DIRECTION_PORT) el posem a 1 (Transmetre)

    TxBuffer[0] = 0xff; //Primers 2 bytes que indiquen inici de trama FF, FF.
    TxBuffer[1] = 0xff;

    TxBuffer[2] = bID; //ID del modul al que volem enviar el missatge
    TxBuffer[3] = bParameterLength+2; //Length(Parameter,Instruction,Checksum)
    TxBuffer[4] = bInstruction; //Instruccio que enviem al Modul

    for(bCount = 0; bCount < bParameterLength; bCount++) //Comencem a generar la trama que hem d'enviar
    {
        TxBuffer[bCount+5] = bParameters[bCount];
    }

    // Inicialitzem a 0 la variable del checksum que utilizarem per comprovar si s'ha enviat correctament les dades
    bCheckSum = 0;
    // Inicialitzem i assignem la longitud del paquet d'enviament com la longitud de parametres + 4 + 2
    bPacketLength = bParameterLength+4+2;

    for(bCount = 2; bCount < bPacketLength-1; bCount++) //Calcul del checksum
    {
        bCheckSum += TxBuffer[bCount];
    }

    TxBuffer[bCount] = ~bCheckSum; //Escrivim el Checksum (complement a 1)

    for(bCount = 0; bCount < bPacketLength; bCount++) //Aquest bucle es el que envia la trama al Modul Robot
    {
        // Segons si hem seleccionat un mode o un altre, enviem el packet emprant una UAC o una altra
        #ifdef SIMULACIO
            TxUAC2(TxBuffer[bCount]);
        #else
            TxUAC0(TxBuffer[bCount]);
        #endif
    }

    /* Segons estiguem en el mode simulador o no */
    #ifdef SIMULACIO
        while((UCA0STATW & UCBUSY));
    #else
        while( (UCA2STATW&UCBUSY)); //Espera fins que s'ha transmes l'ultim byte
    #endif

    sentit_dades_Rx(); //Possem la linia de dades en Rx perque el modul Dynamixel envii una resposta

    return bPacketLength;
}


// Configuracio del paquet que el modul Dynamixel enviara al microcontrolador com a resposta de la transmissio de
// dades realitzada
struct RxReturn RxPacket(void)
{
    // Inicialitzem una variable de tipus struct RxReturn definida com una estructura de dades
    struct RxReturn respuesta;
    // Inicialitzem
    byte bCount, bLenght, bCheckSum = 0;
    bool Rx_time_out = false;

    sentit_dades_Rx(); // Possem la linia de dades en Rx perque el modul Dynamixel envii una resposta

    //Activa_Interrupcion_TimerA1();

    // Llegim els quatre primers parametres
    for(bCount = 0; bCount < 4; bCount++)
    {
        // Inicialitzem una variable que guardi el temps actual, aixo servira per gestionar els errors de tipus time_out
        current_time=0;

        // Inicialitzem una variable que indiqui si s'ha rebut la dada o no
        received_data=0; // No

        while (!received_data) // No s'ha rebut la dada?
        {
            Rx_time_out = time_out(20);  // Temps d'espera en milisegons
            if (Rx_time_out)break;      // Si s'ha esgotat el temps d'espera per a rebre una dada sortim del bucle
        }

        if (Rx_time_out)break; // Sortim del bucle si s'ha produit un time_out

        // Si tot ha anat correctament, llegim una dada del paquet rebut
        respuesta.StatusPacket[bCount] = read_data_UART;

    }


    if (!Rx_time_out){  // Si no n'hi ha time_out

        // Inicialitzem una variable que guarda la longitud del total que anem a llegir
        bLenght = respuesta.StatusPacket[3]+4;

        // Llegim la resta de dades
        for(bCount = 4; bCount < bLenght; bCount++)
        {
            // Inicialitzem una variable que guardi el temps actual, aixo servira per gestionar els errors de tipus time_out
            current_time=0;

            // Inicialitzem una variable que indiqui si s'ha rebut la dada o no
            received_data=0; // No

            while (!received_data) // No s'ha rebut la dada?
            {
                Rx_time_out = time_out(20);  // Temps d'espera en milisegons
                if (Rx_time_out)break;      // Si s'ha esgotat el temps d'espera per a rebre una dada sortim del bucle
            }

            if (Rx_time_out)break; // Sortim del bucle si n'hi ha hagut un time_out

            // Si tot ha anat correctament, llegim una dada del paquet rebut
            respuesta.StatusPacket[bCount] = read_data_UART;
        }
    }

    if(!Rx_time_out){   // Si no n'hi ha time_out

        for(bCount = 2; bCount < bLenght-1; bCount++) // Realitzem el calcul del check sum
        {
            bCheckSum += respuesta.StatusPacket[bCount];
        }

        bCheckSum = ~bCheckSum; // Checksum a complement a 1
        // Comparem el checksum rebut amb el calculat, si dona diferent, n'hi ha un error
        if(respuesta.StatusPacket[bLenght-1] != bCheckSum){
            // Utilitzem una variable inicialitzada dintre de la struct RxReturn per saber si s'ha produit un error
            respuesta.error = true;
        }
    }

    return respuesta;
}

// Interrupcio al rebre una dada
void EUSCIA0_IRQHandler(void)
{
    // Interrupcio de recepcio en la UART en mode simulacio
    UCA0IE &= ~UCRXIE; // Interrupcions desactivades en Rx

    read_data_UART = UCA0RXBUF; // Assignem a una variable global el valor de la seguent dada a llegir
    received_data = 1;
    UCA0IE | UCRXIE; // Interrupcions reactivades en Rx
}

// Interrupcio al rebre una dada
void EUSCIA2_IRQHandler(void)
{
    // Interrupcio de recepcio en la UART en mode real
    UCA2IE &= ~UCRXIE; //Interrupcions desactivades en RX

    read_data_UART = UCA2RXBUF; // Assignem a una variable global el valor de la seguent dada a llegir
    received_data = 1; // La dada ha arribat

    UCA2IE |= UCRXIE; //Interrupcions reactivades en RX
}

// Interrupcio pel TIMER DE 1 MS
void TA1_0_IRQHandler(void) {

    TA1CCTL0 &= ~CCIE;      // Deshabilitem les interrupcions mentre tractem aquesta

    current_time++;         // Augmentem el temps actual

    TA1CCTL0 &= ~CCIFG;     // Quitem el flag d'interrupcio
    TA1CCTL0 |= CCIE;       // Habilitem les interrupcions
}
