#include <msp432p401r.h>
#include <stdio.h>
#include <stdint.h>

uint32_t timer_ms_count;

/* Funcio que ens servira per girar amb un cert angle */
void delay_t(uint32_t temps_ms)
{
    timer_ms_count = 0;                     // Reiniciar Timer ms
    TA0CTL |= MC_1;                         // S'habilita el Timer
    do {

    } while (timer_ms_count <= temps_ms);   // Timer anira sumant +1 a la varibale timer_ms_count fins arribar al temps establert
    TA0CTL &= ~MC_1;                        // Es deshabilita el timer
}


