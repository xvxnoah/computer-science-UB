
#ifndef INTERRUPT_H_
#define INTERRUPT_H_

void init_interrupciones(void);

#endif /* INTERRUPT_H_ */
