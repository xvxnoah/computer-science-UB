/******************************
 *
 * Practica_02_PAE Programació de Ports
 * i pràctica de les instruccions de control de flux:
 * "do ... while", "switch ... case", "if" i "for"
 * UB, 02/2021.
 *
 * ALEJANDRO GUZMAN REQUENA & NOAH MARQUEZ VARA (GRUP DIMARTS c00)
 *****************************/

#include <msp432p401r.h>
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

#define LED_V_BIT BIT0

#define SW1_POS 1
#define SW2_POS 4
#define SW1_INT 0x04
#define SW2_INT 0x0A
#define SW1_BIT BIT(SW1_POS)
#define SW2_BIT BIT(SW2_POS)

#define RETRASO 300000

/* Inicialització de les variables que necessitarem durant l'execució del programa:
 *  --> estado: guardarà l'estat en que ens trobem a cada moment per tal de fer una acció o un altre (l'hem inicialitzat a NULL
 *              per distingir quan polsem per primera vegada).
 *  --> check_S2: variable que farem servir per tal de poder polsar vàries vegades S2 i aconseguir desplaçar
 *                els LEDS RGB  tal i com demana l'enunciat (l'hem inicialitzat a false ja que encara no hem premut S2).
 *
 * */
volatile uint8_t estado = NULL;
static bool check_S2 = false;

/**************************************************************************
 * INICIALIZACIÓN DEL CONTROLADOR DE INTERRUPCIONES (NVIC).
 *
 * Sin datos de entrada
 *
 * Sin datos de salida
 *
 **************************************************************************/
void init_interrupciones()
{
    // Configuracion al estilo MSP430 "clásico":
    // --> Enable Port 4 interrupt on the NVIC.
    // Segun el Datasheet (Tabla "6-39. NVIC Interrupts", apartado "6.7.2 Device-Level User Interrupts"),
    // la interrupcion del puerto 1 es la User ISR numero 35.
    // Segun el Technical Reference Manual, apartado "2.4.3 NVIC Registers",
    // hay 2 registros de habilitacion ISER0 y ISER1, cada uno para 32 interrupciones (0..31, y 32..63, resp.),
    // accesibles mediante la estructura NVIC->ISER[x], con x = 0 o x = 1.
    // Asimismo, hay 2 registros para deshabilitarlas: ICERx, y dos registros para limpiarlas: ICPRx.

    //Int. port 1 = 35 corresponde al bit 3 del segundo registro ISER1:
    NVIC->ICPR[1] |= BIT3; //Primero, me aseguro de que no quede ninguna interrupcion residual pendiente para este puerto,
    NVIC->ISER[1] |= BIT3; //y habilito las interrupciones del puerto

}

/**************************************************************************
 * INICIALIZACION DE LOS BOTONES & LEDS DEL BOOSTERPACK MK II.
 *
 * Sin datos de entrada
 *
 * Sin datos de salida
 *
 **************************************************************************/
void init_botons(void)
{
    //Configuramos botones i LED vermell
    //***************************
    P1SEL0 &= ~(BIT0 + BIT1 + BIT4 );    //Els polsadors son GPIOs
    P1SEL1 &= ~(BIT0 + BIT1 + BIT4 );    //Els polsadors son GPIOs

    //LED vermell = P1.0
    P1DIR |= LED_V_BIT;      //El LED es una sortida
    P1OUT &= ~LED_V_BIT;     //El estat inicial del LED es apagat

    //Boto S1 = P1.1 i S2 = P1.4
    P1DIR &= ~(SW1_BIT + SW2_BIT );    //Un polsador es una entrada
    P1REN |= (SW1_BIT + SW2_BIT );     //Pull-up/pull-down pel pulsador
    P1OUT |= (SW1_BIT + SW2_BIT ); //Donat que l'altra costat es GND, volem una pull-up
    P1IE |= (SW1_BIT + SW2_BIT );      //Interrupcions activades
    P1IES &= ~(SW1_BIT + SW2_BIT );    // amb transicio L->H
    P1IFG = 0;                  // Netegem les interrupcions anteriors
}

/**************************************************************************
 * DELAY - A CONFIGURAR POR EL ALUMNO - con bucle for (com demana l'enunciat de la practica)
 *
 * Datos de entrada: Tiempo de retraso. 1 segundo equivale a un retraso de 1000000 (aprox)
 *
 * Sin datos de salida
 *
 **************************************************************************/
void delay_t(uint32_t temps)
{
    volatile uint32_t i;

    /**************************
     * TODO PER PART DEL ALUMNE AMB UN BUCLE FOR
     * Un cop implementat, comenteu o elimineu la seguent funcio
     **************************/

    //__delay_cycles(RETRASO);

    // Solucio

    /* Simplement hem fet un bucle for que compti des de 0 fins al numero indicat,
     * per tal de generar un cert delay en el LED vermell que fa pampallugues.*/
    for(i = 0; i < temps; i++){
    }
}

/*****************************************************************************
 * CONFIGURACION DE LOS LEDs DEL PUERTO 2. A REALIZAR POR EL ALUMNO
 *
 * Sin datos de entrada
 *
 * Sin datos de salida
 *
 ****************************************************************************/
void config_RGB_LEDS(void)
{
    /**************************
     * TODO PER PART DEL ALUMNE
     **************************/

    /* En aquest metode es realitza la inicialitzacio dels LEDs del port 2 (RGB).
     * Primerament s'indica que els LEDs actuaran com a sortida (emeten llum) i
     * posteriorment s'indica explicitament que volem que tots els LEDs comencin
     * apagats, per tal d'assegurar-nos que fan el que volem. */

    //LED2_RED = P2.0
    P2DIR |= LED_V_BIT;     //El LED es una sortida
    P2OUT &= ~LED_V_BIT;    //El estat inicial del LED es apagat

    //LED2_GREEN = P2.1
    P2DIR |= BIT1;      //El LED es una sortida
    P2OUT &= ~BIT1;     //El estat inicial del LED es apagat

    //LED2_BLUE = P2.2
    P2DIR |= BIT2;      //El LED es una sortida
    P2OUT &= ~BIT2;     //El estat inicial del LED es apagat
}

void main(void)
{
    /* Variable on guardarem l'estat anterior per tal de decidir si entrarem al condicional if. */
    static uint8_t estado_anterior;

    /* Variables que utilitzarem a l'hora de gestionar l'estat 3 (pulsacio del botó S2) per tal de guardar
     * els estats dels LEDS RGB (encesos o apagats) i fer-los servir per tal de realitzar la transicio que
     * demana l'enunciat de la practica. */
    static uint8_t puerto_azul;
    static uint8_t puerto_rojo;
    static uint8_t puerto_verde;

    /* Per tal d'evitar que entrem al condicional if al primer moment d'iniciar el nostre programa, inicialitzem
     * la variable 'estado_anterior' a un nombre diferent dels que pot tenir la variable 'estado' (tot i que aquesta
     * començara a NULL). Li hem posat un valor de 4 (aleatoriament) i no el de '-1' que venia amb el codi de la
     * practica ja que la variable 'estado_anterior' es de tipus unsigned int (aixi ens evitem un Warning). */
    estado_anterior = 4;

    /* El proposit del watchdog timer es reiniciar el microcontrolador a la forca si el codi es penja per algun motiu.
     * Te un periode de temps d'espera i, si no l'indiquem que tot esta funcionant correctament, aquest reiniciara el
     * microcontrolador. En el nostre micro el watchdog timer esta ences per defecte, es per aio que a l'iniciar tots
     * els programes l'hem de desactivar. */
    WDTCTL = WDTPW + WDTHOLD;       // Stop watchdog timer

    /* Cridem als metodes per inicialitzar els botons i configurar els LEDS RGB (metodes indicats anteriorment). */
    init_botons();
    config_RGB_LEDS();

    /* Cridem al metode que configura i inicialitza el controlador de les interrupcions dels botons. */
    init_interrupciones();

    /* Habilitem les interrupcions a nivell global al registre de “status” del processador. */
    __enable_interrupts();

    //Bucle principal (infinito):
    while (true)
    {
        /* Segons el valor de l'estat i de si em polsat anteriorment el boto S2 o no, realitzarem una accio o un altre. */
        if (estado_anterior != estado || check_S2)
        {
            estado_anterior = estado;

            /**********************************************************+
             A RELLENAR POR EL ALUMNO BLOQUE  switch (estado) ... case
             Para gestionar las acciones:
             Boton S1 presionado un numero impar de veces, estado = 1
             Boton S1 presionado un numero par de veces, estado = 2
             Boton S2, estado = 3
             ***********************************************************/

            /* Switch on segons l'estat en que ens trobem farem una accio o un altre, seguint l'esquema d'estats i accions de
             * l'enunciat. */
            switch(estado){
                /* Estat = 1: s'han d'encendre tots els LEDs RGB, per tal de fer aio fem us d'una porta OR (|) per tal de fer
                 * una mascara i l'indiquem que volem posar un 1 en els bits indicats (0, 1 i 2).*/
                case 1:
                    P2OUT |= (LED_V_BIT + BIT1 + BIT2);
                    break;

                /* Estat = 2: s'ha d'invertir l'estat dels LEDs RGB, per tal de realitzar-ho fem servir una porta XOR (^) per tal
                 * de fer una mascara i l'indiquem que volem invertir els bits indicats (e.g. si hi ha un '1' passa a ser un '0'). */
                case 2:
                    P2OUT ^= (LED_V_BIT + BIT1 + BIT2);
                    break;

                /* Estat = 3: hem de desplaçar els estats dels LEDs RGB seguint les indicacions de l'enunciat de la practica; el valor
                 * del LED blau passa a ser el valor del LED verd, el valor del LED verd passa a ser el valor del LED vermell i el LED
                 * vermell s'apaga.*/
                case 3:
                    /* Guardem en les variables l'estat del LED verd i del LED vermell (apagat o encèes). */
                    puerto_verde = P2OUT & BIT1;
                    puerto_rojo = P2OUT & LED_V_BIT;

                    /* Fem les transicions indicades anteriorment i a l'enunciat de la practica fent un shift left en els dos casos, ja
                     * que en les variables anteriors tindrem guardat el valor per exemple del 'puerto_verde' de la seguent forma:
                     * 00000010 (LED verd encès) i si volem que el 'puerto_azul' tingui aquest estat, hem de desplaçar a l'esquera de tal
                     * forma que el bit del verd (1) estigui en la posició del bit blau (2), de tal forma que ens quedaria aixi:
                     * 00000100. */
                    puerto_azul = puerto_verde << 1;
                    puerto_verde = puerto_rojo << 1;

                    /* En cas que despres de fer el desplaçament el bit verd s'hagi d'encendre, fem us d'una porta OR per tal de posar un
                     * 1 en la seva posicio (BIT1). Altrament, apaguem el LED verd com hem fet a l'hora de configurar-lo. */
                    if(puerto_verde == 0x02){
                        P2OUT |= puerto_verde;
                    } else{
                        P2OUT &= ~BIT1;
                    }

                    /* El mateix que pel LED verd pero ara per tal de modificar el bit del LED blau (BIT2). */
                    if(puerto_azul == 0x04){
                        P2OUT |= puerto_azul;
                    } else{
                        P2OUT &= ~BIT2;
                    }

                    /* Sigui quin sigui la transformació realitzada, hem d'apagar el LED vermell posant un 0 a la seva posicio (BIT0 o
                     * LED_V_BIT). Per fer aixo femus d'una porta AND i neguem el contingut de LED_V_BIT (00000001) de tal forma que al
                     * negar-ho quedaria de la seguent forma: 11111110, i al fer una porta AND amb P2OUT, ens quedarem amb els seus valors
                     * anteriors i posarem un 0 a la posicio 0. */
                    P2OUT &= ~LED_V_BIT;

                    /* En cas de que haguem entrat al switch per haver premut dos cops seguits el boto S2, desactivem la variable que ens
                     * permet saber si l'hem premut dos cops seguits o no. */
                    if(check_S2){
                        check_S2 = false;
                    }

                    break;
            }
        }

        /* Commutem l'estat del LED vermell que fa pampallugues. */
        P1OUT ^= LED_V_BIT;

        /* Cridem a la funcio que hem realitzat anteriorment per tal de donar un cert periode de delay al LED. */
        delay_t(RETRASO);
    }

}

/**************************************************************************
 * RUTINAS DE GESTION DE LOS BOTONES:
 * Mediante estas rutinas, se detectara qué boton se ha pulsado
 *
 * Sin Datos de entrada
 *
 * Sin datos de salida
 *
 * Actualizar el valor de la variable global estado
 *
 **************************************************************************/

//ISR para las interrupciones del puerto 1:
void PORT1_IRQHandler(void)
{
    /* Variable que ens permetra saber en tot moment si hem premut un nombre imparell o parell de vegades
     * el boto S1. */
    static bool impar;

    /* Guardem el vector d'interrupcions del port 1. Alhora d'accedir-hi, es neteja automaticament, es a dir, es desactiven els
     * flags que han fet saltar la interrupcio. */
    uint8_t flag = P1IV;

    /* Per tal d'evitar que salti un altre interrupcio mentre encara estem gestionant la present, les desactivem. */
    P1IE &= ~(SW1_BIT + SW2_BIT );

    /**********************************************************+
         A RELLENAR POR EL ALUMNO
         Para gestionar los estados:
                 Boton S1 presionado un numero impar de veces, estado = 1
                 Boton S1 presionado un numero par de veces, estado = 2
                 Boton S2, estado = 3
    ***********************************************************/

    switch (flag)
    {
    /* S'ha premut el boto S1. */
    case SW1_INT:
        /* En cas que el primer boto que polsem sigui S1, l'haurem premut un nombre imparell de vegades (1),
         * i per tant hem de posar l'estat a 1 i la variable impar a false, ja que el seguent cop que premem
         * el boto S1, ja sera parell. */
        if(estado == NULL){
            estado = 1;
            impar = false;
        }
        /* En cas que ja haguem premut algun dels dos botons (S1 o S2) anteriorment, hem de distingir el cas
         * en que haguem premut un nombre imparell/parell de vegades S1 per tal de decidir quin valor assignar
         * a la variable 'estado'. */
        else{
            if(impar){
                estado = 1;
            } else{
                estado = 2;
            }

            /* Un cop assignat el valor a la variable 'estado', invertim el valor de la variable 'impar'; si haviem
             * premut un nombre imparell de vegades, doncs ara 'impar' sera true per tal d'indicar que el seguent
             * cop que premem el boto S1, sera un nombre imparell i viceversa. */
            impar = !impar;
        }
        break;

    /* S'ha premut el boto S2. */
    case SW2_INT:
        /* Si l'estat es igual a 3, vol dir que el boto que s'ha polsat anteriorment ha estat S2, per tant posem a true
         * la variable 'check-S2' que ens permetra entrar a la condicio de l'if del main per tal de poder premer varis
         * cops el boto S2. */
        if(estado == 3){
            check_S2 = true;
        }

        /* Si S2 es el primer boto que premem, posem l'estat a 3 i iniciem la variable 'impar' a true per tal d'indicar
         * que quan polsem S1 per primera vegada, sera imparell. */
        else if(estado == NULL){
            estado = 3;
            impar = true;
        }
        /* En qualsevol altre cas, indiquem que l'estat es igual a 3. */
        else{
            estado = 3;
        }
        break;
    }

    /* Un cop que hem gestionat la interrupcio, tornem a activar les interrupcions dels nostres botons (S1 i S2) en el port 1. */
    P1IE |= (SW1_BIT + SW2_BIT);
}

