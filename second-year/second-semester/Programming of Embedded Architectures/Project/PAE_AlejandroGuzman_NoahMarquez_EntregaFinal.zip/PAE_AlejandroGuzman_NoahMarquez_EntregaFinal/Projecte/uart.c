#include <msp432p401r.h>
#include <stdint.h>
#include <stdio.h>
#include "lcd.h"
#include "uart.h"

#define TXD2_READY (UCA2IFG & UCTXIFG)

/* Configuracio de la UART en mode real, utilitzant els moduls Dynamixel i el sensor del robot de laboratori */
/* La UART funciona en mode real configurant la UCA2 situada en el port 3 (pin 3.0 de direction port, 3.2 UCA0RXD, 3.3 UCA2TXD). */
void init_UART(void)
{
    /* A continuacio configurem tres registres importants de la UCA2 amb les caracteristiques que volem que tingui la UART configurada */
    UCA2CTLW0 |= UCSWRST;           /* Fem un reset de la USCI, desactiva la USCI */
    UCA2CTLW0 |= UCSSEL__SMCLK;     /* UCSYNC=0 mode asincron */
                                    /* UCMODEx=0 seleccionem mode UART */
                                    /* UCSPB=0 nomes 1 stop bit */
                                    /* UC7BIT=0 8 bits de dades */
                                    /* UCMSB=0 bit de menys pes primer */
                                    /* UCPAR=x ja que no es fa servir bit de paritat */
                                    /* UCPEN=0 sense bit de paritat */
                                    /* Triem SMCLK (24M Hz) com a font del clock BRCLK */

    UCA2MCTLW = UCOS16;             /* Necessitem sobre-mostreig => bit 0 = UCOS16 = 1 */
    UCA2BRW = 3;                    /* Prescaler de BRCLK fixat a 3. Com SMCLK va a24MHz, volem un baud rate de 500kb/s i fem sobre-mostreig de 16
                                     * el rellotge de la UART ha de ser de 8MHz (24MHz/3). */

    /* Configurem els pins de la UART */
    /* P3.2 = RX, P3.3 = TX, P3.0 = Direction port */
    P3SEL0 |= BIT2 | BIT3; /* I/O funcio: P3.3 = UART2TX, P3.2 = UART2RX */
    P3SEL1 &= ~(BIT2 | BIT3);

    /* Configurem pin de seleccio del sentit de les dades Transmissio / Recepecio */
    P3SEL0 &= ~BIT0; /* Port P3.0 com GPIO */
    P3SEL1 &= ~BIT0;
    P3DIR |= BIT0; /* Port P3.0 com A sortida (Data Direction selector Tx/Rx) */
    P3OUT &= ~BIT0; /* Inicialitzem Sentit Dades a 0 (Rx) */
    UCA2CTLW0 &= ~UCSWRST; /* Reactivem la linia de comunicacions serie */
    UCA2IE |= UCRXIE; /* Aixo nomes s'ha d'activar quan tinguem la rutina de recepcio */
}

/* A continuacio tenim les funcions relatives a la transmissio i recepcio de dades dels moduls dynamixel */

/* Sentit: Rebre dades */
void Sentit_Dades_Rx(void){
    /* Configuracio del Half Duplex dels motors: Recepcio */
    P3OUT &= ~BIT0; /* El pin P3.0 (DIRECTION_PORT) el posem a 0 (Rx)*/
}

/* Sentit: Enviar les dades */
void Sentit_Dades_Tx(void){
    /* Configuracio del Half Duplex dels motors: Transmissio */
    P3OUT |= BIT0; /* El pin P3.0 (DIRECTION_PORT) el posem a 1 (Tx) */
}

/* Enviar un byte per la UART */
void TxUAC2(byte bTxdData)
{
    while(!TXD2_READY); /* Espera a que estigui preparat el buffer de transmissio */
    UCA2TXBUF = bTxdData;
}


/* Funcio de transmissio del paquet d'instruccio */
byte TxPacket(byte bID, byte bParameterLength, byte bInstruction, byte Parametros[16])
{
    byte bCount, bCheckSum, bPacketLength;
    volatile int i = 50;
    char error[] = "adr. no permitida";

    /* Si s'intenta escriure en una direccio de memoria <= 0x05 */
    if(Parametros[0] < 5 && bInstruction == 3){
        halLcdPrintLine(error,8,INVERT_TEXT); /* Emetre missatge d'error de direccio prohibida */
        return 0; /* I sortim de la funcio */
    }

    byte TxBuffer[32];
    Sentit_Dades_Tx();  /* El pin P3.0 (DIRECTION_PORT) el posem a 1 (Transmetre) */

    TxBuffer[0] = 0xff; /* Primers 2 bytes que indiquen inici de trama FF, FF */
    TxBuffer[1] = 0xff;

    TxBuffer[2] = bID; /* ID del modul al que volem enviar el missatge */
    TxBuffer[3] = bParameterLength+2; /* Length(Parameter,Instruction,Checksum) */
    TxBuffer[4] = bInstruction; /* Instruccio que enviem al Modul */

    for(bCount = 0; bCount < bParameterLength; bCount++) /* Comencem a generar la trama que hem d'enviar */
    {
        TxBuffer[bCount+5] = Parametros[bCount];
    }

    /* Inicialitzem a 0 la variable del checksum que utilizarem per comprovar si s'han enviat correctament les dades */
    bCheckSum = 0;

    /* Inicialitzem i assignem la longitud del paquet d'enviament com la longitud de parametres + 4 + 2 */
    bPacketLength = bParameterLength+4+2;

    for(bCount = 2; bCount < bPacketLength-1; bCount++) /* Calcul del checksum */
    {
        bCheckSum += TxBuffer[bCount];
    }

    TxBuffer[bCount] = ~bCheckSum; /* Escrivim el Checksum (complement a 1) */

    for(bCount = 0; bCount < bPacketLength; bCount++) /* Aquest bucle es el que envia la trama al Modul Robot */{
        TxUAC2(TxBuffer[bCount]);
    }

    while( (UCA2STATW&UCBUSY)); /* Espera fins que s'ha transmes l'ultim byte */

    Sentit_Dades_Rx(); /* Possem la linia de dades en Rx perque el modul Dynamixel envii una resposta */

    return(bPacketLength);
}


/* Configuracio del paquet que el modul Dynamixel enviara al microcontrolador com a resposta de la transmissio de dades realitzada */
struct RxReturn RxPacket(void)
{
    /* Inicialitzem una variable de tipus struct RxReturn definida com una estructura de dades */
    struct RxReturn respuesta;

    /* Declarem la resta de variables */
    byte bCount, bLenght, bCheckSum;
    bool Rx_time_out;

    Sentit_Dades_Rx(); /* Possem la linia de dades en Rx perque el modul Dynamixel envii una resposta */

    Activa_TimerA1_TimeOut(); /* Activem el timer pel time out */

    /* Llegim els quatre primers parametres */
    for(bCount = 0; bCount < 4; bCount++){
        Reset_Timeout(); /* Fem un reset del timer */
        Byte_Recibido = false; /* Si esta a false vol dir que no s'ha rebut el byte */

        while (!Byte_Recibido){ /* Mentre no es rebi la dada */
            Rx_time_out = timeOut(1000);  /* Temps d'espera en milisegons */
            if (Rx_time_out)break;      /* Si s'ha esgotat el temps d'espera per a rebre una dada sortim del bucle */
        }

        if (Rx_time_out)break; /* Sortim del bucle si s'ha produit un time_out */

        /* Si tot ha anat correctament, llegim una dada del paquet rebut */
        respuesta.StatusPacket[bCount] = DatoLeido_UART;
    }


    if (!Rx_time_out){  /* Si no n'hi ha time_out continua llegint la resta de bytes del Status Packet */

        /* Inicialitzem una variable que guarda la longitud del total que anem a llegir */
        bLenght = DatoLeido_UART;

        /* Llegim la resta de dades */
        for(bCount = 0; bCount < bLenght; bCount++){
            Reset_Timeout(); /* Fem un reset del timer */
            Byte_Recibido = false;

            while (!Byte_Recibido){ /* Mentre no es rebi la dada */
                Rx_time_out = timeOut(1000);  /* Temps d'espera en milisegons */
                if (Rx_time_out)break;      /* Si s'ha esgotat el temps d'espera per a rebre una dada sortim del bucle */
            }

            if (Rx_time_out)break; /* Sortim del bucle si s'ha produit un time_out */

            /* Si tot ha anat correctament, llegim una dada del paquet rebut */
            respuesta.StatusPacket[bCount+4] = DatoLeido_UART;
        }

        /* Guardem el checksum */
        bCheckSum = respuesta.StatusPacket[bLenght+3];

        /* Comprobem si els dos checksum son iguals (0) o diferents (error: 1)*/
        respuesta.eCheckSum = bCheckSum != ~checkSum(respuesta.StatusPacket, bLenght);
    }

    if(Rx_time_out){
        respuesta.timeout = true;
    }

    /* Si hem arribat a aquest punt parem el timer */
    Stop_Timeout();

    return respuesta;
}

/* Funcio per realitzar el checksum segons la formula */
uint32_t checkSum(byte packet[16], uint8_t length){
    int i; /* Comptador pel bucle for */
    uint32_t result = 0; /* Anem acumulant la suma del checksum */

    for(i = 2; i < length + 3; i++){
        result += packet[i]; /* Sumem l'ID + cadascun dels parametres + el length */
    }

    return result; /* Retornem el resultat per comparar amb el checksum original */
}

/* Funcio que retorna true si el comptador temps ha superat el temps passat per parametre */
bool timeOut(uint32_t t){
    return temps >= t;
}

/* Establim el timer a mode UP */
void Activa_TimerA1_TimeOut(){
    TA1CTL |= MC_1;
}

/* Establim el timer a mode STOP */
void Stop_Timeout(){
    TA1CTL &= ~MC_0;
    temps = 0;
}

/* Fem reset de la variable temps */
void Reset_Timeout(){
    TA1CTL &= ~MC_0; /* Mode STOP */
    temps = 0;
    TA1CTL |= MC_1; /* Mode UP */
}

/* Establim el timer en mode STOP */
void Stop_Timeout_A0(){
    TA0CTL &= ~MC_0; /* Mode STOP */
    temps = 0;
}

/* Fem reset de la variable temps */
void Reset_Timeout_A0(){
    TA0CTL &= ~MC_0; /* Mode STOP */
    temps = 0;
    TA0CTL |= MC_1; /* Mode UP */
}

/* Subrutina per a la interrupcio del timer A1 */
void TA1_0_IRQHandler (void){
    TA1CCTL0 &= ~CCIE; /* Conve inhabilitar la interrupcio al comencament */
    temps++;   /* El timer augmentara el temps en una unitat */

    TA1CCTL0 &= ~CCIFG; /* Hem de netejar el flag de la interrupcio */
    TA1CCTL0 |= CCIE; /* S'ha d'habilitar la interrupcio abans de sortir */
}

/* Interrupcio de recepcio en la UART */
void EUSCIA2_IRQHandler(void){
    UCA2IE &= ~UCRXIE; /* Interrupcions desactivades en RX */
    DatoLeido_UART = UCA2RXBUF;
    Byte_Recibido = true;
    UCA2IE |= UCRXIE; /* Interrupcions reactivades en RX */
}

