#ifndef UART_H_
#define UART_H_

#include <msp432p401r.h>
#include <stdio.h>
#include <stdint.h>
#include "lib_PAE2.h"

typedef int bool;
#define true 1
#define false 0

typedef uint8_t byte;

/* Format dels paquets de dades */
struct RxReturn{
    byte StatusPacket[16];
    bool timeout;
    bool eCheckSum;
};

uint16_t temps;
uint16_t DatoLeido_UART;
byte Byte_Recibido;

void init_UART(void);


/* Funcions per a transmisio / recepcio de dades */
byte TxPacket(byte bID, byte bParameterLength, byte bInstruction, byte Parametros[16]);
struct RxReturn RxPacket(void);
void TxUAC2(byte bTxdData);
void Sentit_Dades_Rx(void);
void Sentit_Dades_Tx(void);
void EUSCIA2_IRQHandler(void);
uint32_t checkSum(byte packet[16], uint8_t length);
bool timeOut(uint32_t t);


/* Funciones relatives al timer */
void Activa_TimerA1_TimeOut();
void Stop_Timeout();
void Reset_Timeout();
void Stop_TimeOut_A0();
void Reset_TimeOut_A0();
void TA1_0_IRQHandler (void);

#endif /* UART_H_ */
