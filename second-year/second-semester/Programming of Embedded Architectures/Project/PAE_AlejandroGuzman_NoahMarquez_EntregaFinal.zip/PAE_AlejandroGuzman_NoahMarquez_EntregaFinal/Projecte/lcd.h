#ifndef LCD_H_
#define LCD_H_

void init_LCD(void);
void borrar(uint8_t linia);
void escribir(char String[], uint8_t linia);

#endif /* LCD_H_ */
