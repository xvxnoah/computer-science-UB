#ifndef INTERRUPCIONS_H_
#define INTERRUPCIONS_H_

void init_interrupcions(void);

#endif
