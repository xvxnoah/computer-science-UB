#ifndef HARDWARE_H_
#define HARDWARE_H_

#include <msp432p401r.h>
#include <stdio.h>
#include <stdint.h>
#include "lib_PAE2.h"

/* Aqui tindrem toda la capa on es configurem i s'inicialitzen tots els recursos principals i necessaris de la placa.
 *
 * Tenim inicitalitzacions de: interrupcions, botons, UART i Timers juntament amb els seus respectius handlers.
 */

void init_recursos();

#endif
