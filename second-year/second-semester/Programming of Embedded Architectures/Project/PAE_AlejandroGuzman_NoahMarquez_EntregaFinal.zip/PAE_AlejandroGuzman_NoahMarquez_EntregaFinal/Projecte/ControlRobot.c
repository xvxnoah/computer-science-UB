#include <ControlRobot.h>
#include <stdio.h>
#include <stdlib.h>


/* Funcio que inicialitza les variables i a la vegada inicialitza tots els recursos necessaris del microcontrolador */
void init(){
    speed = MINSPEED;
    wall = WALL_NONE;
    direction = true;
    init_recursos();
    mode = true;
    sens = 30;
}

/* Funcio que conte l'algorisme de moviment del robot segons quina sigui la situacio */
void robotRoute(struct RxReturn estructura){
    /* Ens guardem els valors dels tres sensors */
    uint8_t id = estructura.StatusPacket[2], snsEsquerra = estructura.StatusPacket[5], snsCentral = estructura.StatusPacket[6], snsDret = estructura.StatusPacket[7];

    switch(wall){
        /* Cas inicial: no hem trobat cap paret encara i anirem recte fins trobar alguna */
        case WALL_NONE:
            if(id == 100){
                /* En el cas de que cap sensor detecti res, continuem recte */
                if(snsCentral == 0 && snsEsquerra == 0 && snsDret == 0){
                    apagarLedsMotor();
                    encenderLedsMotor(true,true);
                    moveRobot(true,speed);

                    bool timeout;
                    Reset_Timeout();

                    while (1){
                        timeout=timeOut(550);
                        if (timeout) break;
                    }
                }
                /* Si el sensor esquerra detecta un obstacle abans que dreta amb un valor superior a 10, seguirem la paret per l'esquerra */
                else if (snsEsquerra > snsDret && snsEsquerra >= sens){
                    setWall(WALL_I);
                }
                /* Si el sensor dret detecta un obstacle abans que l'esquerra amb un valor superior a 10, seguirem la paret per la dreta */
                else if(snsEsquerra < snsDret && snsDret >= sens){
                    setWall(WALL_D);
                }
            }
        /* Cas en el que haguem de seguir la paret de l'esquerra */
        case WALL_I:
            if (id == 100){
                /* Si tots els sensors detecten un valor mes gran a la sensibilitat donada, voldra dir que ens hem quedat tancats i hem d'anar enrere */
                if(snsCentral >= sens && snsEsquerra >= sens-20 && snsDret >= sens-20 && reverseActive){
                    setWall(WALL_BREAK);
                }
                /* Si el valor del sensor central o el de l'esquerra es superior a la sensibilitat donada, anem a la dreta */
                else if (snsCentral >= sens || snsEsquerra >= sens){
                    apagarLedsMotor();             /* Apaguem els llums del motor */
                    direction = true;
                    encenderLedsMotor(true,false); /* Encenem les llums de moviment cap a la dreta */
                    spinRobot(direction,speed);    /* Anem a la dreta */

                }
                /* Si el valor del sensor central i el de l'esquerra son inferiors a la sensibilitat donada -5, anem a l'esquerra */
                else if (snsCentral <= (sens - 10) && snsEsquerra <= (sens - 10)){
                    apagarLedsMotor();             /* Apaguem els llums del motor */
                    direction = false;
                    encenderLedsMotor(false,true); /* Encenem les llums de moviment cap a l'esquerra */
                    spinRobot(direction,speed);    /* Anem a l'esquerra */
                }
                /* En cap altre cas, anem recte */
                else{
                    apagarLedsMotor();              /* Apaguem els llums del motor */
                    encenderLedsMotor(true,true);   /* Encenem les llums dels dos motors per indicar que anem endavant */
                    moveRobot(true,speed);          /* Anem recte */

                    bool timeout;
                    Reset_Timeout();

                    while (1){
                        timeout=timeOut(550);
                        if (timeout) break;
                    }
                }
            }
            break;
        /* Cas en el que haguem de seguir la paret de la dreta */
        case WALL_D:
            if (id == 100){
                /* Si tots els sensors detecten un valor mes gran a la sensibilitat donada, voldra dir que ens hem quedat tancats i hem d'anar enrere */
                if(snsCentral >= sens && snsEsquerra >= sens-20 && snsDret >= sens-20 && reverseActive){
                    setWall(WALL_BREAK);
                }
                /* Si el valor del sensor central o el de la dreta es superior a la sensibilitat donada, anem a l'esquerra */
                if (snsCentral >= sens || snsDret >= sens){
                    apagarLedsMotor();              /* Apaguem els llums del motor */
                    direction = false;
                    encenderLedsMotor(false, true); /* Encenem les llums de moviment cap a l'esquerra */
                    spinRobot(direction,speed);     /* Anem a l'esquerra */

                }else if (snsCentral <= (sens-10) && snsDret <= (sens-10)){
                    apagarLedsMotor();              /* Apaguem els llums del motor */
                    direction = true;
                    encenderLedsMotor(true, false); /* Encenem les llums de moviment cap a la dreta */
                    spinRobot(direction,speed);     /* Anem a la dreta */
                }
                else{
                    apagarLedsMotor();              /* Apaguem els llums del motor */
                    encenderLedsMotor(true,true);   /* Encenem les llums de moviment cap a la dreta */
                    moveRobot(true,speed);          /* Anem recte */

                    bool timeout;
                    Reset_Timeout();

                    while (1){
                        timeout=timeOut(550);
                        if (timeout) break;
                    }
                }
            }
            break;
        /* Cas en el que el robot es troba en un cami sense sortida i hem d'anar enrere */
        case WALL_BREAK:
            if (id == 100){
                moveRobot(false, speed); /* El robot fa marxa enrere */

                /* Si trobem que el sensor dret ha deixat de detectar obstacle i el sensor dret es inferior a l'esquerra, reseguirem la paret dreta, girant cap a ella */
                if(snsDret == 0 && snsDret < snsEsquerra){
                    delay(1000);
                    spinRobot(true, speed); /* Anem a la dreta */

                    setWall(WALL_I); /* Ara el robot seguira la paret dreta */
                }
                /* Si trobem que el sensor esquerra ha deixat de detectar obstacle i el sensor esquerra es inferior al dret, reseguirem la paret esquerra, girant cap a ella */
                else if(snsEsquerra == 0 && snsEsquerra < snsDret){
                    delay(1000);
                    spinRobot(false, speed); /* Anem a l'esquerra */

                    setWall(WALL_D); /* Ara el robot seguira la paret esquerra */
                }
            }
            break;
    }
}

/* Getters & Setters de les diferents variables */
void setSpeed(uint16_t vel){
    speed = vel;
}

void setWall(uint8_t right){
    wall = right;
}

void setDirection(bool direc){
    direction = direc;
}

void setMode(bool aut){
    mode = aut;
}

void setSens(uint16_t col){
    sens = col;
}

void setReverseActive(bool reverse){
    reverseActive = reverse;
}

uint16_t getSpeed(){
    return speed;
}

uint8_t getWall(){
    return wall;
}

bool getDirection(){
    return direction;
}

bool getMode(){
    return mode;
}

uint16_t getSens(){
    return sens;
}

bool getReverseActive(){
    return reverseActive;
}

