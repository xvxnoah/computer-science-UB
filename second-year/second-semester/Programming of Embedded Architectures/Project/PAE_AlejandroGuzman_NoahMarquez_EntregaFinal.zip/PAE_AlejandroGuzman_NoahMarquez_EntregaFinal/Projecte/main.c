#include <ControlRobot.h>
#include "lcd.h"
#include "botons.h"
#include "interrupcions.h"
#include "timers.h"
#include "uart.h"

/* En el main imprimirem el menu. Aquest es dedicara a configurar la sensibilitat dels sensors, resetejar l'estat del robot, comencar a moure's o be mostrar els valors dels sensors */

/* Utilitzarem tant els botons com els joysticks, aixi que els declarem a continuacio */
#define Button_S1 1
#define Button_S2 2
#define Jstick_Right 3
#define Jstick_Left 4
#define Jstick_Up 5
#define Jstick_Down 6
#define Jstick_Center 7

/* Definim les diferents variables que necessitarem durant l'execucio del codi */
char configMsg[16] = " CONFIGURACIO"; /* Maxim 15 caracters visibles */
char cadena[16];
char reverseMsg[16] = "SI";
char noReverseMsg[16] = "NO";
uint8_t linea = 0;
uint8_t estado = 0;
uint8_t estado_anterior = 8;
bool sentido = true;
uint8_t menu = 0;
uint8_t selectedSubMenus = 0;
bool start = false;
bool aux = true;
bool aux2 = true;

void imprimirMenu(uint8_t selected){
    uint8_t i = 2;

    /* Eliminem tot el que hi hagi al menu */
    for (i = 2; i < 10; i++){
        borrar(i);
    }
    linea = 2;

    switch(selected){
    /* Cada cas indica que estem situats a una opcio diferent del menu */
    case 0:
        sprintf(cadena, "SENSIBILITAT %d", getSens()); /* Sensibilitat a la que volem configurar els sensors */
        halLcdPrintLine(cadena,linea++, INVERT_TEXT);

        sprintf(cadena, "VELOCITAT %d", getSpeed()); /* Velocitat a la qual va el robot */
        escribir(cadena,linea++);

        if(getReverseActive()){
            sprintf(cadena, "REVERSE %s", reverseMsg); /* Va marxa enrere en cas de trobar-se atascat */
        }else{
            sprintf(cadena, "REVERSE %s", noReverseMsg); /* Si volem que faci mitja volta en cas de trobar-se atascat */
        }
        escribir(cadena,linea++);

        sprintf(cadena, "RESETEAR"); /* Opcio per resetejar l'estat del robot */
        escribir(cadena,linea++);

        sprintf(cadena, "EMPEZAR"); /* Opcio per comencar a moure el robot */
        escribir(cadena,linea++);
        break;

    case 1:
        sprintf(cadena, "SENSIBILITAT %d", getSens()); /* Sensibilitat a la que volem configurar els sensors */
        escribir(cadena,linea++);

        sprintf(cadena, "VELOCITAT %d", getSpeed()); /* Velocitat a la qual va el robot */
        halLcdPrintLine(cadena,linea++, INVERT_TEXT);

        if(getReverseActive()){
            sprintf(cadena, "REVERSE %s", reverseMsg); /* Va marxa enrere en cas de trobar-se atascat */
        }else{
            sprintf(cadena, "REVERSE %s", noReverseMsg); /* Si volem que faci mitja volta en cas de trobar-se atascat */
        }
        escribir(cadena,linea++);

        sprintf(cadena, "RESETEAR"); /* Opcio per resetejar l'estat del robot */
        escribir(cadena,linea++);

        sprintf(cadena, "EMPEZAR"); /* Opcio per comencar a moure el robot */
        escribir(cadena,linea++);
        break;

    case 2:
        sprintf(cadena, "SENSIBILITAT %d", getSens()); /* Sensibilitat a la que volem configurar els sensors */
        escribir(cadena,linea++);

        sprintf(cadena, "VELOCITAT %d", getSpeed()); /* Velocitat a la qual va el robot */
        escribir(cadena,linea++);

        if(getReverseActive()){
            sprintf(cadena, "REVERSE %s", reverseMsg); /* Va marxa enrere en cas de trobar-se atascat */
        }else{
            sprintf(cadena, "REVERSE %s", noReverseMsg); /* Si volem que faci mitja volta en cas de trobar-se atascat */
        }
        halLcdPrintLine(cadena,linea++, INVERT_TEXT);

        sprintf(cadena, "RESETEAR"); /* Opcio per resetejar l'estat del robot */
        escribir(cadena,linea++);

        sprintf(cadena, "EMPEZAR"); /* Opcio per comencar a moure el robot */
        escribir(cadena,linea++);
        break;

    case 3:
        sprintf(cadena, "SENSIBILITAT %d", getSens()); /* Sensibilitat a la que volem configurar els sensors */
        escribir(cadena,linea++);

        sprintf(cadena, "VELOCITAT %d", getSpeed()); /* Velocitat a la qual va el robot */
        escribir(cadena,linea++);

        if(getReverseActive()){
            sprintf(cadena, "REVERSE %s", reverseMsg); /* Va marxa enrere en cas de trobar-se atascat */
        }else{
            sprintf(cadena, "REVERSE %s", noReverseMsg); /* Dona mitja volta en cas de trobar-se atascat */
        }
        escribir(cadena,linea++);

        sprintf(cadena, "RESETEAR"); /* Opcio per resetejar l'estat del robot */
        halLcdPrintLine(cadena,linea++,INVERT_TEXT);

        sprintf(cadena, "EMPEZAR"); /* Opcio per comencar a moure el robot */
        escribir(cadena,linea++);
        break;

    case 4:
        sprintf(cadena, "SENSIBILITAT %d", getSens()); /* Sensibilitat a la que volem configurar els sensors */
        escribir(cadena,linea++);

        sprintf(cadena, "VELOCITAT %d", getSpeed()); /* Velocitat a la qual va el robot */
        escribir(cadena,linea++);

        if(getReverseActive()){
            sprintf(cadena, "REVERSE %s", reverseMsg); /* Va marxa enrere en cas de trobar-se atascat */
        }else{
            sprintf(cadena, "REVERSE %s", noReverseMsg); /* Dona mitja volta en cas de trobar-se atascat */
        }
        escribir(cadena,linea++);

        sprintf(cadena, "RESETEAR"); /* Opcio per resetejar l'estat del robot */
        escribir(cadena,linea++);

        sprintf(cadena, "EMPEZAR"); /* Opcio per comencar a moure el robot */
        halLcdPrintLine(cadena,linea++,INVERT_TEXT);
        break;
    }
}

void main(void){
    WDT_A->CTL = WDT_A_CTL_PW | WDT_A_CTL_HOLD; /* Stop watchdog timer */

    init(); /* Funcio que inicialitza tots els recursos */
    halLcdPrintLine(configMsg,linea,NORMAL_TEXT);
    linea+=2;
    struct RxReturn estructura;
    uint8_t selected = 0;

    /* Imprimim el menu */
    imprimirMenu(selected);

    do{
        estructura = leerSensor(); /* La variable estructura guardara els valors que ha llegit dels sensors */

        /* Imprimim per pantalla els valors dels sensors */
        escribir("Sensor values",7);
        sprintf(cadena,"I%3d C%3d D%3d",estructura.StatusPacket[5],estructura.StatusPacket[6],estructura.StatusPacket[7]);
        escribir(cadena,8);

        /* Si l'usuari ha premut la opcio per comencar del menu, comencem */
        if(selected == 4 && start){
            robotRoute(estructura);
        }

        /* Si ha variat l'estat (es a dir, l'usuari ha mogut el joystick o ha premut un boto */
        if(estado_anterior != estado){
            estado_anterior = estado;

            switch(estado){
                case Button_S1:
                    /* Augmenta la sensibilitat en 5 */
                    if(selected == 0 && getSens() <= 250){
                        setSens(getSens() + 5);
                    }

                    /* Augmenta la velocitat en 10 */
                    if(selected == 1 && getSpeed() < MAXSPEED){
                        setSpeed(getSpeed() + 10);
                    }

                    /* Cambia entre el mode marxa enrere i el mode mitja volta
                     * en cas de trobar-se atrapat */
                    if(selected == 2){
                        if(getReverseActive()){
                            setReverseActive(false);
                        } else{
                            setReverseActive(true);
                        }
                    }

                    /* Reseteja el moviment del robot i torna a la configuracio inicial */
                    if(selected == 3){
                        menu = 0;
                        selected = 0;
                        start = false;
                        if(!start){
                            setWall(WALL_NONE);
                            stopMovementRobot();
                            apagarLedsMotor();
                        }
                    }

                    if(selected == 4){
                        start = true;
                    }
                    break;

                case Button_S2:
                    /* Disminueix la sensibilitat en 5 */
                    if(selected == 0 && getSens() > 5){
                        setSens(getSens() - 5);
                    }

                    /* Decrementa la velocitat en 10 */
                    if(selected == 1 && getSpeed() > MINSPEED+10){
                        setSpeed(getSpeed() - 10);
                    }

                case Jstick_Up:
                    /* Mou la seleccio del menu cap amunt */
                    if(selected > 0) selected --;
                    break;

                case Jstick_Down:
                    /* Mou la seleccio del menu cap abaix */
                    if (selected < 4) selected ++;
                    break;
        }
            imprimirMenu(selected); /* Torna a imprimir el menu */
    }
    }while(1);
}

/* Rutines de gestio dels botons i dels joysticks (mitjancant aquestes rutines detectem que boto s'ha premut o cap a on s'ha mogut
 * el joystick (per tal d'actualitzar el valor de la variable estado):
 * Actualizar el valor de la variable global estado
 * */

/* ISR per les interrupcions del port 3 (pulsador S2): */
void PORT3_IRQHandler(void){
    uint8_t flag = P3IV; /* Guardem el vector d'interrupcions. A mes, a l'accedir a aquest vector vector, es neteja automaticament */
    P3IE &= 0xDF; /* Interrupcions del boto S2 en el port 3 desactivades */
    estado_anterior=0;

    switch(flag){
    case 0x0C: /* Pin 5, corresponent al boto S2 */
        estado = Button_S2;
        break;
    }

    P3IE |= 0x20; /* Interrupcions pulsador S2 en el port 3 reactivades */
}


/* ISR per les interrupcions del port 4 (joystick centre, joystick dreta i joystick esquerra): */
void PORT4_IRQHandler(void){
    uint8_t flag = P4IV; /* Guardem el vector d'interrupcions. A mes, a l'accedir a aquest vector vector, es neteja automaticament */
    P4IE &= 0x5D; /* Interrupcions del joystick en el port 4 desactivades */
    estado_anterior=0;

    switch(flag){
            case 0x04: /* Pin 1 */
                estado = Jstick_Center; /* Centre */
                break;
            case 0x0C: /* Pin 5 */
                estado = Jstick_Right; /* Dreta */
                break;
            case 0x10: /* Pin 7 */
                estado = Jstick_Left; /* Esquerra */
                break;
            }

    P4IE |= 0xA2; /* Interrupcions joystick en el port 4 reactivades */
}

/* ISR per les interrupcions del port 5 (joystick up, joystick down i polsador S1): */
void PORT5_IRQHandler(void){
    uint8_t flag = P5IV; /* Guardem el vector d'interrupcions. A mes, a l'accedir a aquest vector vector, es neteja automaticament */
    P5IE &= 0xCD; /* Interrupcions del joystick i boto S1 en el port 5 desactivades */
    estado_anterior=0;

    switch(flag){
            case 0x04: /* Pin 1 */
                estado = Button_S1;
                break;
            case 0x0A: /* Pin 4 */
                estado = Jstick_Up;
                break;
            case 0x0C: /* Pin 5 */
                estado = Jstick_Down;
                break;
            }

    P5IE |= 0x32; /* Interrupcions joystick i pulsador S1 en el port 5 reactivades */
}
