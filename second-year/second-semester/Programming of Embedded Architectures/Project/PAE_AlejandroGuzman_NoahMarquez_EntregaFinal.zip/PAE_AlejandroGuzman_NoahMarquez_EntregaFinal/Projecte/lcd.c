#include <msp432p401r.h>
#include <stdio.h>
#include <stdint.h>
#include "lib_PAE2.h"

/* Inicialitzacio de la pantalla LCD */
void init_LCD(void)
{
    halLcdInit(); /* Inicialitzar i configurar la pantalla */
    halLcdClearScreenBkg(); /* Borrar la pantalla, omplint amb el color de fons */
}

/* Borrar linia
 *
 * Dades d'entrada: linia, indica la linia a eliminar */
void borrar(uint8_t linia)
{
    char borrado[] = "               "; /* Una linia sencera de 15 espais en blanc */
    halLcdPrintLine(borrado, linia, NORMAL_TEXT); /* Escrivim una linia en blanc */
}

/* Escriure linia
 *
 * Dades d'entrada: linia, indica la linia del LCD on escriure
 *                  String, la cadena de caracters que volem escriure */
void escribir(char String[], uint8_t linia)

{
    halLcdPrintLine(String, linia, NORMAL_TEXT); /* Enviem l'String al LCD, sobreescrivint la linia indicada */
}
