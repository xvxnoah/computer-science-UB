#include <Hardware.h>
#include <msp432p401r.h>
#include <stdio.h>
#include <stdint.h>
#include "lib_PAE2.h"
#include "lcd.h"
#include "botons.h"
#include "interrupcions.h"
#include "timers.h"
#include "uart.h"


/* Inicialització dels recursos */
void init_recursos(){
    init_ucs_24MHz();       /* Inicialització dels clocks */
    init_botons();          /* Configurem els botons i els leds */
    init_interrupcions();   /* Configurem i activem les interrupcions */
    init_timers();          /* Inicialitzem els timers */
    init_LCD();             /* Inicialitzem la pantalla LCD */
    init_UART();            /* Iniciem la UART */
}

