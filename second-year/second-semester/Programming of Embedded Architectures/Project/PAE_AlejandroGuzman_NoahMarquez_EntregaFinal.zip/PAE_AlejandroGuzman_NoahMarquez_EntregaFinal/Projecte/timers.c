#include <msp432p401r.h>
#include <stdint.h>
#include <stdio.h>

/* Funcio per inicialitzar els timers */
void init_timers(){
    TA1CTL |= 0x0200;   /* Iniciem SMCLK en Stop mode */
    TA1CCTL0 |= 0x0010; /* Habilitem la interrupcio */
    TA1CCR0 = 24000;    /* Establim el temps de la interrupcio */
}
