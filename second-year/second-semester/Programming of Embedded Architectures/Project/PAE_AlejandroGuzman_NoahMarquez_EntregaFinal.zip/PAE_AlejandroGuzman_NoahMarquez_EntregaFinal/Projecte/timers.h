#ifndef TIMERS_H_
#define TIMERS_H_

void init_timers();

#endif
