#include <FuncionsRobot.h>

/* Funcio per encendre els LEDs del motor
 * Rep dos booleans, un per a cada motor
 */
void encenderLedsMotor(bool rLed, bool lLed){
    byte parametros[16];

    parametros[0] = LED_MOTOR;                /* Posem el LED del motor a 1 (ences) */
    parametros[1] = 1;

    if(rLed){
        TxPacket(2, 2, WRITE, parametros);    /* Enviem al motor 2 */
        RxPacket();                           /* Comprovem que s'ha rebut correctament */
    }

    if(lLed){
        TxPacket(3, 2, WRITE, parametros);    /* Enviem al motor 3 */
        RxPacket();                           /* Comprovem que s'ha rebut correctament */
    }
}

/* Funcio per apagar els LEDs dels motors */
void apagarLedsMotor(void){
    byte parametros[16];

    parametros[0] = LED_MOTOR;              /* Posem el LED del motor a 0 (apagat) */
    parametros[1] = 0;

    TxPacket(2, 2, WRITE, parametros);      /* Enviem al motor 2 */
    RxPacket();                             /* Comprovem que s'ha rebut correctament */

    TxPacket(3, 2, WRITE, parametros);      /* Enviem al motor 3 */
    RxPacket();                             /* Comprovem que s'ha rebut correctament */

}

/* Funcio per a moure el robot */
void moveRobot(bool forward, uint16_t speed){
    byte parametros[16];

    parametros[0] = MOVE_MOTOR; /* Escrivim el moving speed - direccio MOVE_MOTOR */

    if(speed <= MAXSPEED && speed >= MINSPEED){
        parametros[1] = speed;
    }else{
        parametros[1] = MINSPEED;
    }

    if(forward){
        parametros[2] = DOWN;               /* Anem recte */
        TxPacket(2, 3, WRITE, parametros);  /* Enviem al motor 2 */
        RxPacket();                         /* Comprovem que s'ha rebut correctament */

        parametros[2] = UP;
        TxPacket(3, 3, WRITE, parametros);  /* Enviem al motor 3 */
        RxPacket();                         /* Comprovem que s'ha rebut correctament */

    }else{
        parametros[2] = UP;                 /* Anem enrere */
        TxPacket(2, 3, WRITE, parametros);  /* Enviem al motor 2 */
        RxPacket();                         /* Comprovem que s'ha rebut correctament */

        parametros[2] = DOWN;
        TxPacket(3, 3, WRITE, parametros);  /* Enviem al motor 3 */
        RxPacket();                         /* Comprovem que s'ha rebut correctament */
    }

}

/* Parem el moviment del robot */
void stopMovementRobot(void){
    byte parametros[16];

    parametros[0] = MOVE_MOTOR;             /* Posem a 0 la direccio MOVE_MOTOR */
    parametros[1] = 0;
    parametros[2] = 0;
    TxPacket(2, 3, WRITE, parametros);      /* Enviem la informacio al motor 2 */
    RxPacket();                             /* Comprovem que s'ha rebut correctament */
    TxPacket(3, 3, WRITE, parametros);      /* Enviem la informacio al motor 3 */
    RxPacket();                             /* Comprovem que s'ha rebut correctament */
}

/* Funcio per fer girar el robot */
void spinRobot(bool sentido, uint16_t speed){
    byte parametros[16];
    stopMovementRobot();                    /* Aturem els motors per moure nomes la roda que volem */

    parametros[0] = MOVE_MOTOR;
    parametros[1] = MINSPEED;

    if(sentido){
        parametros[2] = UP;                 /* Motor 2 endavant */
        TxPacket(3, 3, WRITE, parametros);  /* Direm que nomes es mogui el motor 2 endavant (en sentit horari) */
        RxPacket();                         /* Comprovem que s'ha rebut correctament */

    }else{
        parametros[2] = DOWN;               /* Motor 3 enrere */
        TxPacket(2, 3, WRITE, parametros);  /* Direm que nomes es mogui el motor 3 enrere (sentit antihorari) */
        RxPacket();                         /* Comprovem que s'ha rebut correctament */

    }

}

/* Funcio que ens retorna un RxReturn per tal de llegir el sensor.
 * S'encarrega de retornar les dades que rep dels sensors. */
struct RxReturn leerSensor(void){
    byte parametros[16];

    parametros[0] = 0X1A;                       /* Accedim a la direccio 0x1A */
    parametros[1] = 3;                          /* Indiquem els 3 sensors seguents (esquerra, central i dreta) */
    TxPacket(SENSOR_100, 2, READ, parametros);  /* Enviem la trama per que llegeixi els valors del sensor 100 */
    struct RxReturn retorn = RxPacket();        /* Comprovem que s'ha rebut correctament */
    return retorn;
}
