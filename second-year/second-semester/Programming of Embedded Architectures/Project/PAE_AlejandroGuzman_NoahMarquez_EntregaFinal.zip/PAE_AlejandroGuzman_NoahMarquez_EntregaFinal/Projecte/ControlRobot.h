#ifndef CONTROLROBOT_H_
#define CONTROLROBOT_H_
#include <FuncionsRobot.h>
#include "uart.h"

/* Defines per distingir en quina situacio ens trobem per actuar amb el robot */
#define WALL_I 0
#define WALL_D 1
#define WALL_NONE 2
#define WALL_BREAK 3

/* Definicio de variables */
uint16_t speed;
uint8_t wall;
bool direction;
bool mode;
uint16_t sens;
bool reverseActive;

/* Getters */
uint16_t getSpeed();
uint8_t getWall();
bool getDirection();
bool getMode();
uint16_t getSens();
bool getReverseActive();

/* Setters */
void setSpeed(uint16_t);
void setWall(uint8_t);
void setDirection(bool);
void setForward(bool);
void setMode(bool);
void setSens(uint16_t);
void setReverseActive(bool);

void init();

void robotRoute(struct RxReturn structure);

void musica(void);

#endif
