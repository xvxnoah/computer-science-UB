#ifndef BOTONS_H_
#define BOTONS_H_

void init_botons(void);

#endif
