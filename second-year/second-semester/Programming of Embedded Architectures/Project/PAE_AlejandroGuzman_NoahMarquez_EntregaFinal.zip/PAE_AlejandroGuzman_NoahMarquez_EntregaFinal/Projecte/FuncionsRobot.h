#ifndef FUNCIONSROBOT_H_
#define FUNCIONSROBOT_H_
#include <Hardware.h>
#include "uart.h"

/* Definicio de constants per a les diferents funcions */
#define MOTOR_2 2
#define MOTOR_3 3
#define WRITE 0x03
#define READ 0x02
#define UP 1
#define DOWN 5
#define MAXSPEED 1023
#define MINSPEED 200
#define MOVE_MOTOR 0x20
#define LED_MOTOR 0x19
#define SENSOR_100 100

/* Comandes pels moviments dels motors */
void stopMovementRobot(void);
void encenderLedsMotor(bool,bool);
void apagarLedsMotor(void);
void moveRobot(bool, uint16_t);
void spinRobot(bool, uint16_t);
struct RxReturn leerSensor(void);

#endif
