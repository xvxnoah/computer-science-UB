#include <msp432p401r.h>
#include <stdio.h>
#include <stdint.h>


/* Inicialitzacio del controlador d'interrupcions (NVIC) */
void init_interrupcions(void)
{
    /* Configuracio al estil MSP430 "clasic":
     * Enable Port 3 & 4 & 5 & Timer A0 & Timer A1 interrupt on the NVIC
     * segons el datasheet (Tabla "6-12. NVIC Interrupts", capitol "6.6.2 Device-Level User Interrupts", p80-81 del document SLAS826A-Datasheet),
     * la interrupcio del port 3 es la User ISR numero 37, la del port 4 es la User ISR numero 38 i la del port 5 es la User ISR numero 39.
     * Les dels Timers tambe les podem consultar en l'anterior apartat del Datasheet.
     *
     * Segons el document SLAU356A-Technical Reference Manual, capitol "2.4.3 NVIC Registers"
     * hi ha 2 registres d'habilitacio ISER0 i ISER1, cadascun per a 32 interrupcions (0..31, y 32..63, resp.),
     * accessibles mitjancant l'estructura NVIC->ISER[x], amb x = 0 o x = 1.
     * Aixi mateix, hi ha 2 registres per deshabilitar-les: ICERx, i dos registres per a limpiar-les: ICPRx.
    */

    /* Int. port 3 = 37 correspon al bit 5 del segon registre ISER1: */
    NVIC->ICPR[1] |= BIT5; /* Primer, ens asegurem de que no quedi cap interrupcio residual en aquest port, */
    NVIC->ISER[1] |= BIT5; /* i habilitem les interrupcions al port */

    /* Int. port 4 = 38 correspon al bit 6 del segon registre ISERx: */
    NVIC->ICPR[1] |= BIT6; /* Primer, ens asegurem de que no quedi cap interrupcio residual en aquest port, */
    NVIC->ISER[1] |= BIT6; /* i habilitem les interrupcions al port */

    /* Int. port 5 = 39 correspon al bit 7 del segon registre ISERx: */
    NVIC->ICPR[1] |= BIT7; /* Primer, ens asegurem de que no quedi cap interrupcio residual en aquest port, */
    NVIC->ISER[1] |= BIT7; /* i habilitem les interrupcions al port */

    /* Timer A0 */
    //NVIC->ICPR[0] |= BIT8;  /* Primer, ens asegurem de que no quedi cap interrupcio residual en aquest port, */
    //NVIC->ISER[0] |= BIT8;  /* i habilitem les interrupcions al port */

    /* Timer A1 */
    NVIC->ICPR[0] |= BITA;  /* Primer, ens asegurem de que no quedi cap interrupcio residual en aquest port, */
    NVIC->ISER[0] |= BITA;  /* i habilitem les interrupcions al port */

    NVIC->ICPR[0] |= BIT(18);
    NVIC->ISER[0] |= BIT(18);

    __enable_interrupt();   /* Habilitem les interrupcions a nivell global del microcontrolador */
}
