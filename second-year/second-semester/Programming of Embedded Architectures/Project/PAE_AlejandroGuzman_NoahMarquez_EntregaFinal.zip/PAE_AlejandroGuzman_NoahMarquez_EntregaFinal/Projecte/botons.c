#include "msp432p401r.h"

/* Configuracio dels ports dels botons i els LEDs */
void init_botons(void){
        /* Leds RGB del MK II: */
          P2DIR |= 0x50;  /* Pins P2.4 (G), 2.6 (R) como sortides LED (RGB) */
          P5DIR |= 0x40;  /* Pin P5.6 (B) com sortida LED (RGB) */
          P2OUT &= 0xAF;  /* Iniciem LEDs RGB (G, R) a 0 (apagats) */
          P5OUT &= ~0x40; /* Iniciem LEDs RGB (B) a 0 (apagat) */

        /* 7 LEDs */
          P7DIR |= 0xFF;  /* Pins P7.0 ... P7.7 com a sortida de LEDs de la placa secundaria */
          P7OUT &= ~0xFF; /* Iniciem P7 a 0 (LEDs apagats) */

        /* Boto S1 del MK II */
          P5SEL0 &= ~0x02;   /* Pin P5.1 com I/O digital */
          P5SEL1 &= ~0x02;   /* Pin P5.1 com I/O digital */
          P5DIR &= ~0x02;    /* Pin P5.1 com entrada */
          P5IES &= ~0x02;    /* Amb transicio L->H */
          P5IE |= 0x02;      /* Interrupcions activades a P5.1 */
          P5IFG = 0;         /* Netegem tots els flags de les interrupcions del port 5 */
          /* P5REN no cal ja que ja hi ha una resistencia de pullup a la placa MK II */

        /* Boto S2 del MK II */
          P3SEL0 &= ~0x20;   /* Pin P3.5 com I/O digital */
          P3SEL1 &= ~0x20;   /* Pin P3.5 com I/O digital */
          P3DIR &= ~0x20;    /* Pin P3.5 com entrada */
          P3IES &= ~0x20;    /* Amb transicio L->H */
          P3IE |= 0x20;      /* Interrupcions activades a P3.5 */
          P3IFG = 0;         /* Netegem tots els flags de les interrupcions del port 3 */
          /* P3REN no cal ja que ja hi ha una resistencia de pullup a la placa MK II */

        /* Configurem els GPIOs del joystick del MK II: */
          P4DIR &= ~(BIT1 + BIT5 + BIT7);   /* Pins P4.1, 4.5 i 4.7 com entrades */
          P4SEL0 &= ~(BIT1 + BIT5 + BIT7);  /* Pins P4.1, 4.5 i 4.7 com I/O digitals */
          P4SEL1 &= ~(BIT1 + BIT5 + BIT7);
          P4REN |= BIT1 + BIT5 + BIT7;      /* Amb resistencia activada de pull up*/
          P4OUT |= BIT1 + BIT5 + BIT7;
          P4IE |= BIT1 + BIT5 + BIT7;       /* Interrupcions activades a P4.1, 4.5 i 4.7 */
          P4IES &= ~(BIT1 + BIT5 + BIT7);   /* Les interrupcions es generaran amb transicio L->H */
          P4IFG = 0;                        /* Netegem tots els flags de les interrupcions del port 4 */

          P5DIR &= ~(BIT4 + BIT5);          /* Pins P5.4 i 5.5 com entrades */
          P5SEL0 &= ~(BIT4 + BIT5);         /* Pins P5.4 i 5.5 com I/O digitals */
          P5SEL1 &= ~(BIT4 + BIT5);
          P5IE |= BIT4 + BIT5;              /* Interrupcions activades a 5.4 i 5.5 */
          P5IES &= ~(BIT4 + BIT5);          /* Les interrupcions es generaran amb transicio L->H */
          P5IFG = 0;                        /* Netegem tots els flags de les interrupcions del port 5 */
          /* Ja hi ha una resistencia de pullup a la placa MK II */
}



